#include "app/AppController.h"
#include "ui/Live2DWindow.h"
#include "util/Log.h"

#include <QApplication>
#include <QDir>
#include <QFile>
#include <QIcon>
#include <QTextStream>
#include <QThread>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

#include <functional>

namespace {

#ifdef Q_OS_WIN
// 桌宠子进程的看门狗：等父进程句柄变成 signaled（父进程退出/崩溃），就自动退出。
class ParentWatcher : public QThread {
public:
    explicit ParentWatcher(unsigned long pid) : m_pid(pid) {}
    void run() override
    {
        HANDLE parent = OpenProcess(SYNCHRONIZE, FALSE, m_pid);
        if (parent == nullptr) {
            return;
        }
        WaitForSingleObject(parent, INFINITE);
        CloseHandle(parent);
        if (!isInterruptionRequested()) {
            QMetaObject::invokeMethod(QCoreApplication::instance(), []() {
                QCoreApplication::quit();
            }, Qt::QueuedConnection);
        }
    }

private:
    unsigned long m_pid = 0;
};
#endif

// 子进程模式：stdin 读命令（expr/mouth/mode/quit）。
// 用独立线程阻塞读，GUI 线程不卡。
class StdinReader : public QThread {
public:
    std::function<void(QString)> onLine;

    void run() override
    {
        QTextStream in(stdin);
        in.setEncoding(QStringConverter::Utf8);   // Demon 用 UTF-8 写 stdin，不能靠 locale
        while (!isInterruptionRequested()) {
            const QString line = in.readLine();
            if (line.isNull()) {
                // stdin 关闭 = 父进程（Demon）退出 → 桌宠也退出，别留孤儿进程占着 exe
                QMetaObject::invokeMethod(qApp, []() { QCoreApplication::quit(); }, Qt::QueuedConnection);
                break;
            }
            if (onLine) {
                onLine(line);
            }
        }
    }
};

// `demon.exe --live2d-pet`：只跑桌宠窗口的轻量进程。
// 为什么要单进程：同一个进程里同时有主窗口/托盘/HTTP 服务时，桌宠的呈现会被压到
// ~10fps（各种原因都排查过），而这个干净的进程里能稳定 20-25fps。
int runPetOnly(int argc, char** argv)
{
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("DemonPet"));
    Log::init(QDir(QCoreApplication::applicationDirPath())
                  .absoluteFilePath(QStringLiteral("data/pet.log")));
    app.setQuitOnLastWindowClosed(true);

    unsigned long parentPid = 0;
    for (int i = 1; i < argc; ++i) {
        if (qstrcmp(argv[i], "--parent-pid") == 0 && i + 1 < argc) {
            parentPid = static_cast<unsigned long>(QByteArray(argv[i + 1]).toULong());
        }
    }

    QString modelPath = qEnvironmentVariable("DEMON_LIVE2D_MODEL");
    if (modelPath.isEmpty()) {
        modelPath = QStringLiteral("E:/dshwork/models/live2d/大肥鱼-B站/大肥鱼.model3.json");
    }

    Live2DWindow window;
    window.resize(480, 720);
    window.setPosition(120, 80);
    window.loadModel(modelPath);
    window.setFrameInterval(33);
    window.show();
    window.raise();

#ifdef Q_OS_WIN
    ParentWatcher parentWatcher(parentPid);
    if (parentPid != 0) {
        parentWatcher.start();
    }
#endif

    StdinReader reader;
    reader.onLine = [&window](const QString& line) {
        QMetaObject::invokeMethod(&window, [&window, line]() {
            const QStringList parts = line.trimmed().split(QLatin1Char(' '), Qt::SkipEmptyParts);
            if (parts.isEmpty()) {
                return;
            }
            const QString cmd = parts.value(0);
            if (cmd == QStringLiteral("expr")) {
                // 一次性触发
                const QString name = parts.mid(1).join(QLatin1Char(' '));
                if (name.isEmpty()) {
                    window.clearOneShotExpression();
                } else {
                    window.setOneShotExpression(name);
                }
            } else if (cmd == QStringLiteral("exprk")) {
                // 保留触发（可叠加多个）
                const QString name = parts.mid(1).join(QLatin1Char(' '));
                if (!name.isEmpty()) {
                    window.togglePersistentExpression(name);
                }
            } else if (cmd == QStringLiteral("exprclear")) {
                window.clearAllExpressions();
            } else if (cmd == QStringLiteral("act")) {
                window.playAction(parts.value(1));
            } else if (cmd == QStringLiteral("mouth")) {
                window.setMouth(parts.value(1).toDouble());
            } else if (cmd == QStringLiteral("mode")) {
                window.setHalfBody(parts.value(1) == QStringLiteral("half"));
            } else if (cmd == QStringLiteral("quit")) {
                QCoreApplication::quit();
            }
        }, Qt::QueuedConnection);
    };
    reader.start();

    const int code = app.exec();
    reader.requestInterruption();
    reader.wait(500);
    return code;
}

} // namespace

int main(int argc, char** argv)
{
    // 必须在 QApplication 之前设置默认 surface format（alpha=8、OpenGL 2.1 兼容 profile）。
    Live2DWindow::configureSurfaceFormat();

    for (int i = 1; i < argc; ++i) {
        if (qstrcmp(argv[i], "--live2d-pet") == 0) {
            return runPetOnly(argc, argv);
        }
    }

    qputenv("QTWEBENGINE_CHROMIUM_FLAGS",
            ""
            "--disable-background-timer-throttling --disable-renderer-backgrounding "
            "--disable-backgrounding-occluded-windows");
    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("Demon"));
    app.setApplicationVersion(QStringLiteral("2.0.0"));
    // 托盘程序：关掉最后一个窗口不退出
    app.setQuitOnLastWindowClosed(false);

    // 窗口/任务栏图标：优先用同目录的 demon.ico
    const QString iconPath = QCoreApplication::applicationDirPath() + QStringLiteral("/demon.ico");
    if (QFile::exists(iconPath)) {
        app.setWindowIcon(QIcon(iconPath));
    }

    AppController controller;
    if (!controller.start()) {
        return 1;
    }

    return app.exec();
}
