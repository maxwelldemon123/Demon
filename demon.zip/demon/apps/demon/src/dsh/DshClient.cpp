#include "DshClient.h"

#include "../util/Log.h"

#include <QFile>
#include <QJsonDocument>
#include <QNetworkReply>
#include <QStandardPaths>

namespace {

QString readToken()
{
    const QString path = QStandardPaths::writableLocation(QStandardPaths::GenericDataLocation)
        + QStringLiteral("/../../Local/dsh-demon/token");
    // 直接按 Windows 约定读 %LOCALAPPDATA%\dsh-demon\token
    QString direct = qEnvironmentVariable("LOCALAPPDATA");
    if (!direct.isEmpty()) {
        QFile file(direct + QStringLiteral("/dsh-demon/token"));
        if (file.open(QIODevice::ReadOnly)) {
            return QString::fromUtf8(file.readAll()).trimmed();
        }
    }
    QFile fallback(path);
    if (fallback.open(QIODevice::ReadOnly)) {
        return QString::fromUtf8(fallback.readAll()).trimmed();
    }
    return QString();
}

} // namespace

DshClient::DshClient(const QString& endpoint, QObject* parent)
    : QObject(parent)
    , m_endpoint(endpoint)
    , m_token(readToken())
{
    if (m_token.isEmpty()) {
        Log::warn(QStringLiteral("dsh-demon：没有找到 token（%LOCALAPPDATA%\\dsh-demon\\token）"));
    }
}

QNetworkRequest DshClient::makeRequest(const QString& path) const
{
    QNetworkRequest request(QUrl(m_endpoint + path));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    if (!m_token.isEmpty()) {
        request.setRawHeader("X-Dsh-Token", m_token.toUtf8());
    }
    return request;
}

void DshClient::health()
{
    QNetworkReply* reply = m_net.get(makeRequest(QStringLiteral("/v1/health")));
    connect(reply, &QNetworkReply::finished, reply, [this, reply]() {
        const QByteArray payload = reply->readAll();
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            emit healthChanged(false, reply->errorString());
            return;
        }
        const QJsonObject root = QJsonDocument::fromJson(payload).object();
        const QString version = root.value(QStringLiteral("version")).toString();
        const QString contract = root.value(QStringLiteral("contract")).toString();
        Log::info(QStringLiteral("dsh-demon 在线：version=%1 contract=%2").arg(version, contract));
        emit healthChanged(true, version);
    });
}

void DshClient::pushEmotion(const QString& character, const QString& emotion,
                            double intensity, const QString& source)
{
    if (m_token.isEmpty()) {
        return;
    }
    QJsonObject body;
    body.insert(QStringLiteral("type"), QStringLiteral("emotion"));
    body.insert(QStringLiteral("character"), character);
    body.insert(QStringLiteral("subject"), QStringLiteral("user"));
    body.insert(QStringLiteral("emotion"), emotion);
    body.insert(QStringLiteral("intensity"), intensity);
    body.insert(QStringLiteral("source"), source);

    QNetworkReply* reply = m_net.post(makeRequest(QStringLiteral("/v1/events")),
                                      QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, reply, [reply]() {
        if (reply->error() != QNetworkReply::NoError) {
            Log::warn(QStringLiteral("dsh-demon 推送情绪失败：%1").arg(reply->errorString()));
        }
        reply->deleteLater();
    });
}

void DshClient::queryMemory(const QString& character, const QString& query,
                            std::function<void(bool, const QJsonObject&)> callback)
{
    QJsonObject body;
    body.insert(QStringLiteral("character"), character);
    body.insert(QStringLiteral("query"), query);
    QNetworkReply* reply = m_net.post(makeRequest(QStringLiteral("/v1/memory/query")),
                                      QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, reply, [reply, callback]() {
        const QJsonObject root = QJsonDocument::fromJson(reply->readAll()).object();
        callback(reply->error() == QNetworkReply::NoError, root);
        reply->deleteLater();
    });
}


void DshClient::sync(bool chats, bool worlds,
                     std::function<void(bool, const QJsonObject&)> callback)
{
    QJsonObject body;
    body.insert(QStringLiteral("chats"), chats);
    body.insert(QStringLiteral("worlds"), worlds);
    QNetworkReply* reply = m_net.post(makeRequest(QStringLiteral("/v1/sync")),
                                      QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, reply, [reply, callback]() {
        const QJsonObject root = QJsonDocument::fromJson(reply->readAll()).object();
        const bool ok = reply->error() == QNetworkReply::NoError;
        if (!ok) {
            Log::warn(QStringLiteral("dsh-demon 同步失败：%1").arg(reply->errorString()));
        }
        callback(ok, root);
        reply->deleteLater();
    });
}


void DshClient::setAutoTransfer(bool on)
{
    QJsonObject body;
    body.insert(QStringLiteral("autoTransfer"), on);
    QNetworkReply* reply = m_net.post(makeRequest(QStringLiteral("/v1/config")),
                                      QJsonDocument(body).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, reply, [this, on, reply]() {
        if (reply->error() != QNetworkReply::NoError) {
            Log::warn(QStringLiteral("dsh-demon 自动传输设置失败：%1").arg(reply->errorString()));
        } else {
            Log::info(QStringLiteral("dsh-demon 自动传输：%1").arg(on ? 1 : 0));
        }
        reply->deleteLater();
    });
}
