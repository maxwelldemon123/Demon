#pragma once

#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QObject>
#include <QString>

#include <functional>

/**
 * dsh-demon 本地记忆/情绪服务的客户端（127.0.0.1:8791）。
 * token 默认从 %LOCALAPPDATA%\dsh-demon\token 读取。
 */
class DshClient : public QObject {
    Q_OBJECT

public:
    explicit DshClient(const QString& endpoint = QStringLiteral("http://127.0.0.1:8791"),
                       QObject* parent = nullptr);

    void health();
    void pushEmotion(const QString& character, const QString& emotion,
                     double intensity, const QString& source);
    void queryMemory(const QString& character, const QString& query,
                     std::function<void(bool ok, const QJsonObject& result)> callback);
    void setAutoTransfer(bool on);
    void sync(bool chats, bool worlds,
              std::function<void(bool ok, const QJsonObject& result)> callback);

signals:
    void healthChanged(bool ok, const QString& message);

private:
    QNetworkRequest makeRequest(const QString& path) const;
    QString m_endpoint;
    QString m_token;
    QNetworkAccessManager m_net;
};
