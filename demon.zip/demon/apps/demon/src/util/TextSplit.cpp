#include "TextSplit.h"

#include <QRegularExpression>

QString detectTextLang(const QString& text)
{
    static const QRegularExpression kana(QStringLiteral("[\\x{3040}-\\x{30ff}]"));
    static const QRegularExpression han(QStringLiteral("[\\x{4e00}-\\x{9fff}]"));
    static const QRegularExpression hangul(QStringLiteral("[\\x{ac00}-\\x{d7af}]"));

    if (text.contains(kana)) {
        return QStringLiteral("ja");
    }
    if (text.contains(hangul)) {
        return QStringLiteral("ko");
    }
    if (text.contains(han)) {
        return QStringLiteral("zh");
    }
    return QStringLiteral("en");
}
