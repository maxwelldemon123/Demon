#pragma once

#include <QString>
#include <QStringList>

/** 粗略判语种：有假名→ja，有汉字→zh，否则 en */
QString detectTextLang(const QString& text);
