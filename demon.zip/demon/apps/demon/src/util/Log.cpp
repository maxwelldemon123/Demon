#include "Log.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QTextStream>

#include <QMutex>
#include <QMutexLocker>

#include <cstdio>

namespace {
QString g_filePath;
QFile* g_logFile = nullptr;
QMutex g_mutex;

QString timestamp()
{
    return QDateTime::currentDateTime().toString(QStringLiteral("yyyy-MM-dd HH:mm:ss.zzz"));
}
} // namespace

void Log::init(const QString& filePath)
{
    g_filePath = filePath;
    const QFileInfo info(filePath);
    QDir().mkpath(info.absolutePath());

    // 简单滚动：超过 8MB 就把旧文件改名
    if (info.exists() && info.size() > 8 * 1024 * 1024) {
        const QString backup = filePath + QStringLiteral(".1");
        QFile::remove(backup);
        QFile::rename(filePath, backup);
    }

    if (!g_logFile) {
        g_logFile = new QFile(filePath);
    }
    g_logFile->open(QIODevice::WriteOnly | QIODevice::Append);
}

void Log::info(const QString& message)
{
    write(QStringLiteral("INFO"), message);
}

void Log::warn(const QString& message)
{
    write(QStringLiteral("WARN"), message);
}

void Log::error(const QString& message)
{
    write(QStringLiteral("ERROR"), message);
}

void Log::write(const QString& level, const QString& message)
{
    const QString line = QStringLiteral("[%1] [%2] %3").arg(timestamp(), level, message);
    const QByteArray utf8 = line.toUtf8();

    QMutexLocker locker(&g_mutex);
    std::fprintf(stderr, "%s\n", utf8.constData());
    std::fflush(stderr);

    if (g_logFile && g_logFile->isOpen()) {
        g_logFile->write(utf8);
        g_logFile->write("\n");
        g_logFile->flush();
    }
}
