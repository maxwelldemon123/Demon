#include "TtsClient.h"

#include "../util/Log.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkRequest>
#include <QUrlQuery>
#include <QUrl>
#include <QUrlQuery>

TtsClient::TtsClient(QObject* parent)
    : QObject(parent)
    , m_net(new QNetworkAccessManager(this))
{
}

VoiceProfile TtsClient::profile(const QString& id) const
{
    for (const VoiceProfile& p : m_profiles) {
        if (p.id == id) {
            return p;
        }
    }
    return m_profiles.isEmpty() ? VoiceProfile{} : m_profiles.first();
}

void TtsClient::synthesize(const QString& text, const QString& lang, const VoiceProfile& profile,
                           double speed, std::function<void(const QByteArray&, const QString&)> callback)
{
    if (m_provider.isEmpty()) {
        if (callback) {
            callback(QByteArray(), QStringLiteral("还没有选择语音后端：请在 Demon 的「语音」页选一下「本地 GPT-SoVITS」或「千问 Qwen」"));
        }
        return;
    }
    if (m_provider == QStringLiteral("qwen")) {
        synthesizeQwen(text, lang, speed, profile.qwenVoice, std::move(callback));
        return;
    }

    QJsonObject body;
    body.insert(QStringLiteral("text"), text);
    body.insert(QStringLiteral("text_lang"), lang);
    body.insert(QStringLiteral("ref_audio_path"), profile.refAudio);
    body.insert(QStringLiteral("prompt_text"), profile.promptText);
    body.insert(QStringLiteral("prompt_lang"), profile.promptLang);
    body.insert(QStringLiteral("text_split_method"), QStringLiteral("cut5"));
    body.insert(QStringLiteral("batch_size"), 1);
    body.insert(QStringLiteral("media_type"), QStringLiteral("wav"));
    body.insert(QStringLiteral("streaming_mode"), 0);
    body.insert(QStringLiteral("speed_factor"), speed);
    body.insert(QStringLiteral("top_k"), 15);
    body.insert(QStringLiteral("top_p"), 1);
    body.insert(QStringLiteral("temperature"), 1);
    body.insert(QStringLiteral("repetition_penalty"), 1.35);
    body.insert(QStringLiteral("seed"), -1);
    body.insert(QStringLiteral("parallel_infer"), true);

    QUrl url(m_endpoint);
    QString path = url.path();
    if (path.endsWith(QLatin1Char('/'))) {
        path.chop(1);
    }
    path += QStringLiteral("/tts");
    url.setPath(path);

    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    QNetworkReply* reply = m_net->post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));

    auto buffer = std::make_shared<QByteArray>();
    connect(reply, &QNetworkReply::readyRead, reply, [reply, buffer]() { buffer->append(reply->readAll()); });
    connect(reply, &QNetworkReply::finished, reply, [this, reply, buffer, text, callback]() {
        if (reply->error() == QNetworkReply::NoError) {
            buffer->append(reply->readAll());
            if (buffer->isEmpty()) {
                callback(QByteArray(), QStringLiteral("合成返回空音频"));
            } else {
                Log::info(QStringLiteral("TTS 合成完成：%1 字 / %2 KB").arg(text.size()).arg(buffer->size() / 1024));
                callback(*buffer, QString());
            }
        } else {
            const QString error = QStringLiteral("%1（%2）").arg(reply->errorString()).arg(m_endpoint);
            Log::error(QStringLiteral("TTS 失败：%1").arg(error));
            callback(QByteArray(), error);
        }
        reply->deleteLater();
    });
}


void TtsClient::ensureWeights(const VoiceProfile& profile, std::function<void(const QString&)> callback)
{
    if (m_provider.isEmpty()) {
        callback(QStringLiteral("还没有选择语音后端：请在 Demon 的「语音」页选一下「本地 GPT-SoVITS」或「千问 Qwen」"));
        return;
    }
    if (m_provider == QStringLiteral("qwen")) {
        callback(QString());
        return;
    }

    const QString wantGpt = profile.gptWeights.trimmed();
    const QString wantSovits = profile.sovitsWeights.trimmed();

    // 依次设置 GPT、SoVITS；都不需要切换时直接回调
    std::function<void(const QString&)> setSovits = [this, wantSovits, callback](const QString&) {
        if (wantSovits.isEmpty() || wantSovits == m_loadedSovits) {
            callback(QString());
            return;
        }
        QUrl url(m_endpoint);
        QString path = url.path();
        if (path.endsWith(QLatin1Char('/'))) {
            path.chop(1);
        }
        url.setPath(path + QStringLiteral("/set_sovits_weights"));
        QUrlQuery query;
        query.addQueryItem(QStringLiteral("weights_path"), wantSovits);
        url.setQuery(query);

        QNetworkReply* reply = m_net->get(QNetworkRequest(url));
        connect(reply, &QNetworkReply::finished, reply, [this, reply, wantSovits, callback]() {
            const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
            if (reply->error() != QNetworkReply::NoError && status != 400) {
                const QString err = QStringLiteral("设置 SoVITS 权重失败：%1").arg(reply->errorString());
                Log::error(err);
                callback(err);
            } else {
                m_loadedSovits = wantSovits;
                Log::info(QStringLiteral("权重已切换：%1").arg(wantSovits));
                callback(QString());
            }
            reply->deleteLater();
        });
    };

    if (wantGpt.isEmpty() || wantGpt == m_loadedGpt) {
        setSovits(QString());
        return;
    }

    QUrl url(m_endpoint);
    QString path = url.path();
    if (path.endsWith(QLatin1Char('/'))) {
        path.chop(1);
    }
    url.setPath(path + QStringLiteral("/set_gpt_weights"));
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("weights_path"), wantGpt);
    url.setQuery(query);

    QNetworkReply* reply = m_net->get(QNetworkRequest(url));
    connect(reply, &QNetworkReply::finished, reply, [this, reply, wantGpt, setSovits]() {
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        if (reply->error() != QNetworkReply::NoError && status != 400) {
            const QString err = QStringLiteral("设置 GPT 权重失败：%1").arg(reply->errorString());
            Log::error(err);
            setSovits(err);
        } else {
            m_loadedGpt = wantGpt;
            Log::info(QStringLiteral("权重已切换：%1").arg(wantGpt));
            setSovits(QString());
        }
        reply->deleteLater();
    });
}



void TtsClient::synthesizeQwen(const QString& text, const QString& lang, double speed, const QString& voiceOverride,
                               std::function<void(const QByteArray&, const QString&)> callback)
{
    QJsonObject input;
    input.insert(QStringLiteral("text"), text);
    input.insert(QStringLiteral("voice"), voiceOverride.isEmpty() ? m_qwen.voice : voiceOverride);
    input.insert(QStringLiteral("format"), m_qwen.format);
    input.insert(QStringLiteral("sample_rate"), m_qwen.sampleRate);
    input.insert(QStringLiteral("rate"), speed);

    QJsonObject body;
    body.insert(QStringLiteral("model"), m_qwen.model);
    body.insert(QStringLiteral("input"), input);

    QNetworkRequest request(QUrl(m_qwen.baseUrl));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    request.setRawHeader("Authorization", "Bearer " + m_qwen.apiKey.toUtf8());

    Log::info(QStringLiteral("千问合成：model=%1 voice=%2 text=%3")
                  .arg(m_qwen.model, voiceOverride.isEmpty() ? m_qwen.voice : voiceOverride, text.left(16)));

    QNetworkReply* reply = m_net->post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));

    auto buffer = std::make_shared<QByteArray>();
    connect(reply, &QNetworkReply::readyRead, reply, [reply, buffer]() { buffer->append(reply->readAll()); });
    connect(reply, &QNetworkReply::finished, reply, [this, reply, buffer, text, callback]() {
        const int status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        buffer->append(reply->readAll());
        if (reply->error() != QNetworkReply::NoError || status >= 400) {
            const QString detail = QString::fromUtf8(*buffer).left(300);
            Log::error(QStringLiteral("千问 TTS 失败 HTTP %1：%2").arg(status).arg(detail));
            callback(QByteArray(), QStringLiteral("千问 TTS 失败 HTTP %1").arg(status));
            reply->deleteLater();
            return;
        }

        const QJsonObject root = QJsonDocument::fromJson(*buffer).object();
        const QJsonObject audio = root.value(QStringLiteral("output")).toObject()
                                      .value(QStringLiteral("audio")).toObject();
        QString url = audio.value(QStringLiteral("url")).toString();
        const QString b64 = audio.value(QStringLiteral("data")).toString();

        if (!b64.isEmpty()) {
            const QByteArray wav = QByteArray::fromBase64(b64.toLatin1());
            Log::info(QStringLiteral("千问 TTS 完成（内联）：%1 字 / %2 KB").arg(text.size()).arg(wav.size() / 1024));
            callback(wav, QString());
            reply->deleteLater();
            return;
        }

        if (url.isEmpty()) {
            callback(QByteArray(), QStringLiteral("千问 TTS 没有返回音频地址"));
            reply->deleteLater();
            return;
        }

        // 非流式：返回的是 24 小时有效的 URL，需要再下载一次
        QNetworkRequest audioRequest{QUrl(url)};
        QNetworkReply* audioReply = m_net->get(audioRequest);
        auto audioBuffer = std::make_shared<QByteArray>();
        connect(audioReply, &QNetworkReply::readyRead, audioReply,
                [audioReply, audioBuffer]() { audioBuffer->append(audioReply->readAll()); });
        connect(audioReply, &QNetworkReply::finished, audioReply,
                [this, audioReply, audioBuffer, text, callback]() {
                    audioBuffer->append(audioReply->readAll());
                    if (audioReply->error() != QNetworkReply::NoError || audioBuffer->isEmpty()) {
                        Log::error(QStringLiteral("下载千问音频失败：%1").arg(audioReply->errorString()));
                        callback(QByteArray(), QStringLiteral("下载千问音频失败"));
                    } else {
                        Log::info(QStringLiteral("千问 TTS 完成：%1 字 / %2 KB")
                                      .arg(text.size())
                                      .arg(audioBuffer->size() / 1024));
                        callback(*audioBuffer, QString());
                    }
                    audioReply->deleteLater();
                });
        reply->deleteLater();
    });
}
