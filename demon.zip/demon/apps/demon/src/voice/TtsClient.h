#pragma once

#include <QByteArray>
#include <QJsonObject>
#include <QObject>
#include <QString>
#include <QVector>

#include <functional>

class QNetworkAccessManager;
class QNetworkReply;

/** 一条声线档案 */
struct VoiceProfile {
    QString id;          // 档案 id
    QString name;        // 显示名
    QString gptWeights;  // 可空：切换 GPT 权重
    QString sovitsWeights;
    QString refAudio;    // 绝对路径，交给 api_v2
    QString promptText;  // 参考音频原文
    QString promptLang = QStringLiteral("ja");
    QString qwenVoice;   // 千问复刻音色 ID
    QString language = QStringLiteral("ja");
    QString cloudAudio;
    QString cloudPreview;
    QString source = QStringLiteral("local");
};

/** 一句待合成的文本 */
struct SpeechChunk {
    QString text;
    QString lang; // zh / ja / en ...
};

/**
 * GPT-SoVITS api_v2 客户端：
 *   POST {endpoint}/tts  →  WAV 字节
 * 只负责“合成”，播放交给 AudioPlayer。
 */
#include "config/Config.h"

class TtsClient : public QObject {
    Q_OBJECT

public:
    explicit TtsClient(QObject* parent = nullptr);

    void setEndpoint(const QString& endpoint) { m_endpoint = endpoint; }
    void setProvider(const QString& provider, const QwenTtsConfig& qwen) { m_provider = provider; m_qwen = qwen; }
    QString provider() const { return m_provider; }
    QString endpoint() const { return m_endpoint; }

    void setProfiles(const QVector<VoiceProfile>& profiles) { m_profiles = profiles; }

    VoiceProfile profile(const QString& id) const;

    /** 合成一句；回调返回 WAV（失败时 error 非空） */
    void synthesize(const QString& text, const QString& lang, const VoiceProfile& profile,
                    double speed, std::function<void(const QByteArray& wav, const QString& error)> callback);

    /** 探测服务是否在线（GET /control） */

    /** 确保当前加载的是该档案的权重；不一样时先切换再回调 */
    void ensureWeights(const VoiceProfile& profile, std::function<void(const QString& error)> callback);

private:
    void synthesizeQwen(const QString& text, const QString& lang, double speed, const QString& voiceOverride,
                        std::function<void(const QByteArray&, const QString&)> callback);

    QString m_provider = QStringLiteral("gptsovits");
    QwenTtsConfig m_qwen;
    QNetworkAccessManager* m_net = nullptr;
    QString m_endpoint = QStringLiteral("http://127.0.0.1:9880");
    QVector<VoiceProfile> m_profiles;
    QString m_loadedGpt;
    QString m_loadedSovits;
};
