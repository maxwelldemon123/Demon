#include "AudioRecorder.h"

#include "../util/Log.h"

#include <QAudioDevice>
#include <QAudioSource>
#include <QBuffer>
#include <QMediaDevices>
#include <QTimer>
#include <QtEndian>

namespace {

QByteArray makeWav(const QByteArray& pcm, int sampleRate, int channels, int bits)
{
    QByteArray wav;
    wav.reserve(pcm.size() + 44);
    const int byteRate = sampleRate * channels * bits / 8;

    auto put32 = [&wav](quint32 v) {
        char b[4];
        qToLittleEndian(v, b);
        wav.append(b, 4);
    };
    auto put16 = [&wav](quint16 v) {
        char b[2];
        qToLittleEndian(v, b);
        wav.append(b, 2);
    };

    wav.append("RIFF", 4);
    put32(36 + pcm.size());
    wav.append("WAVE", 4);
    wav.append("fmt ", 4);
    put32(16);
    put16(1);
    put16(static_cast<quint16>(channels));
    put32(static_cast<quint32>(sampleRate));
    put32(static_cast<quint32>(byteRate));
    put16(static_cast<quint16>(channels * bits / 8));
    put16(static_cast<quint16>(bits));
    wav.append("data", 4);
    put32(static_cast<quint32>(pcm.size()));
    wav.append(pcm);
    return wav;
}

} // namespace

AudioRecorder::AudioRecorder(QObject* parent)
    : QObject(parent)
{
}

AudioRecorder::~AudioRecorder()
{
    if (m_source) {
        m_source->stop();
    }
}

void AudioRecorder::record(int seconds, std::function<void(const QByteArray&, const QString&)> callback)
{
    if (m_source) {
        callback(QByteArray(), QStringLiteral("正在录音"));
        return;
    }
    const QAudioDevice device = QMediaDevices::defaultAudioInput();
    if (device.isNull()) {
        callback(QByteArray(), QStringLiteral("没有可用的麦克风"));
        return;
    }

    m_format.setSampleRate(16000);
    m_format.setChannelCount(1);
    m_format.setSampleFormat(QAudioFormat::Int16);

    m_callback = std::move(callback);
    m_buffer = new QBuffer(this);
    m_buffer->open(QIODevice::WriteOnly);

    m_source = new QAudioSource(device, m_format, this);
    m_source->start(m_buffer);
    Log::info(QStringLiteral("开始录音 %1 秒（%2）").arg(seconds).arg(device.description()));

    m_stopTimer = new QTimer(this);
    m_stopTimer->setSingleShot(true);
    m_stopTimer->setInterval(seconds * 1000);
    connect(m_stopTimer, &QTimer::timeout, this, [this]() {
        if (!m_source) {
            return;
        }
        m_source->stop();
        m_source->deleteLater();
        m_source = nullptr;
        m_stopTimer->deleteLater();
        m_stopTimer = nullptr;

        const QByteArray pcm = m_buffer->data();
        m_buffer->deleteLater();
        m_buffer = nullptr;

        auto callback = m_callback;
        m_callback = nullptr;
        if (pcm.isEmpty()) {
            Log::warn(QStringLiteral("录音为空"));
            callback(QByteArray(), QStringLiteral("没有录到声音"));
            return;
        }
        Log::info(QStringLiteral("录音完成：%1 字节").arg(pcm.size()));
        callback(makeWav(pcm, m_format.sampleRate(), m_format.channelCount(), 16), QString());
    });
    m_stopTimer->start();
}
