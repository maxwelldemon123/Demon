#pragma once

#include <QAudioFormat>
#include <QByteArray>
#include <QObject>

#include <functional>

class QAudioSource;
class QBuffer;
class QTimer;

/**
 * 麦克风录音（16kHz / 单声道 / 16bit），录满指定秒数后返回 WAV 字节。
 */
class AudioRecorder : public QObject {
    Q_OBJECT

public:
    explicit AudioRecorder(QObject* parent = nullptr);
    ~AudioRecorder() override;

    void record(int seconds, std::function<void(const QByteArray& wav, const QString& error)> callback);
    bool recording() const { return m_source != nullptr; }

private:
    QAudioSource* m_source = nullptr;
    QBuffer* m_buffer = nullptr;
    QTimer* m_stopTimer = nullptr;
    QAudioFormat m_format;
    std::function<void(const QByteArray&, const QString&)> m_callback;
};
