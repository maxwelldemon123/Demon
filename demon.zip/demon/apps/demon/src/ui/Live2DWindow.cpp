#include "Live2DWindow.h"

#include <QAction>
#include <QCursor>
#include <QKeyEvent>
#include <QMenu>
#include <QMouseEvent>
#include <QOpenGLContext>
#include <QOpenGLFunctions>
#include <QSurfaceFormat>

#include <algorithm>
#include <cmath>

#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <dwmapi.h>
#endif

#include "AppOpenGLWrapper.hpp"
#include "live2d/NativeLive2DModel.h"
#include "live2d/cubism/CubismSupport.h"
#include "util/Log.h"

QSurfaceFormat Live2DWindow::live2dSurfaceFormat()
{
    QSurfaceFormat format;
    format.setRenderableType(QSurfaceFormat::OpenGL);
    // 注意：不要用 3.2 Core —— shader 是 #version 120，core profile 下会编译失败。
    format.setVersion(2, 1);
    format.setProfile(QSurfaceFormat::NoProfile);
    format.setAlphaBufferSize(8);
    format.setDepthBufferSize(0);
    format.setStencilBufferSize(8);
    format.setSwapBehavior(QSurfaceFormat::DoubleBuffer);
    format.setSwapInterval(1);   // 交给 vsync 封顶，渲染循环自己驱动
    return format;
}

void Live2DWindow::configureSurfaceFormat()
{
    QSurfaceFormat::setDefaultFormat(live2dSurfaceFormat());
}

QImage Live2DWindow::grabFrame()
{
    if (!m_glReady || context() == nullptr) {
        return QImage();
    }
    makeCurrent();
    const int w = std::max(1, static_cast<int>(std::lround(width() * devicePixelRatio())));
    const int h = std::max(1, static_cast<int>(std::lround(height() * devicePixelRatio())));
    QImage image(w, h, QImage::Format_RGBA8888);
    QOpenGLFunctions* functions = context()->functions();
    functions->glPixelStorei(GL_PACK_ALIGNMENT, 4);
    functions->glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, image.bits());
    doneCurrent();
    return image.mirrored(false, true);
}

Live2DWindow::Live2DWindow(QWindow* parent)
    : QOpenGLWindow(QOpenGLWindow::NoPartialUpdate, parent)
{
    setTitle(QStringLiteral("Demon Live2D"));
    setFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Window
             | Qt::NoDropShadowWindowHint);
    setFormat(live2dSurfaceFormat());
    resize(480, 720);

    // 真正节奏由 paintGL 末尾的 requestUpdate()（vsync 驱动）控制；
    // 这个定时器只做兜底心跳，避免窗口短暂不可见后循环停死。
    // 注意：不能用 33ms 的 QTimer 当主循环 —— 在后台窗口上 Windows 会把
    // WM_TIMER 限流到 ~13Hz（实测 Demon 里桌宠只有 12.7fps，而独立进程 probe 有 30fps）。
    m_timer.setInterval(250);
    m_timer.setTimerType(Qt::CoarseTimer);
    connect(&m_timer, &QTimer::timeout, this, &Live2DWindow::onFrame);

    // 初始整窗穿透：等第一帧的 alpha 命中检测发现光标在模型上，再切回可交互。
    setClickThrough(true);
}

Live2DWindow::~Live2DWindow()
{
    m_timer.stop();
    cleanupGl();
}

bool Live2DWindow::loadModel(const QString& model3Path)
{
    m_pendingModelPath = model3Path;
    if (m_glReady) {
        loadPendingModel();
    }
    return m_model && m_model->isLoaded();
}

bool Live2DWindow::ready() const
{
    return m_model && m_model->isLoaded();
}

void Live2DWindow::loadPendingModel()
{
    if (!m_glReady || m_pendingModelPath.isEmpty() || m_cleaned) {
        return;
    }

    const QString path = m_pendingModelPath;
    m_pendingModelPath.clear();

    if (!m_model) {
        m_model = std::make_unique<NativeLive2DModel>();
    }
    if (!m_model->load(path)) {
        Log::error(QStringLiteral("[live2d] 模型加载失败: %1 (%2)").arg(path, m_model->lastError()));
        return;
    }

    m_model->setScaleMode(m_halfBody);
    m_model->setMouth(m_pendingMouth);
    if (!m_pendingExpression.isEmpty()) {
        const QString expression = m_pendingExpression;
        m_pendingExpression.clear();
        m_model->setExpression(expression);
    }

    m_frameClock.restart();
    Log::info(QStringLiteral("[live2d] Live2DWindow 就绪，画布 %1x%2")
                  .arg(m_model->canvasSize().width())
                  .arg(m_model->canvasSize().height()));
}

void Live2DWindow::applyDwmTransparency()
{
#ifdef Q_OS_WIN
    if (m_dwmApplied) {
        return;
    }
    HWND hwnd = reinterpret_cast<HWND>(winId());
    if (!hwnd) {
        return;
    }
    // Qt 给半透明窗口加了 WS_EX_LAYERED。分层窗口的 OpenGL 内容必须走
    // UpdateLayeredWindow 的 DIB 拷贝，实测把帧率压到 ~10fps。
    // 透明改由下面的 DWM blur-behind 负责，这里把 LAYERED 去掉。
    LONG ex = GetWindowLongW(hwnd, GWL_EXSTYLE);
    if (ex & WS_EX_LAYERED) {
        SetWindowLongW(hwnd, GWL_EXSTYLE, ex & ~WS_EX_LAYERED);
        Log::info(QStringLiteral("[live2d] 已移除 WS_EX_LAYERED（避免分层窗口的 DIB 拷贝）"));
    }
    DWM_BLURBEHIND blur = {};
    blur.dwFlags = DWM_BB_ENABLE | DWM_BB_BLURREGION;
    blur.fEnable = TRUE;
    blur.hRgnBlur = CreateRectRgn(0, 0, -1, -1);
    DwmEnableBlurBehindWindow(hwnd, &blur);
    if (blur.hRgnBlur) {
        DeleteObject(blur.hRgnBlur);
    }
    m_dwmApplied = true;
    Log::info(QStringLiteral("[live2d] DWM blur-behind 已启用（透明合成交给 DWM）"));
#endif
}

void Live2DWindow::initializeGL()
{
    QOpenGLContext* glContext = context();
    QOpenGLFunctions* functions = glContext ? glContext->functions() : nullptr;
    if (functions == nullptr) {
        Log::error(QStringLiteral("[live2d] 无法获取 QOpenGLFunctions"));
        return;
    }
    functions->initializeOpenGLFunctions();
    AppOpenGLWrapper::get()->initializeOpenGLFunctions();

    if (!CubismSupport::initialize()) {
        Log::error(QStringLiteral("[live2d] CubismFramework 初始化失败"));
        return;
    }

    connect(glContext, &QOpenGLContext::aboutToBeDestroyed, this, &Live2DWindow::cleanupGl,
            Qt::DirectConnection);

    m_glReady = true;
    m_cleaned = false;
    applyDwmTransparency();
    startFrameClock();

    const char* rendererName = reinterpret_cast<const char*>(functions->glGetString(GL_RENDERER));
    const char* glslVersion =
        reinterpret_cast<const char*>(functions->glGetString(GL_SHADING_LANGUAGE_VERSION));
    Log::info(QStringLiteral("[live2d] OpenGL: %1 | GLSL: %2")
                  .arg(QString::fromUtf8(rendererName ? rendererName : "?"),
                       QString::fromUtf8(glslVersion ? glslVersion : "?")));

    loadPendingModel();

    m_fpsClock.start();
    m_paintFrames = 0;
    m_frameClock.start();
    m_timer.start();
}

void Live2DWindow::resizeGL(int w, int h)
{
    Q_UNUSED(w);
    Q_UNUSED(h);
    // 视口每帧按物理像素重设，这里不做缓存。
}

void Live2DWindow::paintGL()
{
    if (m_cleaned) {
        return;
    }

    // ---- 渲染循环节奏 ----
    // requestUpdate() 是 vsync 驱动的（不受 WM_TIMER 限流），每次画完再排下一帧；
    // 用 m_frameIntervalMs 把帧率压到目标值（默认 33ms ≈ 30fps）。
    // 自驱动渲染循环：每帧画完后用 requestUpdate() 排下一帧，由 vsync 封顶（≈60fps）。
    // 实测：用 elapsed/QTimer/计数器做节流都会把这条链路打断，掉到 9–12fps，别再加。

    QOpenGLContext* glContext = context();
    QOpenGLFunctions* functions = glContext ? glContext->functions() : nullptr;
    if (functions == nullptr) {
        return;
    }

    // 推进模型（原来放在定时器里，现在跟渲染同频；dt 用真实间隔）
    if (m_model && m_model->isLoaded()) {
        const float dt = m_frameClock.isValid()
                             ? static_cast<float>(m_frameClock.restart()) / 1000.0f
                             : 1.0f / 30.0f;
        ++m_tickFrames;
        m_updateClock.start();
        m_model->update(dt);
        m_updateMilliseconds += static_cast<double>(m_updateClock.nsecsElapsed()) / 1.0e6;
    } else {
        m_frameClock.restart();
    }

    // 先复位裁剪/深度状态再清屏：Cubism 的裁剪遮罩会用 scissor，
    // 没复位就清屏会让画面残留。
    functions->glDisable(GL_DEPTH_TEST);
    functions->glDisable(GL_STENCIL_TEST);
    functions->glDisable(GL_SCISSOR_TEST);
    functions->glDisable(GL_CULL_FACE);
    functions->glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    functions->glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    functions->glClear(GL_COLOR_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    functions->glEnable(GL_BLEND);
    functions->glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

    if (m_model && m_model->isLoaded()) {
        const int physicalWidth =
            std::max(1, static_cast<int>(std::lround(width() * devicePixelRatio())));
        const int physicalHeight =
            std::max(1, static_cast<int>(std::lround(height() * devicePixelRatio())));
        functions->glViewport(0, 0, physicalWidth, physicalHeight);

        m_drawClock.start();
        m_model->draw(physicalWidth, physicalHeight);
        m_drawMilliseconds += static_cast<double>(m_drawClock.nsecsElapsed()) / 1.0e6;

        // 命中检测：在刚画完的这一帧读光标处 1 像素 alpha（同帧内才有效）。
        if (!m_dragging) {
            // 命中检测必须用「物理像素」算，否则 175% 缩放下会取错像素，
            // 透明区被判成模型、点击就穿不过去。这里直接用 Win32 的物理坐标。
            int localX = 0;
            int localY = 0;
            bool inside = false;
#ifdef Q_OS_WIN
            POINT cursorPoint;
            RECT windowRect;
            if (GetCursorPos(&cursorPoint) && GetWindowRect(reinterpret_cast<HWND>(winId()), &windowRect)) {
                localX = cursorPoint.x - windowRect.left;
                localY = cursorPoint.y - windowRect.top;
                inside = localX >= 0 && localY >= 0 && localX < physicalWidth && localY < physicalHeight;
            }
#else
            const QPoint local = QCursor::pos() - position();
            localX = static_cast<int>(std::lround(local.x() * devicePixelRatio()));
            localY = static_cast<int>(std::lround(local.y() * devicePixelRatio()));
            inside = local.x() >= 0 && local.y() >= 0 && local.x() < width() && local.y() < height();
#endif
            const int px = localX;
            const int py = physicalHeight - localY - 1;
            bool hit = false;
            if (inside && px >= 0 && py >= 0 && px < physicalWidth && py < physicalHeight) {
                unsigned char rgba[4] = {0, 0, 0, 0};
                functions->glReadPixels(px, py, 1, 1, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
                m_hitAlpha = rgba[3];
                hit = rgba[3] > (m_hitInteractive ? 6 : 12);
            } else {
                m_hitAlpha = 0;
            }
            if (hit != m_hitInteractive) {
                m_hitInteractive = hit;
                setClickThrough(!hit);
            }
        }
    }

    ++m_paintFrames;
    const qint64 elapsed = m_fpsClock.elapsed();
    if (elapsed >= 1000) {
        m_fps = m_paintFrames * 1000.0 / static_cast<double>(elapsed);
        m_drawMsPerFrame = m_drawMilliseconds / std::max(1, m_paintFrames);
        m_updateMsPerFrame = m_updateMilliseconds / std::max(1, m_tickFrames);
        m_paintFrames = 0;
        m_drawMilliseconds = 0.0;
        m_updateMilliseconds = 0.0;
        m_fpsClock.restart();
        if (++m_logTicks % 5 == 0) {
            Log::info(QStringLiteral("[live2d] FPS=%1 tick=%2 draw=%3ms update=%4ms 穿透=%5 exposed=%6 vis=%7 dpr=%8")
                          .arg(m_fps, 0, 'f', 1)
                          .arg(m_tickFrames)
                          .arg(m_drawMsPerFrame, 0, 'f', 2)
                          .arg(m_updateMsPerFrame, 0, 'f', 2)
                          .arg(m_clickThrough ? 1 : 0));
            m_tickFrames = 0;
        }
    }

}

void Live2DWindow::startFrameClock()
{
    if (m_clockThread) {
        return;
    }
    // 用独立线程按毫秒节奏投递 update()。
    // 不能用 GUI 线程的 QTimer：Windows 会把后台窗口的 WM_TIMER 限流到 ~13Hz，
    // 实测 Demon 里只有 12.7fps，而同一套渲染代码在独立进程里有 26–30fps。
    m_clockThread = QThread::create([this]() {
        QElapsedTimer pace;
        pace.start();
        while (!QThread::currentThread()->isInterruptionRequested()) {
            const int wait = m_frameIntervalMs - static_cast<int>(pace.elapsed());
            if (wait > 0) {
                QThread::msleep(static_cast<unsigned long>(wait));
            }
            pace.restart();
            if (m_cleaned || !isExposed()) {
                continue;
            }
            QMetaObject::invokeMethod(this, [this]() { update(); }, Qt::QueuedConnection);
        }
    });
    m_clockThread->start();
}

void Live2DWindow::exposeEvent(QExposeEvent* event)
{
    QOpenGLWindow::exposeEvent(event);
    if (isExposed()) {
        applyDwmTransparency();
    }
}

void Live2DWindow::onFrame()
{
    // 兜底心跳：正常情况下渲染循环由 paintGL 里的 requestUpdate() 自驱动，
    // 这里只在循环意外停下时把 update 重新踢起来。
    if (m_cleaned || !m_glReady) {
        return;
    }
    if (!m_frameClock.isValid()) {
        m_frameClock.start();
    }
    update();
}

void Live2DWindow::setFrameInterval(int milliseconds)
{
    m_frameIntervalMs = std::max(1, milliseconds);
}

void Live2DWindow::setClickThrough(bool on)
{
#ifdef Q_OS_WIN
    HWND hwnd = reinterpret_cast<HWND>(winId());
    if (hwnd) {
        LONG ex = GetWindowLongW(hwnd, GWL_EXSTYLE);
        if (on) {
            ex |= WS_EX_TRANSPARENT | WS_EX_NOACTIVATE;
        } else {
            ex &= ~(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
        }
        SetWindowLongW(hwnd, GWL_EXSTYLE, ex);
    }
#endif
    if (m_clickThrough != on) {
        m_clickThrough = on;
        Log::info(QStringLiteral("[live2d] 点击穿透 %1").arg(on ? 1 : 0));
    }
}



void Live2DWindow::clearOneShotExpression()
{
    if (m_model && m_model->isLoaded()) {
        m_model->clearOneShotExpression();
        update();
    }
}


void Live2DWindow::setExpression(const QString& expFileBaseNameOrPath)
{
    if (m_model && m_model->isLoaded()) {
        m_model->setExpression(expFileBaseNameOrPath);
        return;
    }
    m_pendingExpression = expFileBaseNameOrPath;
}

void Live2DWindow::togglePersistentExpression(const QString& name)
{
    if (m_model && m_model->isLoaded()) {
        m_model->togglePersistentExpression(name);
    }
}

void Live2DWindow::setOneShotExpression(const QString& name)
{
    if (m_model && m_model->isLoaded()) {
        m_model->setOneShotExpression(name);
    }
}

void Live2DWindow::clearAllExpressions()
{
    if (m_model && m_model->isLoaded()) {
        m_model->clearOneShotExpression();
        m_model->clearPersistentExpressions();
    }
}

void Live2DWindow::playAction(const QString& name)
{
    if (m_model && m_model->isLoaded()) {
        m_model->playAction(name);
    }
}
void Live2DWindow::clearExpression()
{
    m_pendingExpression.clear();
    if (m_model && m_model->isLoaded()) {
        m_model->clearExpression();
    }
}

void Live2DWindow::setMouth(double value)
{
    m_pendingMouth = value;
    if (m_model && m_model->isLoaded()) {
        m_model->setMouth(value);
    }
}

void Live2DWindow::setHalfBody(bool half)
{
    m_halfBody = half;
    if (m_model && m_model->isLoaded()) {
        m_model->setScaleMode(half);
        update();
    }
}

QSize Live2DWindow::canvasSize() const
{
    return m_model ? m_model->canvasSize() : QSize();
}

void Live2DWindow::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        m_dragging = true;
        m_dragGlobalStart = event->globalPosition().toPoint();
        m_dragWindowStart = position();
        event->accept();
        return;
    }
    QOpenGLWindow::mousePressEvent(event);
}

void Live2DWindow::mouseMoveEvent(QMouseEvent* event)
{
    if (m_dragging && (event->buttons() & Qt::LeftButton)) {
        const QPoint delta = event->globalPosition().toPoint() - m_dragGlobalStart;
        setPosition(m_dragWindowStart + delta);
        event->accept();
        return;
    }
    QOpenGLWindow::mouseMoveEvent(event);
}

void Live2DWindow::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton && m_dragging) {
        m_dragging = false;
        event->accept();
        return;
    }
    if (event->button() == Qt::RightButton) {
        QMenu menu;
        QAction* closeAction = menu.addAction(QStringLiteral("关闭桌宠"));
        QAction* fullAction = menu.addAction(QStringLiteral("全身"));
        QAction* halfAction = menu.addAction(QStringLiteral("半身"));
        fullAction->setCheckable(true);
        halfAction->setCheckable(true);
        fullAction->setChecked(!m_halfBody);
        halfAction->setChecked(m_halfBody);
        QAction* picked = menu.exec(QCursor::pos());
        if (picked == closeAction) {
            close();
        } else if (picked == fullAction) {
            setHalfBody(false);
        } else if (picked == halfAction) {
            setHalfBody(true);
        }
        event->accept();
        return;
    }
    QOpenGLWindow::mouseReleaseEvent(event);
}


void Live2DWindow::wheelEvent(QWheelEvent* event)
{
    // 滚轮调整桌宠大小（保持在屏幕上的中心位置）
    const int steps = event->angleDelta().y() / 120;
    if (steps == 0) {
        return;
    }
    const double factor = std::pow(1.08, steps);
    const int newWidth = std::clamp(static_cast<int>(std::lround(width() * factor)), 320, 1100);
    const int newHeight = std::clamp(static_cast<int>(std::lround(newWidth * 1.5)), 480, 1650);
    // 钳制在屏幕可用区域内，避免放大后跑到屏幕外
    QScreen* targetScreen = screen();
    if (targetScreen == nullptr) {
        targetScreen = QGuiApplication::screenAt(position());
    }
    int finalWidth = newWidth;
    int finalHeight = newHeight;
    QRect available = targetScreen ? targetScreen->availableGeometry() : QRect();
    if (!available.isEmpty()) {
        finalWidth = std::min(finalWidth, available.width());
        finalHeight = std::min(finalHeight, available.height());
    }

    const QPoint center = position() + QPoint(width() / 2, height() / 2);
    resize(finalWidth, finalHeight);
    QPoint topLeft = center - QPoint(finalWidth / 2, finalHeight / 2);
    if (!available.isEmpty()) {
        topLeft.setX(std::max(available.left(), std::min(topLeft.x(), available.right() - finalWidth + 1)));
        topLeft.setY(std::max(available.top(), std::min(topLeft.y(), available.bottom() - finalHeight + 1)));
    }
    setPosition(topLeft);
    update();
    event->accept();
}
void Live2DWindow::keyPressEvent(QKeyEvent* event)
{
    if (event->key() == Qt::Key_Escape) {
        close();
        event->accept();
        return;
    }
    QOpenGLWindow::keyPressEvent(event);
}

void Live2DWindow::cleanupGl()
{
    if (m_cleaned) {
        return;
    }
    m_cleaned = true;
    m_timer.stop();
    if (m_clockThread) {
        m_clockThread->requestInterruption();
        m_clockThread->wait(500);
        delete m_clockThread;
        m_clockThread = nullptr;
    }

    if (!m_glReady) {
        return;
    }
    makeCurrent();
    if (m_model) {
        m_model->release();
        m_model.reset();
    }
    CubismSupport::shutdown();
    doneCurrent();
    AppOpenGLWrapper::release();
    Log::info(QStringLiteral("[live2d] GL 资源已清理"));
}
