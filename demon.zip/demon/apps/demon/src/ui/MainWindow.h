#pragma once

#include <QMainWindow>
#include <QMap>

class AppController;
class QLabel;
class QListWidget;
class QTreeWidget;
class QStackedWidget;
class QTableWidget;
class QLineEdit;
class QSpinBox;
class QTimer;
class QSlider;
class QComboBox;
class QPushButton;
class QListWidget;
class QTreeWidget;
class QTabWidget;
class QCheckBox;

/**
 * Demon 主窗口：仿 Electron 版的左侧导航 + 右侧面板。
 * 面板：状态 / 接口 / 启动 / 语音 / 角色 / 日志
 */
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(AppController* controller, QWidget* parent = nullptr);

protected:
    void closeEvent(QCloseEvent* event) override;

private:
    void buildUi();
    QWidget* buildDashboard();
    QWidget* buildLauncherPage();
    QWidget* buildVoicePage();
    QWidget* buildCharacterPage();
    QWidget* buildLive2dPage();
    QWidget* buildLocalPetPage();
    QListWidget* m_petExpressionList = nullptr;

    void refreshStatus();
    void refreshApiTable();
    void refreshVoiceTable();
    void refreshCharacterPage();
    void refreshVoicePage();

    void saveApiTable();
    void saveVoiceTable();

    AppController* m_controller = nullptr;

    QTreeWidget* m_nav = nullptr;
    QStackedWidget* m_stack = nullptr;
    QLabel* m_footer = nullptr;

    // 状态页
    QLabel* m_epLabel = nullptr;
    QLabel* m_upstreamLabel = nullptr;
    QLabel* m_modelLabel = nullptr;
    QLabel* m_voiceLabel = nullptr;
    QLabel* m_queueLabel = nullptr;

    // 接口页
    QTableWidget* m_apiTable = nullptr;
    QLineEdit* m_defaultUpstream = nullptr;

    // 启动页
    QLineEdit* m_stPath = nullptr;
    QSpinBox* m_stPort = nullptr;
    QLabel* m_stState = nullptr;
    QLineEdit* m_gsvPath = nullptr;
    QLabel* m_gsvState = nullptr;

    // 语音页（1.2）
    QTabWidget* m_voiceTabs = nullptr;
    QTabWidget* m_live2dTabs = nullptr;
    QCheckBox* m_translateCheck = nullptr;
    QTableWidget* m_bindTable = nullptr;
    QLineEdit* m_gsvEndpoint = nullptr;
    QSlider* m_speedSlider = nullptr;
    QTableWidget* m_localVoiceTable = nullptr;
    QComboBox* m_cloudModel = nullptr;
    QLineEdit* m_cloudKey = nullptr;
    QTableWidget* m_cloudVoiceTable = nullptr;
    QLabel* m_voiceMsg = nullptr;
    QPushButton* m_emotionRecord = nullptr;
    QLabel* m_emotionStatus = nullptr;
    QLabel* m_emotionTranscript = nullptr;
    QListWidget* m_emotionHistory = nullptr;

    // 旧语音表（保留给旧刷新函数）
    QTableWidget* m_voiceTable = nullptr;
    QLabel* m_voiceState = nullptr;

    // 角色页（1.2）
    QListWidget* m_charList = nullptr;
    QLabel* m_charTitle = nullptr;
    QPushButton* m_localBtn = nullptr;
    QPushButton* m_cloudBtn = nullptr;
    QTableWidget* m_charVoiceTable = nullptr;
    QTableWidget* m_charModelTable = nullptr;
    QLabel* m_charState = nullptr;
    QString m_currentCharacter;

    QComboBox* m_outDevice = nullptr;
    QSlider* m_volSlider = nullptr;

    // Live2D 页
    QLabel* m_l2dState = nullptr;
    QLabel* m_l2dModel = nullptr;
    QLabel* m_l2dError = nullptr;
    QLabel* m_l2dEndpoint = nullptr;
    QSlider* m_mouthSlider = nullptr;
    QTableWidget* m_emotionTable = nullptr;
    QTableWidget* m_hotkeyTable = nullptr;
    QCheckBox* m_petCheck = nullptr;
    QLineEdit* m_petColor = nullptr;

    // 启动页：VTube Studio
    QLineEdit* m_vtsPath = nullptr;
    QLabel* m_vtsState = nullptr;


    QTimer* m_timer = nullptr;
};
