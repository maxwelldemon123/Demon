#pragma once

#include <QColor>
#include <QImage>
#include <QPoint>
#include <QTimer>
#include <QWidget>

/**
 * 桌宠窗口：定时用 PrintWindow 抓取 VTube Studio 窗口，
 * 把背景色抠成透明后画到一个无边框置顶窗口里（类似 OBS 窗口采集 + 色键）。
 */
class PetWindow : public QWidget {
    Q_OBJECT

public:
    explicit PetWindow(QWidget* parent = nullptr);

    bool start(quintptr sourceWindow, const QColor& keyColor);
    void stop();
    bool active() const { return m_active; }

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;

private:
    bool captureFrame();

    QTimer m_timer;
    quintptr m_source = 0;
    QColor m_key = QColor(0, 0, 0);
    QImage m_frame;
    bool m_active = false;
    bool m_dragging = false;
    QPoint m_dragOffset;
};
