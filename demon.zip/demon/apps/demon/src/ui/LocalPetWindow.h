#pragma once

#include <QPoint>
#include <QWebEngineView>

class QTimer;

/**
 * 本地桌宠窗口：QWebEngineView 直接作为顶层透明窗口（不再套 QWidget）。
 */
class LocalPetWindow : public QWebEngineView {
    Q_OBJECT

public:
    explicit LocalPetWindow(QWidget* parent = nullptr);

    bool start(const QString& modelDir, const QString& modelFile);
    void stop();
    void setExpression(const QString& expressionFile);
    void setMouth(double value);
    void setClickThrough(bool on);

protected:
    bool eventFilter(QObject* watched, QEvent* event) override;

private:
    void attachInputFilter();

    QWidget* m_inputTarget = nullptr;
    QTimer* m_fpsTimer = nullptr;
    QPoint m_dragOffset;
    bool m_dragging = false;
    bool m_ready = false;
    int m_expressionLogCount = 0;
};
