#include "PetWindow.h"

#include "../util/Log.h"

#include <QMouseEvent>
#include <QPainter>

#ifdef Q_OS_WIN
#include <windows.h>
#include <dwmapi.h>
#endif

PetWindow::PetWindow(QWidget* parent)
    : QWidget(parent)
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Tool);
    setAttribute(Qt::WA_TranslucentBackground, true);
    setAttribute(Qt::WA_ShowWithoutActivating, true);
    setWindowTitle(QStringLiteral("Demon Pet"));

    m_timer.setInterval(50);
    connect(&m_timer, &QTimer::timeout, this, [this]() { captureFrame(); });
}

bool PetWindow::start(quintptr sourceWindow, const QColor& keyColor)
{
    m_source = sourceWindow;
    m_key = keyColor;
    m_active = true;
    const bool first = captureFrame();
    if (!first) {
        m_active = false;
        Log::warn(QStringLiteral("桌宠：首帧抓取失败（权限不足或窗口不可见）"));
        return false;
    }
    m_timer.start();
    Log::info(QStringLiteral("桌宠窗口启动：src=%1 key=%2 timer=%3")
                  .arg(m_source).arg(m_key.name()).arg(m_timer.isActive() ? 1 : 0));
    show();
    raise();
    return true;
}

void PetWindow::stop()
{
    m_active = false;
    m_timer.stop();
    hide();
}

bool PetWindow::captureFrame()
{
#ifdef Q_OS_WIN
    HWND hwnd = reinterpret_cast<HWND>(m_source);
    if (!hwnd || !IsWindow(hwnd) || IsIconic(hwnd)) {
        return false;
    }
    RECT rect{};
    if (!GetWindowRect(hwnd, &rect)) {
        return false;
    }
    const int width = rect.right - rect.left;
    const int height = rect.bottom - rect.top;
    if (width <= 0 || height <= 0 || width > 4000 || height > 4000) {
        return false;
    }

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = width;
    bmi.bmiHeader.biHeight = -height;   // top-down
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    HDC screen = GetDC(nullptr);
    HDC mem = CreateCompatibleDC(screen);
    HBITMAP bitmap = CreateDIBSection(mem, &bmi, DIB_RGB_COLORS, &bits, nullptr, 0);
    if (!bitmap || !bits) {
        if (bitmap) DeleteObject(bitmap);
        if (mem) DeleteDC(mem);
        ReleaseDC(nullptr, screen);
        return false;
    }

    HGDIOBJ old = SelectObject(mem, bitmap);
    const BOOL ok = PrintWindow(hwnd, mem, 2 /* PW_RENDERFULLCONTENT */);
    if (!ok) {
        SelectObject(mem, old);
        DeleteObject(bitmap);
        DeleteDC(mem);
        ReleaseDC(nullptr, screen);
        return false;
    }

    // 注意：bits 属于 bitmap，必须在 DeleteObject 之前读完
    QImage image(width, height, QImage::Format_ARGB32);
    const QColor key = m_key;
    const int keyR = key.red();
    const int keyG = key.green();
    const int keyB = key.blue();
    const auto* src = static_cast<const quint32*>(bits);
    for (int y = 0; y < height; ++y) {
        auto* dst = reinterpret_cast<QRgb*>(image.scanLine(y));
        for (int x = 0; x < width; ++x) {
            const QRgb pixel = src[y * width + x];
            const int dr = qRed(pixel) - keyR;
            const int dg = qGreen(pixel) - keyG;
            const int db = qBlue(pixel) - keyB;
            const int distance = dr * dr + dg * dg + db * db;
            dst[x] = distance < 2600 ? qRgba(0, 0, 0, 0) : qRgba(qRed(pixel), qGreen(pixel), qBlue(pixel), 255);
        }
    }

    SelectObject(mem, old);
    DeleteObject(bitmap);
    DeleteDC(mem);
    ReleaseDC(nullptr, screen);

    // 去掉 Windows 窗口的不可见边框（Win10/11 的 resize border）
    RECT frame{};
    if (SUCCEEDED(DwmGetWindowAttribute(hwnd, DWMWA_EXTENDED_FRAME_BOUNDS, &frame, sizeof(frame)))) {
        const int dx = frame.left - rect.left;
        const int dy = frame.top - rect.top;
        const int fw = frame.right - frame.left;
        const int fh = frame.bottom - frame.top;
        if (dx >= 0 && dy >= 0 && fw > 0 && fh > 0
            && dx + fw <= width && dy + fh <= height
            && (dx + dy + (width - dx - fw) + (height - dy - fh)) > 0) {
            image = image.copy(dx, dy, fw, fh);
        }
    }
    // DWM 边界仍可能留 1~2px 系统描边，再内缩一点
    if (image.width() > 8 && image.height() > 8) {
        image = image.copy(1, 2, image.width() - 2, image.height() - 3);
    }

    m_frame = image;
    if (size() != image.size()) {
        resize(image.size());
    }
    if (!isVisible()) {
        show();
    }
    update();
    return true;
#else
    return false;
#endif
}

void PetWindow::paintEvent(QPaintEvent*)
{
    static int painted = 0;
    if (painted++ < 3) {
        Log::info(QStringLiteral("桌宠窗口 paint #%1 size=%2x%3 frame=%4")
                      .arg(painted).arg(width()).arg(height()).arg(m_frame.isNull() ? 0 : m_frame.width()));
    }
    QPainter painter(this);
    painter.setRenderHint(QPainter::SmoothPixmapTransform, true);
    if (!m_frame.isNull()) {
        painter.drawImage(rect(), m_frame);
    }
}

void PetWindow::mousePressEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        m_dragging = true;
        m_dragOffset = event->globalPosition().toPoint() - frameGeometry().topLeft();
    }
}

void PetWindow::mouseMoveEvent(QMouseEvent* event)
{
    if (m_dragging) {
        move(event->globalPosition().toPoint() - m_dragOffset);
    }
}

void PetWindow::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton) {
        m_dragging = false;
    }
}
