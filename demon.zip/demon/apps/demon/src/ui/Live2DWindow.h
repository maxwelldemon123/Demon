#pragma once

#include <QElapsedTimer>
#include <QImage>
#include <QOpenGLWindow>
#include <QPoint>
#include <QThread>
#include <QTimer>

#include <memory>

class NativeLive2DModel;

/**
 * 原生 Live2D 桌宠窗口。
 *
 * 用 QOpenGLWindow（不是 QOpenGLWidget）：半透明 QOpenGLWidget 会走
 * 「FBO → glReadPixels → CPU 合成」的慢路径，实测只有 ~13fps；
 * QOpenGLWindow 直接渲染到窗口表面，再由 DWM 按 alpha 合成。
 *
 * - 无边框 + 透明 + 置顶
 * - 左键拖动，Esc / 右键菜单关闭，右键菜单可切全身/半身
 * - 按帧间隔驱动 update + 重绘，鼠标位置做 alpha 命中检测，空白处点击穿透
 */
class Live2DWindow : public QOpenGLWindow {
    Q_OBJECT

public:
    explicit Live2DWindow(QWindow* parent = nullptr);
    ~Live2DWindow() override;

    static QSurfaceFormat live2dSurfaceFormat();

    /// 建议在 QApplication 创建前调用，统一默认 surface format（alpha=8）。
    static void configureSurfaceFormat();

    bool loadModel(const QString& model3Path);
    bool ready() const;

    void setExpression(const QString& expFileBaseNameOrPath);
    void togglePersistentExpression(const QString& name);
    void setOneShotExpression(const QString& name);
    void clearOneShotExpression();
    void clearAllExpressions();
    void playAction(const QString& name);
    void clearExpression();
    void setMouth(double value);
    void setHalfBody(bool half);
    bool isHalfBody() const { return m_halfBody; }

    void setFrameInterval(int milliseconds);

    void setClickThrough(bool on);
    bool isClickThrough() const { return m_clickThrough; }
    bool cursorOnModel() const { return m_hitInteractive; }

    double fps() const { return m_fps; }
    double drawMilliseconds() const { return m_drawMsPerFrame; }
    QSize canvasSize() const;

    /// 读取当前帧（物理像素，含 alpha），给自检/截图用。
    QImage grabFrame();

protected:
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;
    void exposeEvent(QExposeEvent* event) override;

    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    void wheelEvent(QWheelEvent* event) override;

private slots:
    void onFrame();
    void cleanupGl();

private:
    void loadPendingModel();
    void applyDwmTransparency();
    void startFrameClock();

    std::unique_ptr<NativeLive2DModel> m_model;
    QTimer m_timer;
    QThread* m_clockThread = nullptr;
    QElapsedTimer m_frameClock;
    QElapsedTimer m_fpsClock;
    QElapsedTimer m_drawClock;
    QElapsedTimer m_updateClock;

    QString m_pendingModelPath;
    QString m_pendingExpression;
    double m_pendingMouth = 0.0;

    bool m_glReady = false;
    bool m_cleaned = false;
    bool m_dwmApplied = false;
    bool m_halfBody = false;
    int m_frameIntervalMs = 33;

    int m_paintFrames = 0;
    int m_tickFrames = 0;
    double m_fps = 0.0;
    double m_drawMilliseconds = 0.0;
    double m_drawMsPerFrame = 0.0;
    double m_updateMilliseconds = 0.0;
    double m_updateMsPerFrame = 0.0;
    int m_logTicks = 0;
    int m_loopSkip = 7;

    bool m_dragging = false;
    QPoint m_dragGlobalStart;
    QPoint m_dragWindowStart;

    bool m_clickThrough = false;
    bool m_hitInteractive = false;
    int m_hitAlpha = 0;
};
