#include "MainWindow.h"

#include "app/AppController.h"
#include "voice/AudioRecorder.h"
#include "util/Log.h"

#include <QClipboard>
#include <QGuiApplication>
#include <QScrollBar>
#include <QAbstractItemView>
#include <QCheckBox>
#include <QInputDialog>
#include <QTabWidget>
#include <QCloseEvent>
#include <QComboBox>
#include <QCoreApplication>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFormLayout>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QScrollArea>
#include <QSlider>
#include <QProcess>
#include <QPushButton>
#include <QSpinBox>
#include <QStackedWidget>
#include <QTableWidget>
#include <QTime>
#include <QTimer>
#include <QTreeWidget>
#include <QUrl>
#include <QVBoxLayout>

namespace {

const char* kStyle = R"(
QWidget#sidebar { background:#17171f; }
QLabel#brand { color:#cbb8ff; font-size:20px; font-weight:700; padding:18px 14px 10px 16px; }
QListWidget#nav { background:transparent; border:none; color:#a9a9bd; font-size:13px; outline:none; }
QListWidget#nav::item { padding:11px 16px; border-left:3px solid transparent; }
QListWidget#nav::item:selected { color:#ffffff; background:#232333; border-left:3px solid #8b6cff; }
QListWidget#nav::item:hover { color:#ffffff; }
QTreeWidget#nav { background:transparent; border:none; color:#a9a9bd; font-size:13px; outline:none; }
QTreeWidget#nav::item { padding:7px 8px; border-left:3px solid transparent; }
QTreeWidget#nav::item:selected { color:#ffffff; background:#232333; border-left:3px solid #8b6cff; }
QTreeWidget#nav::item:hover { color:#ffffff; }
QTreeWidget#nav::branch { background:transparent; }
QListWidget#emotionHistory { background:#141420; color:#c9c9dd; border:1px solid #2c2c44; border-radius:6px; }
QWidget#content { background:#1e1e28; }
QLabel#pageTitle { color:#ffffff; font-size:17px; font-weight:600; }
QLabel#hint { color:#8d8da6; font-size:12px; }
QLabel#footer { color:#8d8da6; font-size:12px; padding:6px 12px; background:#17171f; }
QGroupBox { color:#c9c9de; border:1px solid #2f2f42; border-radius:8px; margin-top:12px; padding-top:8px; }
QGroupBox::title { subcontrol-origin: margin; left:12px; padding:0 4px; }
QLabel { color:#d6d6e6; }
QLineEdit, QSpinBox, QComboBox, QPlainTextEdit, QTableWidget {
    background:#262635; color:#e6e6f2; border:1px solid #34344a; border-radius:5px; padding:4px 6px;
}
QLineEdit:focus, QSpinBox:focus, QComboBox:focus { border:1px solid #8b6cff; }
QPushButton { background:#2c2c3f; color:#e6e6f2; border:1px solid #3a3a52; border-radius:6px; padding:6px 12px; }
QPushButton:hover { background:#3a3a52; }
QPushButton#primary { background:#7350ff; border:1px solid #8b6cff; }
QPushButton#primary:hover { background:#8b6cff; }
QHeaderView::section { background:#262635; color:#b9b9cf; border:none; padding:5px; }
QTableWidget::item { padding:3px; }
)";

QTableWidgetItem* item(const QString& text)
{
    auto* it = new QTableWidgetItem(text);
    return it;
}

} // namespace


namespace {

/** 打开浏览器（交给 controller，cmd start 优先） */
bool openInBrowser(AppController* controller, const QString& url)
{
    return controller->openExternalUrl(url);
}

} // namespace

MainWindow::MainWindow(AppController* controller, QWidget* parent)
    : QMainWindow(parent)
    , m_controller(controller)
{
    setWindowTitle(QStringLiteral("Demon"));
    resize(1000, 660);
    setStyleSheet(QString::fromUtf8(kStyle));
    buildUi();

    connect(m_controller, &AppController::uiDirty, this, [this]() { refreshStatus(); });

    m_timer = new QTimer(this);
    m_timer->setInterval(1500);
    connect(m_timer, &QTimer::timeout, this, [this]() {
        const bool st = AppController::portOpen(static_cast<quint16>(m_stPort->value()));
        const bool gsv = AppController::portOpen(9880);
        m_stState->setText(st ? QStringLiteral("● 运行中") : QStringLiteral("○ 未运行"));
        m_stState->setStyleSheet(st ? "color:#4ade80;" : "color:#8d8da6;");
        m_gsvState->setText(gsv ? QStringLiteral("● 运行中") : QStringLiteral("○ 未运行"));
        m_gsvState->setStyleSheet(gsv ? "color:#4ade80;" : "color:#8d8da6;");
        if (m_vtsState) {
            const bool vts = AppController::portOpen(m_controller->config().live2d.port);
            m_vtsState->setText(vts ? QStringLiteral("● 运行中（API %1）").arg(m_controller->config().live2d.port)
                                    : QStringLiteral("○ 未运行"));
            m_vtsState->setStyleSheet(vts ? "color:#4ade80;" : "color:#8d8da6;");
        }
        if (m_l2dModel) {
            const QString model = m_controller->currentModelName();
            m_l2dModel->setText(model.isEmpty() ? QStringLiteral("（未连接）")
                                                : QStringLiteral("%1（%2 个表情）").arg(model).arg(m_controller->availableExpressions().size()));
        }
        if (m_l2dState) {
            const QString state = m_controller->live2dStateName();
            m_l2dState->setText(state);
            const bool ready = state == QStringLiteral("ready");
            m_l2dState->setStyleSheet(ready ? "color:#4ade80;" : "color:#f59e0b;");
            if (m_l2dError) {
                m_l2dError->setText(m_controller->live2dError());
            }
        }
        if (m_emotionTable && m_emotionTable->rowCount() > 0) {
            static const QStringList ids = {
                QStringLiteral("happy"), QStringLiteral("excited"), QStringLiteral("shy"),
                QStringLiteral("love"), QStringLiteral("sad"), QStringLiteral("cry"),
                QStringLiteral("angry"), QStringLiteral("surprised"), QStringLiteral("confused"),
                QStringLiteral("think"), QStringLiteral("tease"), QStringLiteral("dark"),
                QStringLiteral("dizzy"), QStringLiteral("tired")};
            for (int r = 0; r < m_emotionTable->rowCount() && r < ids.size(); ++r) {
                const QString expr = m_controller->expressionForEmotion(ids.at(r));
                if (auto* item = m_emotionTable->item(r, 2)) {
                    item->setText(expr.isEmpty() ? QStringLiteral("（无）") : expr);
                }
            }
        }
    });
    m_timer->start();


    refreshStatus();
    refreshApiTable();
    refreshCharacterPage();
    refreshVoicePage();
}

void MainWindow::buildUi()
{
    auto* central = new QWidget(this);
    auto* root = new QHBoxLayout(central);
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    auto* side = new QWidget(central);
    side->setObjectName("sidebar");
    side->setFixedWidth(196);
    auto* sideLayout = new QVBoxLayout(side);
    sideLayout->setContentsMargins(0, 0, 0, 0);
    sideLayout->setSpacing(0);

    auto* brand = new QLabel(QStringLiteral("Demon"), side);
    brand->setObjectName("brand");
    sideLayout->addWidget(brand);

    m_nav = new QTreeWidget(side);
    m_nav->setObjectName("nav");
    m_nav->setHeaderHidden(true);
    m_nav->setIndentation(14);
    m_nav->setRootIsDecorated(true);

    auto addTop = [this](const QString& text, int page) {
        auto* item = new QTreeWidgetItem(m_nav);
        item->setText(0, text);
        item->setData(0, Qt::UserRole, page);
        item->setData(0, Qt::UserRole + 1, -1);
        return item;
    };
    auto addChild = [this](QTreeWidgetItem* parent, const QString& text, int page, int tab) {
        auto* item = new QTreeWidgetItem(parent);
        item->setText(0, text);
        item->setData(0, Qt::UserRole, page);
        item->setData(0, Qt::UserRole + 1, tab);
        return item;
    };

    addTop(QStringLiteral("配置"), 0);
    addTop(QStringLiteral("启动"), 1);
    auto* voiceItem = addTop(QStringLiteral("语音"), 2);
    addChild(voiceItem, QStringLiteral("对接酒馆"), 2, 0);
    addChild(voiceItem, QStringLiteral("本地语音"), 2, 1);
    addChild(voiceItem, QStringLiteral("云端语音"), 2, 2);
    addChild(voiceItem, QStringLiteral("声音情绪识别"), 2, 3);
    addTop(QStringLiteral("角色"), 3);
    auto* live2dItem = addTop(QStringLiteral("Live2D"), 4);
    addChild(live2dItem, QStringLiteral("桌宠"), 4, 0);
    addChild(live2dItem, QStringLiteral("vts-obs模式"), 4, 1);

    m_nav->expandAll();
    sideLayout->addWidget(m_nav, 1);
    root->addWidget(side);

    auto* contentWrap = new QWidget(central);
    contentWrap->setObjectName("content");
    auto* contentLayout = new QVBoxLayout(contentWrap);
    contentLayout->setContentsMargins(0, 0, 0, 0);
    contentLayout->setSpacing(0);

    m_stack = new QStackedWidget(contentWrap);
    m_stack->addWidget(buildDashboard());
    m_stack->addWidget(buildLauncherPage());
    m_stack->addWidget(buildVoicePage());
    m_stack->addWidget(buildCharacterPage());
    auto* live2dTabs = new QTabWidget;
    live2dTabs->setObjectName(QStringLiteral("subTabs"));
    live2dTabs->setStyleSheet(QStringLiteral(
        "QTabWidget::pane{border:1px solid #2c2c44;background:#171722;top:-1px;}"
        "QTabBar::tab{background:#1d1d2e;color:#b9b9d0;padding:6px 16px;border:1px solid #2c2c44;border-bottom:none;}"
        "QTabBar::tab:selected{background:#2a2140;color:#ffffff;}"
        "QTabBar::tab:hover{color:#ffffff;}"));
    live2dTabs->addTab(buildLocalPetPage(), QStringLiteral("桌宠"));
    live2dTabs->addTab(buildLive2dPage(), QStringLiteral("vts-obs模式"));
    m_live2dTabs = live2dTabs;
    m_stack->addWidget(live2dTabs);
    contentLayout->addWidget(m_stack, 1);

    m_footer = new QLabel(contentWrap);
    m_footer->setObjectName("footer");
    contentLayout->addWidget(m_footer);

    root->addWidget(contentWrap, 1);
    setCentralWidget(central);

    connect(m_nav, &QTreeWidget::itemClicked, this, [this](QTreeWidgetItem* item, int) {
        const int page = item->data(0, Qt::UserRole).toInt();
        const int tab = item->data(0, Qt::UserRole + 1).toInt();
        if (page >= 0 && page < m_stack->count()) {
            m_stack->setCurrentIndex(page);
        }
        if (tab >= 0 && m_voiceTabs && page == 2) {
            m_voiceTabs->setCurrentIndex(tab);
        }
        if (tab >= 0 && m_live2dTabs && page == 4) {
            m_live2dTabs->setCurrentIndex(tab);
        }
        Log::info(QStringLiteral("导航：%1 → 页 %2 标签 %3").arg(item->text(0)).arg(page).arg(tab));
    });
    if (m_nav->topLevelItemCount() > 0) {
        m_nav->setCurrentItem(m_nav->topLevelItem(0));
        m_stack->setCurrentIndex(0);
    }
}

QWidget* MainWindow::buildLocalPetPage()
{
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(22, 18, 22, 12);

    auto* title = new QLabel(QStringLiteral("桌宠"));
    title->setObjectName("pageTitle");
    layout->addWidget(title);

    auto* hint = new QLabel(QStringLiteral(
        "原生桌宠：Demon 自己用 Cubism Framework + OpenGL 渲染（Qt 原生窗口，不依赖 WebEngine / Electron）。\n"
        "光标在模型上时可拖动、右键菜单；空白处点击直接穿透到后面的窗口；Esc 或右键菜单关闭。"));
    hint->setObjectName("hint");
    hint->setWordWrap(true);
    layout->addWidget(hint);

    auto* nativeRow = new QHBoxLayout;
    auto* nativeStart = new QPushButton(QStringLiteral("启动原生桌宠"));
    nativeStart->setObjectName("primary");
    auto* nativeStop = new QPushButton(QStringLiteral("关闭原生桌宠"));
    auto* nativeStatus = new QLabel(m_controller->nativePetActive() ? QStringLiteral("运行中")
                                                                    : QStringLiteral("未启动"));
    nativeRow->addWidget(nativeStart);
    nativeRow->addWidget(nativeStop);
    nativeRow->addWidget(nativeStatus, 1);
    layout->addLayout(nativeRow);

    auto* smallRow = new QHBoxLayout;
    auto* smallStart = new QPushButton(QStringLiteral("启动 DshDemon"));
    auto* smallStop = new QPushButton(QStringLiteral("关闭 DshDemon"));
    auto* smallStatus = new QLabel(m_controller->smallDemonRunning()
                                       ? QStringLiteral("运行中（8792 在线）")
                                       : QStringLiteral("未启动（备用）"));
    smallRow->addWidget(smallStart);
    smallRow->addWidget(smallStop);
    smallRow->addWidget(smallStatus, 1);
    layout->addLayout(smallRow);

    // ---- 原生桌宠表情（从模型 EXP/ 导入，可删除、可触发）----
    auto* exprBox = new QGroupBox(QStringLiteral("表情（EXP）"));
    auto* exprLayout = new QVBoxLayout(exprBox);
    m_petExpressionList = new QListWidget;
    m_petExpressionList->setObjectName(QStringLiteral("petExpressions"));
    m_petExpressionList->setSelectionMode(QAbstractItemView::SingleSelection);
    m_petExpressionList->setMaximumHeight(180);
    // 深色主题：不设样式会变成浅底浅字，列表看起来是空的
    m_petExpressionList->setStyleSheet(QStringLiteral(
        "QListWidget{background:#161b26;color:#e6edf7;border:1px solid #2f3a4c;border-radius:6px;}"
        "QListWidget::item{padding:3px 6px;}"
        "QListWidget::item:selected{background:#3b6fd4;color:#ffffff;}"));
    exprLayout->addWidget(m_petExpressionList);

    auto* exprRow = new QHBoxLayout;
    auto* keepBtn = new QPushButton(QStringLiteral("保留触发"));
    auto* onceBtn = new QPushButton(QStringLiteral("一次性触发"));
    onceBtn->setObjectName("primary");
    auto* deleteBtn = new QPushButton(QStringLiteral("删除选中"));
    auto* reimportBtn = new QPushButton(QStringLiteral("重新导入"));
    auto* exprStatus = new QLabel(QStringLiteral("%1 个").arg(m_controller->petExpressions().size()));
    exprStatus->setObjectName("hint");
    exprRow->addWidget(keepBtn);
    exprRow->addWidget(onceBtn);
    exprRow->addWidget(deleteBtn);
    exprRow->addWidget(reimportBtn);
    exprRow->addWidget(exprStatus, 1);
    exprLayout->addLayout(exprRow);
    layout->addWidget(exprBox);

    const auto refreshExpressions = [this, exprStatus]() {
        m_petExpressionList->clear();
        const QStringList names = m_controller->petExpressions();
        const QStringList latched = m_controller->latchedPetExpressions();
        for (const QString& name : names) {
            const bool isLatched = latched.contains(name);
            auto* entry = new QListWidgetItem((isLatched ? QStringLiteral("● ") : QString()) + name,
                                             m_petExpressionList);
            entry->setForeground(QColor(isLatched ? QStringLiteral("#ffd76a") : QStringLiteral("#e6edf7")));
            entry->setData(Qt::UserRole, name);
        }
        exprStatus->setText(QStringLiteral("%1 个（目录：%2）")
                                .arg(names.size())
                                .arg(m_controller->petExpressionDir()));
    };
    refreshExpressions();

    connect(keepBtn, &QPushButton::clicked, this, [this, refreshExpressions]() {
        auto* item = m_petExpressionList->currentItem();
        if (!item) {
            return;
        }
        m_controller->keepPetExpression(item->data(Qt::UserRole).toString());
        refreshExpressions();
    });
    connect(onceBtn, &QPushButton::clicked, this, [this]() {
        auto* item = m_petExpressionList->currentItem();
        if (!item) {
            return;
        }
        m_controller->oncePetExpression(item->data(Qt::UserRole).toString());
    });
    connect(m_petExpressionList, &QListWidget::itemDoubleClicked, this, [this](QListWidgetItem* item) {
        if (item) {
            m_controller->oncePetExpression(item->data(Qt::UserRole).toString());
        }
    });
    connect(deleteBtn, &QPushButton::clicked, this, [this, refreshExpressions]() {
        auto* item = m_petExpressionList->currentItem();
        if (!item) {
            return;
        }
        m_controller->removePetExpression(item->data(Qt::UserRole).toString());
        refreshExpressions();
    });
    connect(reimportBtn, &QPushButton::clicked, this, [this, refreshExpressions]() {
        m_controller->importPetExpressions();
        refreshExpressions();
    });
    // ---- 动作层（参数动画：模型没有 Motions 也能点头/摇头/摆尾/鞠躬）----
    auto* petActionBox = new QGroupBox(QStringLiteral("动作"));
    auto* petActionRow = new QHBoxLayout(petActionBox);
    const QVector<QPair<QString, QString>> kPetActions = {
        {QStringLiteral("nod"), QStringLiteral("点头")},
        {QStringLiteral("shake"), QStringLiteral("摇头")},
        {QStringLiteral("tail"), QStringLiteral("摇尾巴")},
        {QStringLiteral("bow"), QStringLiteral("鞠躬")},
    };
    for (const auto& action : kPetActions) {
        auto* button = new QPushButton(action.second);
        petActionRow->addWidget(button);
        const QString actionId = action.first;
        connect(button, &QPushButton::clicked, this, [this, actionId]() {
            m_controller->playPetAction(actionId);
        });
    }
    petActionRow->addStretch(1);
    layout->addWidget(petActionBox);
    auto* info = new QLabel(QStringLiteral(
        "DshDemon 是 Electron 备用实现；原生桌宠跑起来后可以不再启动它。"));
    info->setObjectName("hint");
    info->setWordWrap(true);
    layout->addWidget(info);
    layout->addStretch();

    connect(nativeStart, &QPushButton::clicked, this, [this, nativeStatus]() {
        QString error;
        if (m_controller->startNativePet(&error)) {
            nativeStatus->setText(QStringLiteral("启动中…（模型加载约 0.1 秒）"));
        } else {
            nativeStatus->setText(QStringLiteral("失败：%1").arg(error));
        }
    });
    connect(nativeStop, &QPushButton::clicked, this, [this, nativeStatus]() {
        m_controller->stopNativePet();
        nativeStatus->setText(QStringLiteral("已关闭"));
    });
    connect(smallStart, &QPushButton::clicked, this, [this, smallStatus]() {
        if (m_controller->smallDemonRunning()) {
            smallStatus->setText(QStringLiteral("已在运行（8792 在线）"));
            return;
        }
        QString error;
        if (m_controller->startSmallDemon(&error)) {
            smallStatus->setText(QStringLiteral("已启动，等待渲染窗口…"));
        } else {
            smallStatus->setText(QStringLiteral("失败：%1").arg(error));
        }
    });
    connect(smallStop, &QPushButton::clicked, this, [this, smallStatus]() {
        m_controller->stopSmallDemon();
        smallStatus->setText(QStringLiteral("已请求退出"));
    });

    return page;
}


QWidget* MainWindow::buildDashboard()
{
    auto* page = new QWidget;
    auto* outer = new QVBoxLayout(page);
    outer->setContentsMargins(0, 0, 0, 0);

    auto* scroll = new QScrollArea(page);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setStyleSheet(QStringLiteral(
        "QScrollArea{background:transparent;border:none;}"
        "QScrollArea > QWidget > QWidget{background:transparent;}"));
    scroll->viewport()->setAutoFillBackground(false);
    auto* inner = new QWidget;
    auto* layout = new QVBoxLayout(inner);
    layout->setContentsMargins(22, 18, 22, 12);
    scroll->setWidget(inner);
    outer->addWidget(scroll);

    auto* title = new QLabel(QStringLiteral("配置"));
    title->setObjectName("pageTitle");
    layout->addWidget(title);

    auto* engineBox = new QGroupBox(QStringLiteral("引擎"));
    auto* form = new QFormLayout(engineBox);
    m_epLabel = new QLabel;
    m_upstreamLabel = new QLabel;
    m_modelLabel = new QLabel;
    m_voiceLabel = new QLabel;
    for (QLabel* l : {m_epLabel, m_upstreamLabel, m_modelLabel, m_voiceLabel}) {
        l->setTextInteractionFlags(Qt::TextSelectableByMouse);
    }
    form->addRow(QStringLiteral("监听地址"), m_epLabel);
    form->addRow(QStringLiteral("当前上游"), m_upstreamLabel);
    form->addRow(QStringLiteral("对外模型"), m_modelLabel);
    form->addRow(QStringLiteral("默认声线"), m_voiceLabel);
    layout->addWidget(engineBox);

    auto* apiBox = new QGroupBox(QStringLiteral("上游（OpenAI 兼容）"));
    auto* apiLayout = new QVBoxLayout(apiBox);
    auto* hint = new QLabel(QStringLiteral("酒馆里的自定义端点填 http://127.0.0.1:8790/v1，模型名写对外模型；这里是 Demon 转发到的上游。"));
    hint->setObjectName("hint");
    hint->setWordWrap(true);
    apiLayout->addWidget(hint);
    m_apiTable = new QTableWidget(0, 4);
    m_apiTable->setHorizontalHeaderLabels({QStringLiteral("ID"), QStringLiteral("地址（到 /v1）"),
                                           QStringLiteral("模型"), QStringLiteral("密钥")});
    m_apiTable->horizontalHeader()->setStretchLastSection(true);
    m_apiTable->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);
    m_apiTable->verticalHeader()->setVisible(false);
    m_apiTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    apiLayout->addWidget(m_apiTable, 1);
    auto* apiRow = new QHBoxLayout;
    auto* add = new QPushButton(QStringLiteral("添加"));
    auto* remove = new QPushButton(QStringLiteral("删除选中"));
    auto* save = new QPushButton(QStringLiteral("保存并生效"));
    save->setObjectName("primary");
    apiRow->addWidget(add);
    apiRow->addWidget(remove);
    apiRow->addWidget(save);
    apiRow->addSpacing(16);
    apiRow->addWidget(new QLabel(QStringLiteral("默认上游")));
    m_defaultUpstream = new QLineEdit;
    m_defaultUpstream->setFixedWidth(140);
    apiRow->addWidget(m_defaultUpstream);
    apiRow->addStretch();
    apiLayout->addLayout(apiRow);
    layout->addWidget(apiBox, 1);

    auto* syncRow = new QHBoxLayout;
    auto* syncChats = new QPushButton(QStringLiteral("同步酒馆聊天"));
    auto* syncWorlds = new QPushButton(QStringLiteral("同步世界书/角色卡"));
    auto* syncStatus = new QLabel(QStringLiteral("手动同步 dsh-demon 索引"));
    syncStatus->setObjectName("hint");
    syncRow->addWidget(syncChats);
    syncRow->addWidget(syncWorlds);
    auto* autoTransfer = new QCheckBox(QStringLiteral("自动传输"));
    autoTransfer->setChecked(true);
    autoTransfer->setToolTip(QStringLiteral("关闭后 dsh-demon 不再自动扫描/传输，只能手动同步"));
    syncRow->addWidget(autoTransfer);
    syncRow->addWidget(syncStatus, 1);
    layout->addLayout(syncRow);

    auto* buttons = new QHBoxLayout;
    auto* copy = new QPushButton(QStringLiteral("复制接口地址"));
    auto* log = new QPushButton(QStringLiteral("打开日志"));
    auto* cfg = new QPushButton(QStringLiteral("配置目录"));
    auto* reload = new QPushButton(QStringLiteral("重载配置"));
    buttons->addWidget(copy);
    buttons->addWidget(log);
    buttons->addWidget(cfg);
    buttons->addWidget(reload);
    buttons->addStretch();
    layout->addLayout(buttons);

    connect(add, &QPushButton::clicked, this, [this]() {
        const int row = m_apiTable->rowCount();
        m_apiTable->insertRow(row);
        m_apiTable->setItem(row, 0, item(QStringLiteral("upstream%1").arg(row + 1)));
        m_apiTable->setItem(row, 1, item(QStringLiteral("http://127.0.0.1:8080/v1")));
        m_apiTable->setItem(row, 2, item(QStringLiteral("local-model")));
        m_apiTable->setItem(row, 3, item(QString()));
    });
    connect(remove, &QPushButton::clicked, this, [this]() {
        const int row = m_apiTable->currentRow();
        if (row >= 0) {
            m_apiTable->removeRow(row);
        }
    });
    connect(save, &QPushButton::clicked, this, [this]() { saveApiTable(); });
    connect(copy, &QPushButton::clicked, this, [this, copy]() {
        const QString url = QStringLiteral("http://%1:%2/v1")
                                .arg(m_controller->config().host)
                                .arg(m_controller->config().port);
        QGuiApplication::clipboard()->setText(url);
        copy->setText(QStringLiteral("已复制 ✓"));
        QTimer::singleShot(1200, copy, [copy]() { copy->setText(QStringLiteral("复制接口地址")); });
    });
    connect(log, &QPushButton::clicked, m_controller, &AppController::openLogFile);
    connect(cfg, &QPushButton::clicked, m_controller, &AppController::openConfigFolder);
    connect(reload, &QPushButton::clicked, m_controller, &AppController::reloadConfig);

    connect(syncChats, &QPushButton::clicked, this, [this, syncStatus, syncChats]() {
        syncChats->setEnabled(false);
        syncStatus->setText(QStringLiteral("同步聊天中…"));
        m_controller->syncDsh(true, false, [syncStatus, syncChats](bool ok, const QString& message) {
            syncChats->setEnabled(true);
            syncStatus->setText((ok ? QStringLiteral("聊天：") : QStringLiteral("失败：")) + message);
        });
    });
    connect(autoTransfer, &QCheckBox::toggled, this, [this](bool on) {
        m_controller->setDshAutoTransfer(on);
    });
    connect(syncWorlds, &QPushButton::clicked, this, [this, syncStatus, syncWorlds]() {
        syncWorlds->setEnabled(false);
        syncStatus->setText(QStringLiteral("同步世界书中…"));
        m_controller->syncDsh(false, true, [syncStatus, syncWorlds](bool ok, const QString& message) {
            syncWorlds->setEnabled(true);
            syncStatus->setText((ok ? QStringLiteral("世界书：") : QStringLiteral("失败：")) + message);
        });
    });

    return page;
}

QWidget* MainWindow::buildLauncherPage()
{
    auto* page = new QWidget;
    auto* outer = new QVBoxLayout(page);
    outer->setContentsMargins(0, 0, 0, 0);

    auto* scroll = new QScrollArea(page);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setStyleSheet(QStringLiteral(
        "QScrollArea{background:transparent;border:none;}"
        "QScrollArea > QWidget > QWidget{background:transparent;}"
        "QScrollBar:vertical{background:#1b1b2b;width:10px;margin:0;}"
        "QScrollBar::handle:vertical{background:#3a3a55;min-height:24px;border-radius:5px;}"
        "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"));
    scroll->viewport()->setAutoFillBackground(false);
    auto* inner = new QWidget;
    auto* layout = new QVBoxLayout(inner);
    layout->setContentsMargins(22, 18, 22, 12);
    scroll->setWidget(inner);
    outer->addWidget(scroll);

    auto* title = new QLabel(QStringLiteral("启动器"));
    title->setObjectName("pageTitle");
    layout->addWidget(title);

    // 酒馆
    auto* stBox = new QGroupBox(QStringLiteral("SillyTavern"));
    auto* stLayout = new QGridLayout(stBox);
    stLayout->addWidget(new QLabel(QStringLiteral("安装目录")), 0, 0);
    m_stPath = new QLineEdit;
    m_stPath->setText(m_controller->config().launcher.stPath);
    stLayout->addWidget(m_stPath, 0, 1);
    auto* stBrowse = new QPushButton(QStringLiteral("浏览…"));
    stLayout->addWidget(stBrowse, 0, 2);
    stLayout->addWidget(new QLabel(QStringLiteral("端口")), 1, 0);
    m_stPort = new QSpinBox;
    m_stPort->setRange(1024, 65535);
    m_stPort->setFixedWidth(110);
    m_stPort->setValue(m_controller->config().launcher.stPort);
    stLayout->addWidget(m_stPort, 1, 1);
    m_stState = new QLabel(QStringLiteral("○ 未运行"));
    stLayout->addWidget(m_stState, 1, 2);
    auto* stButtons = new QHBoxLayout;
    auto* stStart = new QPushButton(QStringLiteral("启动酒馆"));
    stStart->setObjectName("primary");
    auto* stStop = new QPushButton(QStringLiteral("停止酒馆"));
    auto* stOpen = new QPushButton(QStringLiteral("打开页面"));
    stButtons->addWidget(stStart);
    stButtons->addWidget(stStop);
    stButtons->addWidget(stOpen);
    stButtons->addStretch();
    stLayout->addLayout(stButtons, 2, 0, 1, 3);
    layout->addWidget(stBox);

    // 语音
    auto* gsvBox = new QGroupBox(QStringLiteral("本地语音服务"));
    auto* gsvLayout = new QGridLayout(gsvBox);
    gsvLayout->addWidget(new QLabel(QStringLiteral("安装目录")), 0, 0);
    m_gsvPath = new QLineEdit;
    m_gsvPath->setText(m_controller->config().launcher.gsvPath);
    gsvLayout->addWidget(m_gsvPath, 0, 1);
    auto* gsvBrowse = new QPushButton(QStringLiteral("浏览…"));
    gsvLayout->addWidget(gsvBrowse, 0, 2);
    gsvLayout->addWidget(new QLabel(QStringLiteral("状态")), 1, 0);
    m_gsvState = new QLabel(QStringLiteral("○ 未运行"));
    gsvLayout->addWidget(m_gsvState, 1, 1);
    auto* gsvButtons = new QHBoxLayout;
    auto* gsvStart = new QPushButton(QStringLiteral("启动语音服务"));
    gsvStart->setObjectName("primary");
    auto* gsvStop = new QPushButton(QStringLiteral("停止语音服务"));
    auto* gsvFolder = new QPushButton(QStringLiteral("打开目录"));
    gsvButtons->addWidget(gsvStart);
    gsvButtons->addWidget(gsvStop);
    gsvButtons->addWidget(gsvFolder);
    gsvButtons->addStretch();
    gsvLayout->addLayout(gsvButtons, 2, 0, 1, 3);
    layout->addWidget(gsvBox);

    // ---- 语音后端选择 ----
    auto* cloudBox = new QGroupBox(QStringLiteral("云端语音服务"));
    auto* cloudLayout = new QGridLayout(cloudBox);

    auto* providerBox = new QComboBox;
    providerBox->addItem(QStringLiteral("（未选择）"), QString());
    providerBox->addItem(QStringLiteral("本地 GPT-SoVITS"), QStringLiteral("gptsovits"));
    providerBox->addItem(QStringLiteral("千问 Qwen（云端）"), QStringLiteral("qwen"));
    {
        const QString current = m_controller->config().voice.provider;
        if (current == QStringLiteral("qwen")) {
            providerBox->setCurrentIndex(2);
        } else if (current == QStringLiteral("gptsovits")) {
            providerBox->setCurrentIndex(1);
        } else {
            providerBox->setCurrentIndex(0);   // 未选择：必须由用户显式选一次
        }
    }
    // 只有用户手动改过下拉框才允许写 provider，
    // 避免界面初始化/其它保存动作把 provider 悄悄改回默认的 gptsovits
    auto providerPicked = std::make_shared<bool>(false);
    cloudLayout->addWidget(new QLabel(QStringLiteral("来源")), 0, 0);
    cloudLayout->addWidget(providerBox, 0, 1, 1, 2);

    auto* qwenModel = new QLineEdit(m_controller->config().voice.qwen.model);
    auto* qwenVoice = new QLineEdit(m_controller->config().voice.qwen.voice);
    auto* qwenKey = new QLineEdit(m_controller->config().voice.qwen.apiKey);
    qwenKey->setEchoMode(QLineEdit::Password);
    qwenKey->setPlaceholderText(QStringLiteral("sk-...（保存在本地 config.json）"));

    cloudLayout->addWidget(new QLabel(QStringLiteral("模型")), 1, 0);
    cloudLayout->addWidget(qwenModel, 1, 1, 1, 2);
    cloudLayout->addWidget(new QLabel(QStringLiteral("音色")), 2, 0);
    cloudLayout->addWidget(qwenVoice, 2, 1, 1, 2);
    cloudLayout->addWidget(new QLabel(QStringLiteral("API Key")), 3, 0);
    cloudLayout->addWidget(qwenKey, 3, 1, 1, 2);

    auto* qwenTest = new QPushButton(QStringLiteral("试听千问"));
    qwenTest->setObjectName("primary");
    cloudLayout->addWidget(qwenTest, 4, 0, 1, 3);

    auto* cloudHint = new QLabel(QStringLiteral("千问走 DashScope 的 SpeechSynthesizer 接口；切到千问后不再需要本地 GPT-SoVITS。"));
    cloudHint->setObjectName("hint");
    cloudHint->setWordWrap(true);
    cloudLayout->addWidget(cloudHint, 5, 0, 1, 3);

    layout->addWidget(cloudBox);

    // ---- VTube Studio ----
    auto* vtsBox = new QGroupBox(QStringLiteral("VTube Studio（Live2D）"));
    auto* vtsLayout = new QGridLayout(vtsBox);
    m_vtsPath = new QLineEdit(m_controller->config().live2d.vtsExe.isEmpty()
                                   ? QStringLiteral("E:/SteamLibrary/steamapps/common/VTube Studio/VTube Studio.exe")
                                   : m_controller->config().live2d.vtsExe);
    m_vtsPath->setPlaceholderText(QStringLiteral("VTube Studio.exe 的完整路径"));
    auto* vtsBrowse = new QPushButton(QStringLiteral("浏览…"));
    m_vtsState = new QLabel(QStringLiteral("…"));
    auto* vtsStart = new QPushButton(QStringLiteral("启动 VTube Studio"));
    vtsStart->setObjectName("primary");
    auto* vtsStop = new QPushButton(QStringLiteral("关闭 VTube Studio"));

    vtsLayout->addWidget(new QLabel(QStringLiteral("程序")), 0, 0);
    vtsLayout->addWidget(m_vtsPath, 0, 1);
    vtsLayout->addWidget(vtsBrowse, 0, 2);
    vtsLayout->addWidget(new QLabel(QStringLiteral("状态")), 1, 0);
    vtsLayout->addWidget(m_vtsState, 1, 1, 1, 2);
    auto* vtsButtons = new QHBoxLayout;
    vtsButtons->addWidget(vtsStart);
    vtsButtons->addWidget(vtsStop);
    vtsButtons->addStretch();
    vtsLayout->addLayout(vtsButtons, 2, 0, 1, 3);
    layout->addWidget(vtsBox);

    // ---- 本地 4B 小模型（情绪/动作判定）----
    auto* localModelBox = new QGroupBox(QStringLiteral("本地 4B 小模型（情绪/动作判定）"));
    auto* localLayout = new QGridLayout(localModelBox);
    const QString gatewayDir = QStringLiteral("E:/DSH-LocalLLM/gateway");
    const QString modelFile = QStringLiteral("E:/DSH-LocalLLM/models/qwen3-vl-4b/Qwen3-VL-4B-Instruct-Q4_K_M.gguf");
    auto* gatewayEdit = new QLineEdit(gatewayDir);
    gatewayEdit->setReadOnly(true);
    gatewayEdit->setToolTip(QStringLiteral("llama.cpp 网关（OpenAI 兼容，自动按需启停）"));
    auto* modelEdit = new QLineEdit(modelFile);
    modelEdit->setReadOnly(true);
    modelEdit->setToolTip(QStringLiteral("Qwen3-VL-4B-Instruct GGUF（本机 4B 小模型）"));
    auto* localHint = new QLabel(QStringLiteral("作用：当台词的括号描写里没有关键词（如「脸唰地红到耳尖」「尾巴尖轻轻晃」）时，由它判断该表现哪种情绪（脸红/脸黑/龇牙…）和哪种动作（点头/摇头/摇尾巴/鞠躬），再驱动原生桌宠；判定结果按描写文本缓存，重复台词不再调用。接口 http://127.0.0.1:8099/v1/chat/completions（model=local-vl），空闲 5 分钟自动卸载。"));
    localHint->setWordWrap(true);
    localHint->setObjectName("hint");
    localLayout->addWidget(new QLabel(QStringLiteral("网关")), 0, 0);
    localLayout->addWidget(gatewayEdit, 0, 1);
    localLayout->addWidget(new QLabel(QStringLiteral("模型")), 1, 0);
    localLayout->addWidget(modelEdit, 1, 1);
    localLayout->addWidget(localHint, 2, 0, 1, 2);
    layout->addWidget(localModelBox);

    connect(vtsBrowse, &QPushButton::clicked, this, [this]() {
        const QString file = QFileDialog::getOpenFileName(this, QStringLiteral("选择 VTube Studio.exe"), QString(),
                                                          QStringLiteral("程序 (*.exe)"));
        if (!file.isEmpty()) {
            m_vtsPath->setText(QDir::toNativeSeparators(file));
            m_controller->mutableConfig().live2d.vtsExe = QDir::toNativeSeparators(file);
            m_controller->saveConfig();
        }
    });
    connect(m_vtsPath, &QLineEdit::editingFinished, this, [this]() {
        m_controller->mutableConfig().live2d.vtsExe = m_vtsPath->text().trimmed();
        m_controller->saveConfig();
    });
    connect(vtsStart, &QPushButton::clicked, this, [this]() {
        QString error;
        if (!m_controller->startVTubeStudio(&error)) {
            QMessageBox::warning(this, QStringLiteral("VTube Studio"), error);
        }
    });
    connect(vtsStop, &QPushButton::clicked, this, [this]() {
        QString error;
        if (!m_controller->stopVTubeStudio(&error)) {
            QMessageBox::warning(this, QStringLiteral("VTube Studio"), error);
        }
    });


    auto saveQwen = [this, providerBox, qwenModel, qwenVoice, qwenKey, providerPicked]() {
        auto& cfg = m_controller->mutableConfig();
        if (*providerPicked) {
        cfg.voice.provider = providerBox->currentData().toString();
    }
        cfg.voice.qwen.model = qwenModel->text().trimmed();
        cfg.voice.qwen.voice = qwenVoice->text().trimmed();
        cfg.voice.qwen.apiKey = qwenKey->text().trimmed();
        m_controller->saveConfig();
        m_controller->reloadConfig();
        Log::info(QStringLiteral("语音后端：%1（%2 / %3）")
                      .arg(cfg.voice.provider, cfg.voice.qwen.model, cfg.voice.qwen.voice));
    };

    connect(providerBox, &QComboBox::currentIndexChanged, this, [saveQwen](int) { saveQwen(); });
    connect(providerBox, &QComboBox::activated, this, [providerPicked](int) { *providerPicked = true; });
    connect(qwenModel, &QLineEdit::editingFinished, this, [saveQwen]() { saveQwen(); });
    connect(qwenVoice, &QLineEdit::editingFinished, this, [saveQwen]() { saveQwen(); });
    connect(qwenKey, &QLineEdit::editingFinished, this, [saveQwen]() { saveQwen(); });
    connect(qwenTest, &QPushButton::clicked, this, [this]() { m_controller->testVoice(QString()); });


    auto* hint = new QLabel(QStringLiteral("提示：启动脚本分别是 <酒馆目录>\\Start.bat 与 <语音目录>\\start-api-v2pro.bat。"
                                           "语音服务首次加载模型约 20~60 秒。"));
    hint->setObjectName("hint");
    hint->setWordWrap(true);
    layout->addWidget(hint);
    layout->addStretch();

    connect(stBrowse, &QPushButton::clicked, this, [this]() {
        const QString dir = QFileDialog::getExistingDirectory(this, QStringLiteral("选择 SillyTavern 目录"), m_stPath->text());
        if (!dir.isEmpty()) {
            m_stPath->setText(dir);
        }
    });
    connect(gsvBrowse, &QPushButton::clicked, this, [this]() {
        const QString dir = QFileDialog::getExistingDirectory(this, QStringLiteral("选择 GPT-SoVITS 目录"), m_gsvPath->text());
        if (!dir.isEmpty()) {
            m_gsvPath->setText(dir);
        }
    });
    connect(stStart, &QPushButton::clicked, this, [this]() {
        auto& cfg = m_controller->mutableConfig();
        cfg.launcher.stPath = m_stPath->text().trimmed();
        cfg.launcher.stPort = m_stPort->value();
        m_controller->saveConfig();
        QString error;
        if (!m_controller->startSillyTavern(&error)) {
            QMessageBox::warning(this, QStringLiteral("启动酒馆"), error);
            return;
        }
        if (AppController::portOpen(static_cast<quint16>(m_stPort->value()))) {
            // 已经在跑：Start.bat 不会再开浏览器，这里给个手动入口
            m_controller->openInEdge(QStringLiteral("http://127.0.0.1:%1/").arg(m_stPort->value()));
            Log::info(QStringLiteral("酒馆已在运行，打开页面"));
        } else {
            // 未运行：只拉起 Start.bat，浏览器由它自己打开
            Log::info(QStringLiteral("已启动酒馆（浏览器由 Start.bat 打开）"));
        }
    });
    connect(stStop, &QPushButton::clicked, this, [this]() {
        QString error;
        if (!m_controller->stopSillyTavern(&error)) {
            QMessageBox::information(this, QStringLiteral("停止酒馆"), error);
        }
    });
    connect(stOpen, &QPushButton::clicked, this, [this]() {
        openInBrowser(m_controller, QStringLiteral("http://127.0.0.1:%1/").arg(m_stPort->value()));
    });
    connect(gsvStart, &QPushButton::clicked, this, [this]() {
        auto& cfg = m_controller->mutableConfig();
        cfg.launcher.gsvPath = m_gsvPath->text().trimmed();
        m_controller->saveConfig();
        QString error;
        if (!m_controller->startVoiceService(&error)) {
            QMessageBox::warning(this, QStringLiteral("启动语音服务"), error);
        }
    });
    connect(gsvStop, &QPushButton::clicked, this, [this]() {
        QString error;
        if (!m_controller->stopVoiceService(&error)) {
            QMessageBox::information(this, QStringLiteral("停止语音服务"), error);
        }
    });
    connect(gsvFolder, &QPushButton::clicked, this, [this]() {
        QDesktopServices::openUrl(QUrl::fromLocalFile(m_gsvPath->text().trimmed()));
    });

    layout->addStretch();
    return page;
}

QWidget* MainWindow::buildVoicePage()
{
    auto* page = new QWidget;
    auto* layout = new QVBoxLayout(page);
    layout->setContentsMargins(22, 18, 22, 12);

    auto* title = new QLabel(QStringLiteral("语音"));
    title->setObjectName("pageTitle");
    layout->addWidget(title);

    m_voiceTabs = new QTabWidget;
    m_voiceTabs->setStyleSheet(QStringLiteral(
        "QTabWidget::pane{border:1px solid #2c2c44;background:#171722;top:-1px;}"
        "QTabBar::tab{background:#1d1d2e;color:#b9b9d0;padding:6px 16px;border:1px solid #2c2c44;border-bottom:none;}"
        "QTabBar::tab:selected{background:#2a2140;color:#ffffff;}"
        "QTabBar::tab:hover{color:#ffffff;}"));

    // ---- 对接酒馆 ----
    auto* tabSt = new QWidget;
    auto* stLayout = new QVBoxLayout(tabSt);
    auto* stHint = new QLabel(QStringLiteral("播放仍在酒馆页面由 smartdemon 插件执行；这里只负责声线、语言与转发配置。"));
    stHint->setObjectName("hint");
    stHint->setWordWrap(true);
    stLayout->addWidget(stHint);

    m_translateCheck = new QCheckBox(QStringLiteral("中文台词先翻译成日语再合成（翻译走酒馆当前模型）"));
    stLayout->addWidget(m_translateCheck);

    auto* bindLabel = new QLabel(QStringLiteral("角色声线绑定"));
    stLayout->addWidget(bindLabel);
    m_bindTable = new QTableWidget(0, 4);
    m_bindTable->setHorizontalHeaderLabels({QStringLiteral("角色"), QStringLiteral("来源"),
                                            QStringLiteral("声线"), QStringLiteral("语言")});
    m_bindTable->horizontalHeader()->setStretchLastSection(true);
    m_bindTable->verticalHeader()->setVisible(false);
    stLayout->addWidget(m_bindTable, 1);
    m_voiceTabs->addTab(tabSt, QStringLiteral("对接酒馆"));

    // ---- 本地语音 ----
    auto* tabLocal = new QWidget;
    auto* localLayout = new QVBoxLayout(tabLocal);
    auto* localForm = new QFormLayout;
    m_gsvEndpoint = new QLineEdit;
    localForm->addRow(QStringLiteral("GPT-SoVITS 地址"), m_gsvEndpoint);
    m_speedSlider = new QSlider(Qt::Horizontal);
    m_speedSlider->setRange(50, 200);
    m_speedSlider->setValue(100);
    localForm->addRow(QStringLiteral("语速"), m_speedSlider);
    localLayout->addLayout(localForm);
    auto* localHint = new QLabel(QStringLiteral("本地模型与启动脚本在「启动」页；这里管理声线档案并试听。"));
    localHint->setObjectName("hint");
    localLayout->addWidget(localHint);
    m_localVoiceTable = new QTableWidget(0, 4);
    m_localVoiceTable->setHorizontalHeaderLabels({QStringLiteral("声线"), QStringLiteral("参考音频"),
                                                  QStringLiteral("提示文本"), QStringLiteral("操作")});
    m_localVoiceTable->horizontalHeader()->setStretchLastSection(true);
    m_localVoiceTable->verticalHeader()->setVisible(false);
    localLayout->addWidget(m_localVoiceTable, 1);
    m_voiceTabs->addTab(tabLocal, QStringLiteral("本地语音"));

    // ---- 云端语音 ----
    auto* tabCloud = new QWidget;
    auto* cloudLayout = new QVBoxLayout(tabCloud);
    auto* cloudForm = new QFormLayout;
    m_cloudModel = new QComboBox;
    m_cloudModel->addItems({QStringLiteral("cosyvoice-v3.5-flash"), QStringLiteral("qwen-audio-3.1-tts-flash")});
    m_cloudModel->setEditable(true);
    m_cloudKey = new QLineEdit;
    m_cloudKey->setEchoMode(QLineEdit::Password);
    cloudForm->addRow(QStringLiteral("合成模型"), m_cloudModel);
    cloudForm->addRow(QStringLiteral("API Key"), m_cloudKey);
    cloudLayout->addLayout(cloudForm);
    auto* cloudHint = new QLabel(QStringLiteral("复刻音色在「角色」页添加参考音频后创建；这里可切换模型、查看音色 ID 与试听。"));
    cloudHint->setObjectName("hint");
    cloudHint->setWordWrap(true);
    cloudLayout->addWidget(cloudHint);
    m_cloudVoiceTable = new QTableWidget(0, 6);
    m_cloudVoiceTable->setHorizontalHeaderLabels({QStringLiteral("声线"), QStringLiteral("复刻音色 ID"),
                                                  QStringLiteral("长音频"), QStringLiteral("短参考"),
                                                  QStringLiteral("语言"), QStringLiteral("操作")});
    m_cloudVoiceTable->horizontalHeader()->setStretchLastSection(true);
    m_cloudVoiceTable->verticalHeader()->setVisible(false);
    cloudLayout->addWidget(m_cloudVoiceTable, 1);
    m_voiceTabs->addTab(tabCloud, QStringLiteral("云端语音"));
    // ---- 声音情绪识别 ----
    auto* tabEmotion = new QWidget;
    auto* emoLayout = new QVBoxLayout(tabEmotion);
    auto* emoHint = new QLabel(QStringLiteral("按一下录音 5 秒，交给 Qwen Omni 识别七种情绪，并自动切换 Live2D 表情。"));
    emoHint->setObjectName("hint");
    emoHint->setWordWrap(true);
    emoLayout->addWidget(emoHint);

    auto* emoRow = new QHBoxLayout;
    m_emotionRecord = new QPushButton(QStringLiteral("录音 5 秒并识别"));
    m_emotionRecord->setObjectName("primary");
    m_emotionStatus = new QLabel(QStringLiteral("就绪"));
    emoRow->addWidget(m_emotionRecord);
    emoRow->addWidget(m_emotionStatus, 1);
    emoLayout->addLayout(emoRow);

    m_emotionTranscript = new QLabel;
    m_emotionTranscript->setWordWrap(true);
    m_emotionTranscript->setTextInteractionFlags(Qt::TextSelectableByMouse);
    emoLayout->addWidget(m_emotionTranscript);

    m_emotionHistory = new QListWidget;
    m_emotionHistory->setObjectName(QStringLiteral("emotionHistory"));
    emoLayout->addWidget(m_emotionHistory, 1);
    m_voiceTabs->addTab(tabEmotion, QStringLiteral("声音情绪识别"));


    layout->addWidget(m_voiceTabs, 1);

    m_voiceMsg = new QLabel;
    m_voiceMsg->setObjectName("hint");
    layout->addWidget(m_voiceMsg);

    connect(m_translateCheck, &QCheckBox::toggled, this, [this](bool on) {
        m_controller->mutableConfig().voice.translateToJa = on;
        m_controller->saveConfig();
    });
    connect(m_gsvEndpoint, &QLineEdit::editingFinished, this, [this]() {
        m_controller->mutableConfig().voice.endpoint = m_gsvEndpoint->text().trimmed();
        m_controller->saveConfig();
    });
    connect(m_speedSlider, &QSlider::valueChanged, this, [this](int value) {
        m_controller->mutableConfig().voice.speed = value / 100.0;
        m_controller->saveConfig();
    });
    connect(m_cloudModel, &QComboBox::currentTextChanged, this, [this](const QString& text) {
        m_controller->mutableConfig().voice.qwen.model = text.trimmed();
        m_controller->saveConfig();
    });
    connect(m_cloudKey, &QLineEdit::editingFinished, this, [this]() {
        m_controller->mutableConfig().voice.qwen.apiKey = m_cloudKey->text().trimmed();
        m_controller->saveConfig();
    });


    auto* recorder = new AudioRecorder(this);
    connect(m_emotionRecord, &QPushButton::clicked, this, [this, recorder]() {
        m_emotionRecord->setEnabled(false);
        m_emotionStatus->setText(QStringLiteral("录音中… 5 秒"));
        m_emotionTranscript->setText(QString());
        recorder->record(5, [this](const QByteArray& wav, const QString& error) {
            if (!error.isEmpty()) {
                m_emotionStatus->setText(QStringLiteral("录音失败：%1").arg(error));
                m_emotionRecord->setEnabled(true);
                return;
            }
            m_emotionStatus->setText(QStringLiteral("识别中…"));
            m_controller->recognizeEmotion(wav, [this](bool ok, const QString& transcript,
                                                       const QString& emotion, const QString& err) {
                m_emotionRecord->setEnabled(true);
                if (!ok) {
                    m_emotionStatus->setText(QStringLiteral("识别失败：%1").arg(err));
                    return;
                }
                m_emotionStatus->setText(QStringLiteral("识别结果：%1").arg(emotion));
                m_emotionTranscript->setText(QStringLiteral("转录：%1").arg(transcript));
                m_emotionHistory->insertItem(0, QStringLiteral("%1  %2  %3")
                                                   .arg(QTime::currentTime().toString(QStringLiteral("HH:mm:ss")),
                                                        emotion, transcript.left(40)));
                QString mapped = emotion;
                if (emotion == QStringLiteral("fearful")) mapped = QStringLiteral("shy");
                else if (emotion == QStringLiteral("disgusted")) mapped = QStringLiteral("angry");
                m_controller->testEmotion(mapped);
            });
        });
    });

    return page;
}

QWidget* MainWindow::buildCharacterPage()
{
    auto* page = new QWidget;
    auto* layout = new QHBoxLayout(page);
    layout->setContentsMargins(18, 16, 18, 12);
    layout->setSpacing(14);

    auto* left = new QVBoxLayout;
    auto* leftTitle = new QLabel(QStringLiteral("角色"));
    leftTitle->setObjectName("pageTitle");
    left->addWidget(leftTitle);
    m_charList = new QListWidget;
    m_charList->setObjectName("nav");
    m_charList->setMaximumWidth(220);
    left->addWidget(m_charList, 1);
    layout->addLayout(left);

    auto* right = new QVBoxLayout;
    m_charTitle = new QLabel(QStringLiteral("选择一个角色"));
    m_charTitle->setObjectName("pageTitle");
    right->addWidget(m_charTitle);

    auto* providerRow = new QHBoxLayout;
    providerRow->addWidget(new QLabel(QStringLiteral("音色来源")));
    m_localBtn = new QPushButton(QStringLiteral("本地音色"));
    m_cloudBtn = new QPushButton(QStringLiteral("云端音色"));
    for (QPushButton* b : {m_localBtn, m_cloudBtn}) {
        b->setCheckable(true);
        b->setMinimumWidth(110);
    }
    providerRow->addWidget(m_localBtn);
    providerRow->addWidget(m_cloudBtn);
    providerRow->addStretch();
    right->addLayout(providerRow);

    auto* voiceBox = new QGroupBox(QStringLiteral("声线"));
    auto* voiceLayout = new QVBoxLayout(voiceBox);
    m_charVoiceTable = new QTableWidget(0, 3);
    m_charVoiceTable->setHorizontalHeaderLabels({QStringLiteral("声线"), QStringLiteral("来源"), QStringLiteral("操作")});
    m_charVoiceTable->horizontalHeader()->setStretchLastSection(true);
    m_charVoiceTable->verticalHeader()->setVisible(false);
    voiceLayout->addWidget(m_charVoiceTable, 1);
    auto* voiceRow = new QHBoxLayout;
    auto* addVoice = new QPushButton(QStringLiteral("+ 添加声线"));
    voiceRow->addWidget(addVoice);
    voiceRow->addStretch();
    voiceLayout->addLayout(voiceRow);
    right->addWidget(voiceBox, 2);

    auto* modelBox = new QGroupBox(QStringLiteral("Live2D"));
    auto* modelLayout = new QVBoxLayout(modelBox);
    m_charModelTable = new QTableWidget(0, 2);
    m_charModelTable->setHorizontalHeaderLabels({QStringLiteral("模型"), QStringLiteral("操作")});
    m_charModelTable->horizontalHeader()->setStretchLastSection(true);
    m_charModelTable->verticalHeader()->setVisible(false);
    modelLayout->addWidget(m_charModelTable, 1);
    right->addWidget(modelBox, 1);

    m_charState = new QLabel;
    m_charState->setObjectName("hint");
    right->addWidget(m_charState);

    layout->addLayout(right, 1);

    connect(m_charList, &QListWidget::currentTextChanged, this, [this](const QString& name) {
        m_currentCharacter = name;
        refreshCharacterPage();
    });
    connect(m_localBtn, &QPushButton::clicked, this, [this]() {
        if (m_currentCharacter.isEmpty()) return;
        m_controller->setCharacterProvider(m_currentCharacter, QStringLiteral("local"));
        refreshCharacterPage();
    });
    connect(m_cloudBtn, &QPushButton::clicked, this, [this]() {
        if (m_currentCharacter.isEmpty()) return;
        m_controller->setCharacterProvider(m_currentCharacter, QStringLiteral("cloud"));
        refreshCharacterPage();
    });
    connect(addVoice, &QPushButton::clicked, this, [this]() {
        if (m_currentCharacter.isEmpty()) return;
        const bool cloud = m_controller->config().characterProviders.value(m_currentCharacter, QStringLiteral("local")) == QStringLiteral("cloud");
        const QString name = QInputDialog::getText(this, QStringLiteral("添加声线"), QStringLiteral("声线名称"));
        if (name.trimmed().isEmpty()) return;
        const QString audio = QFileDialog::getOpenFileName(this, QStringLiteral("参考音频"), QString(),
                                                          QStringLiteral("音频 (*.wav *.mp3 *.m4a)"));
        if (audio.isEmpty()) return;
        VoiceProfileConfig profile;
        profile.id = name.trimmed();
        profile.name = name.trimmed();
        profile.refAudio = audio;
        profile.source = cloud ? QStringLiteral("cloud") : QStringLiteral("local");
        m_controller->mutableConfig().voiceProfiles.append(profile);
        m_controller->saveConfig();
        m_controller->setCharacterVoice(m_currentCharacter, profile.id);
        refreshCharacterPage();
    });

    return page;
}

QWidget* MainWindow::buildLive2dPage()
{
    auto* page = new QWidget;
    auto* outer = new QVBoxLayout(page);
    outer->setContentsMargins(0, 0, 0, 0);
    auto* scroll = new QScrollArea(page);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    scroll->setStyleSheet(QStringLiteral(
        "QScrollArea{background:transparent;border:none;}"
        "QScrollArea > QWidget > QWidget{background:transparent;}"));
    scroll->viewport()->setAutoFillBackground(false);
    auto* inner = new QWidget;
    auto* layout = new QVBoxLayout(inner);
    layout->setContentsMargins(22, 18, 22, 12);
    scroll->setWidget(inner);
    outer->addWidget(scroll);

    auto* title = new QLabel(QStringLiteral("Live2D · VTube Studio"));
    title->setObjectName("pageTitle");
    layout->addWidget(title);

    auto* hint = new QLabel(QStringLiteral("Demon 通过 VTube Studio 插件 API（默认 ws://127.0.0.1:8001）控制表情、动作和口型。"));
    hint->setObjectName("hint");
    hint->setWordWrap(true);
    layout->addWidget(hint);

    // ---- 连接 ----
    auto* connBox = new QGroupBox(QStringLiteral("连接"));
    auto* form = new QFormLayout(connBox);
    m_l2dEndpoint = new QLabel(m_controller->live2dEndpoint());
    m_l2dState = new QLabel(QStringLiteral("…"));
    m_l2dModel = new QLabel(QStringLiteral("（未连接）"));
    m_l2dError = new QLabel;
    form->addRow(QStringLiteral("地址"), m_l2dEndpoint);
    form->addRow(QStringLiteral("状态"), m_l2dState);
    form->addRow(QStringLiteral("模型"), m_l2dModel);
    form->addRow(QStringLiteral("错误"), m_l2dError);
    auto* connRow = new QHBoxLayout;
    auto* reconnect = new QPushButton(QStringLiteral("重新连接"));
    reconnect->setObjectName("primary");
    connRow->addWidget(reconnect);
    connRow->addStretch();
    form->addRow(connRow);
    layout->addWidget(connBox);

    // ---- 桌宠模式 ----
    auto* petBox = new QGroupBox(QStringLiteral("桌宠模式"));
    auto* petLayout = new QVBoxLayout(petBox);
    auto* petRow = new QHBoxLayout;
    m_petCheck = new QCheckBox(QStringLiteral("桌宠模式（去边框 + 色键透明 + 置顶）"));
    m_petColor = new QLineEdit(QStringLiteral("#000000"));
    m_petColor->setFixedWidth(90);
    petRow->addWidget(m_petCheck);
    petRow->addWidget(new QLabel(QStringLiteral("色键")));
    petRow->addWidget(m_petColor);
    petRow->addStretch();
    petLayout->addLayout(petRow);
    auto* petHint = new QLabel(QStringLiteral("VTS 背景设成纯色（透明背景一般按黑色），填同样的颜色即可把背景抠成透明。"));
    petHint->setObjectName("hint");
    petHint->setWordWrap(true);
    petLayout->addWidget(petHint);
    layout->addWidget(petBox);

    // ---- 口型测试 ----
    auto* mouthBox = new QGroupBox(QStringLiteral("口型测试"));
    auto* mouthLayout = new QVBoxLayout(mouthBox);
    m_mouthSlider = new QSlider(Qt::Horizontal);
    m_mouthSlider->setRange(0, 100);
    m_mouthSlider->setValue(0);
    auto* mouthRow = new QHBoxLayout;
    mouthRow->addWidget(new QLabel(QStringLiteral("MouthOpen")));
    mouthRow->addWidget(m_mouthSlider, 1);
    auto* send = new QPushButton(QStringLiteral("发送"));
    auto* sweep = new QPushButton(QStringLiteral("扫一遍 0→1"));
    mouthRow->addWidget(send);
    mouthRow->addWidget(sweep);
    mouthLayout->addLayout(mouthRow);
    layout->addWidget(mouthBox);

    // ---- 情绪（表格式，带序号）----
    static const QStringList emotions = {
        QStringLiteral("happy"), QStringLiteral("excited"), QStringLiteral("shy"),
        QStringLiteral("love"), QStringLiteral("sad"), QStringLiteral("cry"),
        QStringLiteral("angry"), QStringLiteral("surprised"), QStringLiteral("confused"),
        QStringLiteral("think"), QStringLiteral("tease"), QStringLiteral("dark"),
        QStringLiteral("dizzy"), QStringLiteral("tired"),
    };
    static const QStringList emotionLabels = {
        QStringLiteral("开心"), QStringLiteral("兴奋"), QStringLiteral("害羞"),
        QStringLiteral("亲昵"), QStringLiteral("难过"), QStringLiteral("哭"),
        QStringLiteral("生气"), QStringLiteral("惊讶"), QStringLiteral("疑惑"),
        QStringLiteral("思考"), QStringLiteral("调皮"), QStringLiteral("阴沉"),
        QStringLiteral("晕"), QStringLiteral("累"),
    };

    auto* emotionBox = new QGroupBox(QStringLiteral("情绪"));
    auto* emotionLayout = new QVBoxLayout(emotionBox);
    m_emotionTable = new QTableWidget(0, 5);
    m_emotionTable->setHorizontalHeaderLabels({QStringLiteral("序号"), QStringLiteral("情绪"),
                                               QStringLiteral("当前表情"), QStringLiteral("动作"),
                                               QStringLiteral("操作")});
    m_emotionTable->horizontalHeader()->setStretchLastSection(true);
    m_emotionTable->verticalHeader()->setVisible(false);
    emotionLayout->addWidget(m_emotionTable, 1);
    layout->addWidget(emotionBox);

    // ---- 动作映射（带序号）----
    auto* actionBox = new QGroupBox(QStringLiteral("动作映射（情绪 → VTS 热键）"));
    auto* actionLayout = new QVBoxLayout(actionBox);
    m_hotkeyTable = new QTableWidget(0, 3);
    m_hotkeyTable->setHorizontalHeaderLabels({QStringLiteral("序号"), QStringLiteral("情绪"),
                                              QStringLiteral("热键")});
    m_hotkeyTable->horizontalHeader()->setStretchLastSection(true);
    m_hotkeyTable->verticalHeader()->setVisible(false);
    actionLayout->addWidget(m_hotkeyTable, 1);
    auto* actionRow = new QHBoxLayout;
    auto* refreshHotkeys = new QPushButton(QStringLiteral("刷新热键"));
    auto* saveHotkeys = new QPushButton(QStringLiteral("保存映射"));
    saveHotkeys->setObjectName("primary");
    actionRow->addWidget(refreshHotkeys);
    actionRow->addWidget(saveHotkeys);
    actionRow->addStretch();
    actionLayout->addLayout(actionRow);
    actionBox->setVisible(false);
    layout->addWidget(actionBox);

    // 情绪表填充
    auto fillEmotions = [this]() {
        m_emotionTable->setRowCount(0);
        for (int i = 0; i < emotions.size(); ++i) {
            m_emotionTable->insertRow(i);
            m_emotionTable->setItem(i, 0, item(QStringLiteral("%1").arg(i + 1, 2, 10, QLatin1Char('0'))));
            m_emotionTable->setItem(i, 1, item(emotionLabels.at(i)));
            const QString expr = m_controller->expressionForEmotion(emotions.at(i));
            m_emotionTable->setItem(i, 2, item(expr.isEmpty() ? QStringLiteral("（无）") : expr));
            const QString hotkeyId = m_controller->config().emotionHotkeys.value(emotions.at(i));
            QString hotkeyName = hotkeyId;
            const QStringList hkIds = m_controller->live2dHotkeyIds();
            const QStringList hkNames = m_controller->live2dHotkeys();
            const int hkIdx = hkIds.indexOf(hotkeyId);
            if (hkIdx >= 0 && hkIdx < hkNames.size()) {
                hotkeyName = hkNames.at(hkIdx);
            }
            m_emotionTable->setItem(i, 3, item(hotkeyName.isEmpty() ? QStringLiteral("（无）") : hotkeyName));
            auto* ops = new QWidget;
            auto* opsLayout = new QHBoxLayout(ops);
            opsLayout->setContentsMargins(0, 0, 0, 0);
            auto* trigger = new QPushButton(QStringLiteral("触发"));
            opsLayout->addWidget(trigger);
            opsLayout->addStretch();
            m_emotionTable->setCellWidget(i, 4, ops);
            connect(trigger, &QPushButton::clicked, this, [this, i]() {
                m_controller->testEmotion(emotions.at(i));
                QTimer::singleShot(300, this, [this]() {
                    for (int r = 0; r < m_emotionTable->rowCount(); ++r) {
                        const QString name = m_controller->expressionForEmotion(emotions.at(r));
                        m_emotionTable->item(r, 2)->setText(name.isEmpty() ? QStringLiteral("（无）") : name);
                    }
                });
            });
        }
    };
    fillEmotions();

    auto fillHotkeys = [this, refreshHotkeys]() {
        refreshHotkeys->setEnabled(false);
        m_controller->refreshLive2dHotkeys();
        QTimer::singleShot(1200, this, [this, refreshHotkeys]() {
            refreshHotkeys->setEnabled(true);
            const QStringList names = m_controller->live2dHotkeys();
            const QStringList ids = m_controller->live2dHotkeyIds();
            m_hotkeyTable->setRowCount(0);
            for (int i = 0; i < emotions.size(); ++i) {
                m_hotkeyTable->insertRow(i);
                m_hotkeyTable->setItem(i, 0, item(QStringLiteral("%1").arg(i + 1, 2, 10, QLatin1Char('0'))));
                m_hotkeyTable->setItem(i, 1, item(emotionLabels.at(i)));
                auto* combo = new QComboBox;
                combo->addItem(QStringLiteral("（无）"), QString());
                for (int k = 0; k < names.size() && k < ids.size(); ++k) {
                    combo->addItem(names.at(k), ids.at(k));
                }
                const int idx = combo->findData(m_controller->config().emotionHotkeys.value(emotions.at(i)));
                if (idx >= 0) {
                    combo->setCurrentIndex(idx);
                }
                m_hotkeyTable->setCellWidget(i, 2, combo);
            }
        });
    };
    fillHotkeys();

    connect(refreshHotkeys, &QPushButton::clicked, this, [fillHotkeys]() { fillHotkeys(); });
    connect(saveHotkeys, &QPushButton::clicked, this, [this]() {
        auto& cfg = m_controller->mutableConfig();
        for (int row = 0; row < m_hotkeyTable->rowCount(); ++row) {
            auto* combo = qobject_cast<QComboBox*>(m_hotkeyTable->cellWidget(row, 2));
            if (!combo) continue;
            const QString emotion = emotions.at(row);
            const QString id = combo->currentData().toString();
            if (id.isEmpty()) {
                cfg.emotionHotkeys.remove(emotion);
            } else {
                cfg.emotionHotkeys.insert(emotion, id);
            }
        }
        m_controller->saveConfig();
        QMessageBox::information(this, QStringLiteral("动作映射"), QStringLiteral("已保存"));
    });
    connect(m_petCheck, &QCheckBox::toggled, this, [this](bool on) {
        if (!m_controller->setVtsDesktopPet(on, m_petColor->text().trimmed())) {
            QMessageBox::information(this, QStringLiteral("桌宠模式"),
                                     QStringLiteral("桌宠模式失败：请确认 VTS 已启动，并且 Demon 与 VTS 权限相同（VTS 是管理员时，Demon 也要用管理员启动）"));
            m_petCheck->setChecked(false);
        }
    });
    connect(reconnect, &QPushButton::clicked, this, [this]() { m_controller->reconnectLive2d(); });
    connect(send, &QPushButton::clicked, this, [this]() {
        m_controller->injectMouth(m_mouthSlider->value() / 100.0);
    });
    connect(sweep, &QPushButton::clicked, this, [this]() {
        auto* timer = new QTimer(this);
        auto* step = new int(0);
        timer->setInterval(60);
        connect(timer, &QTimer::timeout, this, [this, timer, step]() {
            const double v = std::sin((*step) / 12.0 * 3.14159) * 0.8 + 0.2;
            m_controller->injectMouth(qBound(0.0, v, 1.0));
            if (++(*step) > 80) {
                timer->stop();
                timer->deleteLater();
                delete step;
                m_controller->injectMouth(0.0);
            }
        });
        timer->start();
    });

    return page;
}

void MainWindow::refreshStatus()
{
    const Config& cfg = m_controller->config();
    if (m_epLabel) {
        m_epLabel->setText(QStringLiteral("http://%1:%2").arg(cfg.host).arg(cfg.port));
        const UpstreamConfig* up = nullptr;
        for (const UpstreamConfig& u : cfg.upstreams) {
            if (u.id == cfg.effectiveUpstreamId()) {
                up = &u;
                break;
            }
        }
        m_upstreamLabel->setText(up ? QStringLiteral("%1（%2）").arg(up->baseUrl, up->model)
                                    : QStringLiteral("未配置"));
        m_modelLabel->setText(cfg.modelId);
        m_voiceLabel->setText(cfg.voice.provider.isEmpty()
                              ? QStringLiteral("语音后端未选择")
                              : (cfg.voice.provider == QStringLiteral("qwen")
                                     ? QStringLiteral("千问 %1 / %2").arg(cfg.voice.qwen.model, cfg.voice.qwen.voice)
                                     : QStringLiteral("本地 GPT-SoVITS / %1").arg(cfg.voice.profile)));
    }
    m_footer->setText(QStringLiteral("接口 http://%1:%2   ·   上游 %3   ·   语音 %4   ·   角色绑定 %5")
                          .arg(cfg.host)
                          .arg(cfg.port)
                          .arg(cfg.effectiveUpstreamId())
                          .arg(cfg.voice.provider.isEmpty()
                                   ? QStringLiteral("未选择")
                                   : (cfg.voice.provider == QStringLiteral("qwen")
                                          ? QStringLiteral("qwen/%1").arg(cfg.voice.qwen.voice)
                                          : cfg.voice.endpoint))
                          .arg(cfg.characterVoices.size()));
}

void MainWindow::refreshApiTable()
{
    const Config& cfg = m_controller->config();
    m_apiTable->setRowCount(0);
    for (const UpstreamConfig& u : cfg.upstreams) {
        const int row = m_apiTable->rowCount();
        m_apiTable->insertRow(row);
        m_apiTable->setItem(row, 0, item(u.id));
        m_apiTable->setItem(row, 1, item(u.baseUrl));
        m_apiTable->setItem(row, 2, item(u.model));
        m_apiTable->setItem(row, 3, item(u.apiKey));
    }
    m_defaultUpstream->setText(cfg.effectiveUpstreamId());
}

void MainWindow::saveApiTable()
{
    QVector<UpstreamConfig> ups;
    for (int row = 0; row < m_apiTable->rowCount(); ++row) {
        auto text = [this, row](int col) {
            QTableWidgetItem* it = m_apiTable->item(row, col);
            return it ? it->text().trimmed() : QString();
        };
        UpstreamConfig u;
        u.id = text(0);
        u.baseUrl = text(1);
        u.model = text(2);
        u.apiKey = text(3);
        if (!u.id.isEmpty() && !u.baseUrl.isEmpty()) {
            ups.append(u);
        }
    }
    auto& cfg = m_controller->mutableConfig();
    cfg.upstreams = ups;
    cfg.defaultUpstreamId = m_defaultUpstream->text().trimmed();
    m_controller->saveConfig();
    m_controller->reloadConfig();
    refreshApiTable();
    refreshStatus();
}

void MainWindow::refreshVoiceTable()
{
    const Config& cfg = m_controller->config();
    m_voiceTable->setRowCount(0);
    for (const VoiceProfileConfig& p : cfg.voiceProfiles) {
        const int row = m_voiceTable->rowCount();
        m_voiceTable->insertRow(row);
        m_voiceTable->setItem(row, 0, item(p.id));
        m_voiceTable->setItem(row, 1, item(p.name));
        QString refShow = p.refAudio;
        const QString baseDir = QCoreApplication::applicationDirPath() + QLatin1Char('/');
        if (refShow.startsWith(baseDir)) {
            refShow = refShow.mid(baseDir.size());
        }
        m_voiceTable->setItem(row, 2, item(refShow));
        m_voiceTable->setItem(row, 3, item(p.gptWeights));
        m_voiceTable->setItem(row, 4, item(p.sovitsWeights));
        m_voiceTable->setItem(row, 5, item(p.promptText));
    }
    m_voiceTable->setColumnWidth(0, 150);
    m_voiceTable->setColumnWidth(1, 150);
    m_voiceTable->setColumnWidth(2, 260);
    m_voiceTable->setColumnWidth(3, 210);
    m_voiceTable->setColumnWidth(4, 220);
    m_voiceState->setText(QStringLiteral("共 %1 条声线，默认：%2").arg(cfg.voiceProfiles.size()).arg(cfg.voice.profile));
}

void MainWindow::saveVoiceTable()
{
    QVector<VoiceProfileConfig> profiles;
    for (int row = 0; row < m_voiceTable->rowCount(); ++row) {
        auto text = [this, row](int col) {
            QTableWidgetItem* it = m_voiceTable->item(row, col);
            return it ? it->text().trimmed() : QString();
        };
        VoiceProfileConfig p;
        p.id = text(0);
        p.name = text(1);
        p.refAudio = text(2);
        p.gptWeights = text(3);
        p.sovitsWeights = text(4);
        p.promptText = text(5);
        if (!p.id.isEmpty()) {
            profiles.append(p);
        }
    }
    auto& cfg = m_controller->mutableConfig();
    cfg.voiceProfiles = profiles;
    m_controller->saveConfig();
    m_controller->reloadConfig();
    refreshVoicePage();
    refreshCharacterPage();
    refreshStatus();
}

void MainWindow::refreshCharacterPage()
{
    if (!m_charList) {
        return;
    }
    if (m_charList->count() == 0) {
        const QStringList chars = m_controller->listCharacters();
        for (const QString& name : chars) {
            m_charList->addItem(name);
        }
        if (m_charList->count() > 0) {
            m_charList->setCurrentRow(0);
        }
    }
    if (m_currentCharacter.isEmpty() && m_charList->count() > 0) {
        m_currentCharacter = m_charList->currentItem()->text();
    }
    if (m_currentCharacter.isEmpty()) {
        m_charTitle->setText(QStringLiteral("没有找到角色卡"));
        return;
    }

    m_charTitle->setText(m_currentCharacter);
    const QString source = m_controller->config().characterProviders.value(m_currentCharacter, QStringLiteral("local"));
    const QString pill = QStringLiteral("QPushButton{border:2px solid #8b5cf6;border-radius:15px;padding:5px 16px;background:#2a2140;}");
    const QString plain = QStringLiteral("QPushButton{border:1px solid #3a3a55;border-radius:15px;padding:5px 16px;background:transparent;}");
    m_localBtn->setChecked(source == QStringLiteral("local"));
    m_cloudBtn->setChecked(source == QStringLiteral("cloud"));
    m_localBtn->setStyleSheet(source == QStringLiteral("local") ? pill : plain);
    m_cloudBtn->setStyleSheet(source == QStringLiteral("cloud") ? pill : plain);

    // 声线
    const QString bound = m_controller->config().characterVoices.value(m_currentCharacter);
    const QVector<VoiceProfileConfig>& profiles = m_controller->config().voiceProfiles;
    m_charVoiceTable->setRowCount(0);
    for (const VoiceProfileConfig& p : profiles) {
        if (p.source != source) {
            continue;
        }
        const int row = m_charVoiceTable->rowCount();
        m_charVoiceTable->insertRow(row);
        auto* nameItem = new QTableWidgetItem(p.name.isEmpty() ? p.id : p.name);
        nameItem->setData(Qt::UserRole, p.id);
        m_charVoiceTable->setItem(row, 0, nameItem);
        m_charVoiceTable->setItem(row, 1, item(p.source));
        auto* ops = new QWidget;
        auto* opsLayout = new QHBoxLayout(ops);
        opsLayout->setContentsMargins(0, 0, 0, 0);
        auto* test = new QPushButton(QStringLiteral("试听"));
        auto* del = new QPushButton(QStringLiteral("－"));
        auto* use = new QPushButton(bound == p.id ? QStringLiteral("已选") : QStringLiteral("选用"));
        opsLayout->addWidget(use);
        opsLayout->addWidget(test);
        opsLayout->addWidget(del);
        opsLayout->addStretch();
        m_charVoiceTable->setCellWidget(row, 2, ops);
        connect(use, &QPushButton::clicked, this, [this, id = p.id]() {
            m_controller->setCharacterVoice(m_currentCharacter, id);
            refreshCharacterPage();
        });
        connect(test, &QPushButton::clicked, this, [this, id = p.id]() {
            m_controller->testVoice(id);
        });
        connect(del, &QPushButton::clicked, this, [this, id = p.id]() {
            if (QMessageBox::question(this, QStringLiteral("删除声线"),
                                      QStringLiteral("从全局声线档案里删除「%1」？").arg(id)) != QMessageBox::Yes) {
                return;
            }
            auto& list = m_controller->mutableConfig().voiceProfiles;
            for (int i = 0; i < list.size(); ++i) {
                if (list[i].id == id) {
                    list.removeAt(i);
                    break;
                }
            }
            m_controller->saveConfig();
            m_controller->reloadConfig();
            refreshCharacterPage();
        });
    }

    // Live2D
    const QStringList models = m_controller->live2dModels();
    const QString currentModel = m_controller->config().characterModels.value(m_currentCharacter);
    m_charModelTable->setRowCount(0);
    for (const QString& model : models) {
        const int row = m_charModelTable->rowCount();
        m_charModelTable->insertRow(row);
        m_charModelTable->setItem(row, 0, item(model + (model == currentModel ? QStringLiteral("  ✓") : QString())));
        auto* ops = new QWidget;
        auto* opsLayout = new QHBoxLayout(ops);
        opsLayout->setContentsMargins(0, 0, 0, 0);
        auto* bind = new QPushButton(model == currentModel ? QStringLiteral("已绑定") : QStringLiteral("绑定"));
        auto* load = new QPushButton(QStringLiteral("加载"));
        opsLayout->addWidget(bind);
        opsLayout->addWidget(load);
        opsLayout->addStretch();
        m_charModelTable->setCellWidget(row, 1, ops);
        connect(bind, &QPushButton::clicked, this, [this, model]() {
            m_controller->setCharacterModel(m_currentCharacter, model);
            refreshCharacterPage();
        });
        connect(load, &QPushButton::clicked, this, [this, model]() {
            m_controller->loadLive2dModel(model);
        });
    }

    m_charState->setText(QStringLiteral("角色 %1：%2 个声线，%3 个可用模型")
                             .arg(m_currentCharacter)
                             .arg(m_charVoiceTable->rowCount())
                             .arg(models.size()));
}

void MainWindow::refreshVoicePage()
{
    if (!m_voiceTabs) {
        return;
    }
    const Config& cfg = m_controller->config();
    m_translateCheck->setChecked(cfg.voice.translateToJa);
    m_gsvEndpoint->setText(cfg.voice.endpoint);
    m_speedSlider->setValue(int(cfg.voice.speed * 100));
    m_cloudModel->setCurrentText(cfg.voice.qwen.model);
    if (m_cloudKey->text().isEmpty()) {
        m_cloudKey->setText(cfg.voice.qwen.apiKey);
    }

    // 绑定表
    const QStringList chars = m_controller->listCharacters();
    m_bindTable->setRowCount(0);
    for (const QString& ch : chars) {
        const int row = m_bindTable->rowCount();
        m_bindTable->insertRow(row);
        m_bindTable->setItem(row, 0, item(ch));
        const QString source = cfg.characterProviders.value(ch, QStringLiteral("local"));
        m_bindTable->setItem(row, 1, item(source));
        auto* combo = new QComboBox;
        combo->addItem(QStringLiteral("（默认）"), QString());
        for (const VoiceProfileConfig& p : cfg.voiceProfiles) {
            if (p.source == source) {
                combo->addItem(p.name.isEmpty() ? p.id : p.name, p.id);
            }
        }
        const QString bound = cfg.characterVoices.value(ch);
        const int idx = combo->findData(bound);
        if (idx >= 0) {
            combo->setCurrentIndex(idx);
        }
        m_bindTable->setCellWidget(row, 2, combo);
        auto langOf = [this](const QString& pid) {
            for (const VoiceProfileConfig& p : m_controller->config().voiceProfiles) {
                if (p.id == pid) return p.language;
            }
            return QStringLiteral("ja");
        };
        m_bindTable->setItem(row, 3, item(langOf(bound)));
        connect(combo, &QComboBox::currentIndexChanged, this, [this, ch, combo](int) {
            const QString pid = combo->currentData().toString();
            m_controller->setCharacterVoice(ch, pid);
            for (int r = 0; r < m_bindTable->rowCount(); ++r) {
                if (m_bindTable->item(r, 0) && m_bindTable->item(r, 0)->text() == ch) {
                    QString lang = QStringLiteral("ja");
                    for (const VoiceProfileConfig& p : m_controller->config().voiceProfiles) {
                        if (p.id == pid) lang = p.language;
                    }
                    if (auto* it = m_bindTable->item(r, 3)) it->setText(lang);
                }
            }
        });
    }

    // 本地 / 云端档案
    m_localVoiceTable->setRowCount(0);
    m_cloudVoiceTable->setRowCount(0);
    for (const VoiceProfileConfig& p : cfg.voiceProfiles) {
        QTableWidget* table = p.source == QStringLiteral("cloud") ? m_cloudVoiceTable : m_localVoiceTable;
        const int row = table->rowCount();
        table->insertRow(row);
        table->setItem(row, 0, item(p.name.isEmpty() ? p.id : p.name));
        table->item(row, 0)->setData(Qt::UserRole, p.id);
        if (p.source == QStringLiteral("cloud")) {
            table->setItem(row, 1, item(p.qwenVoice));
            table->setItem(row, 2, item(p.cloudAudio));
            table->setItem(row, 3, item(p.cloudPreview));
            table->setItem(row, 4, item(p.language));
            for (int col : {2, 3, 4}) {
                if (auto* it = table->item(row, col)) it->setFlags(it->flags() | Qt::ItemIsEditable);
            }
        } else {
            table->setItem(row, 1, item(p.refAudio));
            table->setItem(row, 2, item(p.promptText.left(24)));
            table->setItem(row, 3, item(p.language));
            for (int col : {1, 2, 3}) {
                if (auto* it = table->item(row, col)) it->setFlags(it->flags() | Qt::ItemIsEditable);
            }
        }
        auto* ops = new QWidget;
        auto* opsLayout = new QHBoxLayout(ops);
        opsLayout->setContentsMargins(0, 0, 0, 0);
        auto* test = new QPushButton(QStringLiteral("试听"));
        opsLayout->addWidget(test);
        opsLayout->addStretch();
        table->setCellWidget(row, p.source == QStringLiteral("cloud") ? 5 : 4, ops);
        connect(test, &QPushButton::clicked, this, [this, id = p.id]() { m_controller->testVoice(id); });
    }
    if (!m_cloudVoiceTable->property("audioPicker").toBool()) {
        m_cloudVoiceTable->setProperty("audioPicker", true);
        connect(m_cloudVoiceTable, &QTableWidget::cellDoubleClicked, this, [this](int row, int col) {
            if (col != 2 && col != 3) return;
            const QString file = QFileDialog::getOpenFileName(
                this, QStringLiteral("选择音频"), QString(),
                QStringLiteral("音频 (*.wav *.mp3 *.m4a *.flac);;所有文件 (*.*)"));
            if (file.isEmpty()) return;
            if (auto* it = m_cloudVoiceTable->item(row, col)) {
                it->setText(file);
            }
        });
    }

    if (!m_localVoiceTable->property("hooked").toBool()) {
        m_localVoiceTable->setProperty("hooked", true);
        m_cloudVoiceTable->setProperty("hooked", true);
        auto handle = [this](QTableWidget* t, QTableWidgetItem* it) {
            if (!it) return;
            const int col = it->column();
            const QString id = t->item(it->row(), 0) ? t->item(it->row(), 0)->data(Qt::UserRole).toString() : QString();
            if (id.isEmpty()) return;
            QString field;
            if (t == m_cloudVoiceTable) {
                if (col == 2) field = QStringLiteral("cloudAudio");
                else if (col == 3) field = QStringLiteral("cloudPreview");
                else if (col == 4) field = QStringLiteral("language");
            } else {
                if (col == 1) field = QStringLiteral("refAudio");
                else if (col == 2) field = QStringLiteral("promptText");
                else if (col == 3) field = QStringLiteral("language");
            }
            if (!field.isEmpty()) m_controller->updateVoiceProfile(id, field, it->text());
        };
        connect(m_localVoiceTable, &QTableWidget::itemChanged, this, [this, handle](QTableWidgetItem* it) { handle(m_localVoiceTable, it); });
        connect(m_cloudVoiceTable, &QTableWidget::itemChanged, this, [this, handle](QTableWidgetItem* it) { handle(m_cloudVoiceTable, it); });
    }

    m_voiceMsg->setText(QStringLiteral("当前后端：%1 / %2，共 %3 个声线档案")
                            .arg(cfg.voice.provider, cfg.voice.qwen.model)
                            .arg(cfg.voiceProfiles.size()));
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    event->accept();
    QCoreApplication::quit();
}
