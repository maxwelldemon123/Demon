#include "LocalPetWindow.h"

#include "../util/Log.h"

#include <QCoreApplication>
#include <QFileInfo>
#include <QGuiApplication>
#include <QMouseEvent>
#include <QScreen>
#include <QTimer>
#include <QUrl>
#include <QUrlQuery>
#include <QWebEngineSettings>
#include <QWheelEvent>

#ifdef Q_OS_WIN
#include <windows.h>
#endif

namespace {

QString webRoot()
{
    const QString exeWeb = QCoreApplication::applicationDirPath() + QStringLiteral("/web");
    if (QFileInfo::exists(exeWeb + QStringLiteral("/localpet/index.html"))) {
        return exeWeb;
    }
    return QStringLiteral("E:/dshwork/dsh-demon/apps/demon/web");
}

} // namespace

LocalPetWindow::LocalPetWindow(QWidget* parent)
    : QWebEngineView(parent)
{
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::Tool);
    setAttribute(Qt::WA_TranslucentBackground, true);
    setAttribute(Qt::WA_ShowWithoutActivating, true);
    setWindowTitle(QStringLiteral("Demon Local Pet"));
    setContextMenuPolicy(Qt::NoContextMenu);
    setStyleSheet(QStringLiteral("background: transparent;"));
    page()->setBackgroundColor(Qt::transparent);
    settings()->setAttribute(QWebEngineSettings::LocalContentCanAccessFileUrls, true);
    settings()->setAttribute(QWebEngineSettings::LocalContentCanAccessRemoteUrls, true);
    settings()->setAttribute(QWebEngineSettings::ShowScrollBars, false);

    connect(this, &QWebEngineView::loadFinished, this, [this](bool ok) {
        m_ready = ok;
        attachInputFilter();
        Log::info(QStringLiteral("本地桌宠：页面加载 %1").arg(ok ? QStringLiteral("成功") : QStringLiteral("失败")));
    });
}

bool LocalPetWindow::start(const QString& modelDir, const QString& modelFile)
{
    const QString root = webRoot();
    const QString index = root + QStringLiteral("/localpet/index.html");
    if (!QFileInfo::exists(index)) {
        Log::warn(QStringLiteral("本地桌宠：找不到 %1").arg(index));
        return false;
    }

    QUrl url = QUrl::fromLocalFile(index);
    QUrlQuery query;
    query.addQueryItem(QStringLiteral("base"), modelDir);
    query.addQueryItem(QStringLiteral("model"), modelFile);
    url.setQuery(query);

    const QRect area = QGuiApplication::primaryScreen()->availableGeometry();
    resize(360, 460);
    move(area.right() - width() - 120, area.bottom() - height() - 60);

    load(url);
    show();
    raise();

    if (!m_fpsTimer) {
        m_fpsTimer = new QTimer(this);
        m_fpsTimer->setInterval(5000);
        connect(m_fpsTimer, &QTimer::timeout, this, [this]() {
            if (!m_ready) {
                return;
            }
            page()->runJavaScript(QStringLiteral("window.pet && window.pet.fps ? window.pet.fps() : -1"),
                                  [](const QVariant& value) {
                Log::info(QStringLiteral("本地桌宠 FPS：%1").arg(value.toInt()));
            });
        });
    }
    m_fpsTimer->start();

    Log::info(QStringLiteral("本地桌宠：启动 %1").arg(url.toString()));
    return true;
}

void LocalPetWindow::stop()
{
    if (m_fpsTimer) {
        m_fpsTimer->stop();
    }
    hide();
}

void LocalPetWindow::attachInputFilter()
{
    QWidget* target = focusProxy();
    if (!target) {
        target = findChild<QWidget*>();
    }
    if (target && target != m_inputTarget) {
        target->installEventFilter(this);
        m_inputTarget = target;
        Log::info(QStringLiteral("本地桌宠：输入过滤器已挂载"));
    }
}

void LocalPetWindow::setExpression(const QString& expressionFile)
{
    if (!m_ready || expressionFile.isEmpty()) {
        return;
    }
    QString name = expressionFile;
    if (name.endsWith(QStringLiteral(".exp3.json"))) {
        name.chop(10);
    } else if (name.endsWith(QStringLiteral(".exp3"))) {
        name.chop(5);
    }
    if (name.isEmpty()) {
        return;
    }
    if (m_expressionLogCount++ < 8) {
        Log::info(QStringLiteral("本地桌宠：表情 %1").arg(name));
    }
    const QString js = QStringLiteral("window.pet && window.pet.setExpression(%1);")
                           .arg(QStringLiteral("\"%1\"").arg(name));
    page()->runJavaScript(js);
}

void LocalPetWindow::setMouth(double value)
{
    if (!m_ready) {
        return;
    }
    const QString js = QStringLiteral("window.pet && window.pet.setMouth(%1);")
                           .arg(QString::number(qBound(0.0, value, 1.0), 'f', 3));
    page()->runJavaScript(js);
}

void LocalPetWindow::setClickThrough(bool on)
{
#ifdef Q_OS_WIN
    HWND hwnd = reinterpret_cast<HWND>(winId());
    LONG ex = GetWindowLongW(hwnd, GWL_EXSTYLE);
    if (on) {
        ex |= WS_EX_TRANSPARENT | WS_EX_NOACTIVATE;
    } else {
        ex &= ~(WS_EX_TRANSPARENT | WS_EX_NOACTIVATE);
    }
    SetWindowLongW(hwnd, GWL_EXSTYLE, ex);
    Log::info(QStringLiteral("本地桌宠：点击穿透 %1").arg(on ? 1 : 0));
#else
    Q_UNUSED(on);
#endif
}

bool LocalPetWindow::eventFilter(QObject* watched, QEvent* event)
{
    if (watched == m_inputTarget) {
        if (event->type() == QEvent::MouseButtonPress) {
            auto* mouse = static_cast<QMouseEvent*>(event);
            if (mouse->button() == Qt::RightButton) {
                m_dragging = true;
                m_dragOffset = mouse->globalPosition().toPoint() - frameGeometry().topLeft();
                return true;
            }
        } else if (event->type() == QEvent::MouseMove && m_dragging) {
            auto* mouse = static_cast<QMouseEvent*>(event);
            move(mouse->globalPosition().toPoint() - m_dragOffset);
            return true;
        } else if (event->type() == QEvent::MouseButtonRelease) {
            auto* mouse = static_cast<QMouseEvent*>(event);
            if (mouse->button() == Qt::RightButton) {
                m_dragging = false;
                return true;
            }
        } else if (event->type() == QEvent::Wheel) {
            auto* wheel = static_cast<QWheelEvent*>(event);
            const double steps = wheel->angleDelta().y() / 120.0;
            if (qAbs(steps) < 0.01) {
                return true;
            }
            const QPoint center = frameGeometry().center();
            const double factor = qPow(1.08, steps);
            int newW = qBound(240, int(width() * factor), 1000);
            int newH = qBound(300, int(height() * factor), 1200);
            resize(newW, newH);
            move(center - QPoint(newW / 2, newH / 2));
            return true;
        }
    }
    return QWebEngineView::eventFilter(watched, event);
}
