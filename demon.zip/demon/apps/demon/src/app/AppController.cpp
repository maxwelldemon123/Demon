#include "AppController.h"

#include "util/Log.h"
#include "util/TextSplit.h"
#include "live2d/LipSync.h"
#include "live2d/VtsClient.h"
#include "ui/MainWindow.h"
#include "ui/PetWindow.h"
#include "ui/Live2DWindow.h"
#include "dsh/DshClient.h"
#include "voice/AudioPlayer.h"
#include "voice/TtsClient.h"

#include <QAction>
#include <QActionGroup>
#include <QApplication>
#include <QDateTime>
#include <QDir>
#include <QDesktopServices>
#include <QUrl>
#include <QDir>
#include <QFile>
#include <QGuiApplication>
#include <QJsonDocument>
#include <QProcess>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QScreen>
#include <QMessageBox>
#include <QSettings>

#ifdef Q_OS_WIN
#include <windows.h>
#include <tlhelp32.h>
#endif
#include <QSharedMemory>
#include <QJsonObject>
#include <QDirIterator>
#include <QMenu>
#include <QAudioDevice>
#include <QMediaDevices>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QPainter>
#include <QPixmap>
#include <QProcess>
#include <QJsonArray>
#include <QSystemTrayIcon>
#include <QThread>
#include <QTimer>
#include <QTcpSocket>

namespace {
bool spawnCommandLine(const QString& commandLine);
QString defaultBrowserExe();
} // namespace


namespace {

// 去掉（）()【】[] 里的舞台提示，并把提示文本收集起来用于情绪判断
QString stripStageDirections(const QString& text, QStringList* hints)
{
    static const QRegularExpression patterns[] = {
        QRegularExpression(QStringLiteral("（[^）]*）")),
        QRegularExpression(QStringLiteral("\\([^)]*\\)")),
        QRegularExpression(QStringLiteral("【[^】]*】")),
        QRegularExpression(QStringLiteral("\\[[^\\]]*\\]")),
    };
    QString out = text;
    for (const auto& re : patterns) {
        auto it = re.globalMatch(out);
        while (it.hasNext()) {
            const auto m = it.next();
            if (hints) {
                QString inner = m.captured(0);
                inner.remove(0, 1);
                inner.chop(1);
                inner = inner.trimmed();
                if (!inner.isEmpty()) {
                    hints->append(inner);
                }
            }
        }
        out.remove(re);
    }
    out = out.trimmed();
    return out;
}

QString detectActionFromHints(const QStringList& hints, const QString& text)
{
    // 动作词 -> 桌宠动作 id（动作层是参数动画，模型没有 Motions 也能做）
    static const QVector<QPair<QString, QString>> rules = {
        {QStringLiteral("点头"), QStringLiteral("nod")},
        {QStringLiteral("うなず"), QStringLiteral("nod")},
        {QStringLiteral("頷"), QStringLiteral("nod")},
        {QStringLiteral("颔首"), QStringLiteral("nod")},
        {QStringLiteral("鞠躬"), QStringLiteral("bow")},
        {QStringLiteral("お辞儀"), QStringLiteral("bow")},
        {QStringLiteral("頭を下げ"), QStringLiteral("bow")},
        {QStringLiteral("弯腰"), QStringLiteral("bow")},
        {QStringLiteral("摇头"), QStringLiteral("shake")},
        {QStringLiteral("首を振"), QStringLiteral("shake")},
        {QStringLiteral("かぶり"), QStringLiteral("shake")},
        {QStringLiteral("甩头"), QStringLiteral("shake")},
        {QStringLiteral("尾巴"), QStringLiteral("tail")},
        {QStringLiteral("尾尖"), QStringLiteral("tail")},
        {QStringLiteral("鲸尾"), QStringLiteral("tail")},
        {QStringLiteral("摇尾"), QStringLiteral("tail")},
        {QStringLiteral("摆尾"), QStringLiteral("tail")},
        {QStringLiteral("甩尾"), QStringLiteral("tail")},
        {QStringLiteral("摇尾巴"), QStringLiteral("tail")},
        {QStringLiteral("尻尾"), QStringLiteral("tail")},
        {QStringLiteral("しっぽ"), QStringLiteral("tail")},
    };
    for (const QString& hint : hints) {
        for (const auto& rule : rules) {
            if (hint.contains(rule.first)) {
                return rule.second;
            }
        }
    }
    for (const auto& rule : rules) {
        if (text.contains(rule.first)) {
            return rule.second;
        }
    }
    return QString();
}

QString emotionFromHints(const QStringList& hints)
{
    static const QVector<QPair<QString, QString>> rules = {
        {QStringLiteral("笑"), QStringLiteral("happy")},
        {QStringLiteral("开心"), QStringLiteral("happy")},
        {QStringLiteral("哭"), QStringLiteral("sad")},
        {QStringLiteral("难过"), QStringLiteral("sad")},
        {QStringLiteral("生气"), QStringLiteral("angry")},
        {QStringLiteral("怒"), QStringLiteral("angry")},
        {QStringLiteral("害羞"), QStringLiteral("shy")},
        {QStringLiteral("红到耳"), QStringLiteral("shy")},
        {QStringLiteral("发烫"), QStringLiteral("shy")},
        {QStringLiteral("脸热"), QStringLiteral("shy")},
        {QStringLiteral("小鳍"), QStringLiteral("shy")},
        {QStringLiteral("漏拍"), QStringLiteral("surprised")},
        {QStringLiteral("脸红"), QStringLiteral("shy")},
        {QStringLiteral("小声"), QStringLiteral("shy")},
        {QStringLiteral("惊"), QStringLiteral("surprised")},
        {QStringLiteral("疑惑"), QStringLiteral("confused")},
        {QStringLiteral("叹气"), QStringLiteral("tired")},
        {QStringLiteral("攥紧"), QStringLiteral("shy")},
        {QStringLiteral("声音细"), QStringLiteral("shy")},
        {QStringLiteral("困"), QStringLiteral("tired")},
    };
    for (const QString& hint : hints) {
        for (const auto& rule : rules) {
            if (hint.contains(rule.first)) {
                return rule.second;
            }
        }
    }
    return QString();
}

} // namespace

namespace {

QByteArray jsonErrorBody(const QString& message)
{
    QJsonObject error;
    error.insert(QStringLiteral("message"), message);
    QJsonObject root;
    root.insert(QStringLiteral("error"), error);
    return QJsonDocument(root).toJson(QJsonDocument::Compact);
}

QByteArray sseData(const QByteArray& payload)
{
    QByteArray out = "data: ";
    out += payload;
    out += "\n\n";
    return out;
}

} // namespace

namespace {

/**
 * 单次流式转发任务。
 *   - parent 设为 reply：reply 销毁时它一起销毁
 *   - 只捕获 this，不捕获外部局部变量
 */
class StreamJob : public QObject {
public:
    StreamJob(QNetworkReply* reply, const std::shared_ptr<HttpStream>& stream, QObject* owner, int keepAliveMs)
        : QObject(reply)
        , m_reply(reply)
        , m_stream(stream)
    {
        QObject::connect(reply, &QNetworkReply::readyRead, this, [this]() { onReadyRead(); });
        QObject::connect(reply, &QNetworkReply::finished, this, [this]() { onFinished(); });
        if (m_stream && m_stream->socket) {
            QObject::connect(m_stream->socket, &QTcpSocket::disconnected, this, [this]() { onClientGone(); });
        }
        if (keepAliveMs > 0) {
            m_keepAlive = new QTimer(this);
            m_keepAlive->setInterval(keepAliveMs);
            QObject::connect(m_keepAlive, &QTimer::timeout, this, [this]() {
                if (m_stream) {
                    m_stream->writeChunk(":keep-alive\n\n");
                }
            });
            m_keepAlive->start();
        }

        Log::info(QStringLiteral("流式任务已创建（保活 %1 ms）").arg(keepAliveMs));
    }

private:
    void onReadyRead()
    {
        if (!m_reply) {
            return;
        }
        const QByteArray chunk = m_reply->readAll();
        m_received += chunk.size();
        if (m_stream) {
            m_stream->writeChunk(chunk);
        }
    }

    void onFinished()
    {
        if (m_done) {
            return;
        }
        m_done = true;

        if (m_reply && m_reply->error() != QNetworkReply::NoError) {
            // 无论是首包就失败还是中途断开，都要让客户端收到明确的结束标记，
            // 否则酒馆会一直转圈等 token。
            Log::error(QStringLiteral("上游失败：%1（已收到 %2 字节）")
                           .arg(m_reply->errorString())
                           .arg(m_received));
            if (m_stream) {
                const QByteArray payload = QStringLiteral(
                    "{\"error\":{\"message\":\"上游中断：%1\"}}")
                                               .arg(m_reply->errorString())
                                               .toUtf8();
                m_stream->writeChunk("data: " + payload + "\n\n");
                m_stream->writeChunk("data: [DONE]\n\n");
            }
        } else if (m_received == 0 && m_stream) {
            m_stream->writeChunk("data: [DONE]\n\n");
        }

        if (m_keepAlive) {
            m_keepAlive->stop();
        }
        Log::info(QStringLiteral("流式结束，共转发 %1 字节").arg(m_received));
        if (m_stream) {
            m_stream->end();
        }
        if (m_reply) {
            m_reply->deleteLater();
        }
    }

    void onClientGone()
    {
        if (m_done) {
            return;
        }
        m_done = true;
        Log::warn(QStringLiteral("客户端提前断开，中止上游"));
        if (m_reply) {
            m_reply->abort();
        }
    }

    QTimer* m_keepAlive = nullptr;
    QPointer<QNetworkReply> m_reply;
    std::shared_ptr<HttpStream> m_stream;
    qint64 m_received = 0;
    bool m_done = false;
};

} // namespace

AppController::AppController(QObject* parent)
    : QObject(parent)
{
}

AppController::~AppController()
{
    if (m_petWindow && m_petWindow->active()) {
        setVtsDesktopPet(false, QStringLiteral("#000000"));
    }
}

bool AppController::start()
{
    const QString exeDir = QCoreApplication::applicationDirPath();
    m_dataDir = exeDir + QStringLiteral("/data");
    QDir().mkpath(m_dataDir);

    Log::init(m_dataDir + QStringLiteral("/demon.log"));

    Log::info(QStringLiteral("Demon 启动，exe 目录：%1").arg(exeDir));

    // 单实例：避免用户重复双击导致“端口被占用”的困惑
    m_instanceLock = new QSharedMemory(QStringLiteral("DemonEngineInstance-v1"), this);
    if (!m_instanceLock->create(1)) {
        Log::warn(QStringLiteral("已有实例在运行，本次启动退出"));
        QMessageBox::information(
            nullptr, QStringLiteral("Demon"),
            QStringLiteral("Demon 已经在运行了。\n\n"
                           "如果没看到图标，请点任务栏右下角的 ^ 展开隐藏图标，\n"
                           "里面应该有一个紫色的 D。"));
        return false;
    }

    m_config = Config::load(exeDir + QStringLiteral("/config.json"));
    Log::info(QStringLiteral("配置：%1:%2  模型=%3  上游=%4 个")
                  .arg(m_config.host)
                  .arg(m_config.port)
                  .arg(m_config.modelId)
                  .arg(m_config.upstreams.size()));

    // 首次启动自动导入原生桌宠的 EXP 表情（配置文件里没有时）
    if (m_config.petExpressions.isEmpty()) {
        m_config.petExpressions = scanPetExpressions();
        if (!m_config.petExpressions.isEmpty()) {
            saveConfig();
            Log::info(QStringLiteral("[pet] 首次启动自动导入 %1 个表情").arg(m_config.petExpressions.size()));
        }
    }

    m_net = std::make_unique<QNetworkAccessManager>();

    // 预热本地判定模型：启动后 ping 一次网关，触发 llama-server 加载并常驻
    QTimer::singleShot(5000, this, [this]() {
        if (!m_net) { return; }
        QJsonObject msg{{QStringLiteral("role"), QStringLiteral("user")},
                        {QStringLiteral("content"), QStringLiteral("ping")}};
        QJsonArray arr; arr.append(msg);
        QJsonObject body{{QStringLiteral("model"), QStringLiteral("local-vl")},
                         {QStringLiteral("messages"), arr},
                         {QStringLiteral("max_tokens"), 1}};
        QNetworkRequest warmReq(QUrl(QStringLiteral("http://127.0.0.1:8099/v1/chat/completions")));
        warmReq.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
        warmReq.setTransferTimeout(120000);
        QNetworkReply* warmReply = m_net->post(warmReq, QJsonDocument(body).toJson(QJsonDocument::Compact));
        connect(warmReply, &QNetworkReply::finished, this, [warmReply]() {
            Log::info(QStringLiteral("[pet] 预热本地判定模型：%1")
                          .arg(warmReply->error() == QNetworkReply::NoError ? QStringLiteral("就绪")
                                                                            : warmReply->errorString()));
            warmReply->deleteLater();
        });
        Log::info(QStringLiteral("[pet] 预热本地判定模型：已发送 ping"));
    });

    m_dsh = std::make_unique<DshClient>();
    connect(m_dsh.get(), &DshClient::healthChanged, this, [](bool ok, const QString& message) {
        if (!ok) {
            Log::warn(QStringLiteral("dsh-demon 不可用：%1").arg(message));
        }
    });
    m_dsh->health();

    setupVoice();

    // Live2D：VTube Studio
    m_vts = std::make_unique<VtsClient>();
    m_vts->setEndpoint(m_config.live2d.host, m_config.live2d.port);
    m_vts->setTokenFile(m_dataDir + QStringLiteral("/vts-token.json"));
    connect(m_vts.get(), &VtsClient::rawMessage, this, [this](const QString& type, const QJsonObject& data) {
        m_vtsLastResponses.insert(type, data);
        if (type == QStringLiteral("AvailableModelsResponse") && !m_pendingModel.isEmpty()) {
            const QJsonArray models = data.value(QStringLiteral("availableModels")).toArray();
            for (const QJsonValue& value : models) {
                const QJsonObject item = value.toObject();
                if (item.value(QStringLiteral("modelName")).toString() == m_pendingModel) {
                    QJsonObject req;
                    req.insert(QStringLiteral("modelID"), item.value(QStringLiteral("modelID")).toString());
                    if (m_vts) {
                        m_vts->sendRaw(QStringLiteral("ModelLoadRequest"), req);
                    }
                    Log::info(QStringLiteral("请求加载 Live2D 模型：%1").arg(m_pendingModel));
                    break;
                }
            }
            m_pendingModel.clear();
        }
    });

    connect(m_vts.get(), &VtsClient::stateChanged, this, [this](VtsClient::State state, const QString& detail) {
        Log::info(QStringLiteral("VTS 状态：%1 %2").arg(VtsClient::stateName(state), detail));
        if (detail.startsWith(QStringLiteral("model:"))) {
            m_currentModel = detail.mid(6);
            m_activeEmotion.clear();
            loadModelExpressions(m_currentModel, m_vts ? m_vts->modelId() : QString());
            ensureWatermarkHidden();
        }
    });
    m_vts->connectToServer();

    m_server = std::make_unique<HttpServer>();
    m_server->setHandler([this](const HttpRequest& request) { return handleRequest(request); });
    m_server->setStreamHandler([this](const HttpRequest& request, const std::shared_ptr<HttpStream>& stream) {
        if (request.path == QStringLiteral("/voice/speak")) {
            return handleVoiceSpeak(request, stream);
        }
        return handleChatStream(request, stream);
    });

    if (!m_server->listen(m_config.host, m_config.port)) {
        const QString message = QStringLiteral("无法监听 %1:%2，端口可能被占用。\n\n"
                                               "最常见原因：已经有一个 Demon 在运行（看任务管理器）。\n"
                                               "或者别的程序占用了这个端口。\n\n"
                                               "解决办法：先退出已有的 Demon，或修改 config.json 里的 listen.port。")
                                    .arg(m_config.host)
                                    .arg(m_config.port);
        Log::error(message);
        QMessageBox::critical(nullptr, QStringLiteral("Demon 启动失败"), message);
        return false;
    }

    m_startedAtMs = QDateTime::currentMSecsSinceEpoch();
    Log::info(QStringLiteral("HTTP 服务已监听 http://%1:%2").arg(m_config.host).arg(m_server->port()));

    setupTray();

    m_window = std::make_unique<MainWindow>(this);
    m_window->show();

    auto* statusTimer = new QTimer(this);
    statusTimer->setInterval(2000);
    connect(statusTimer, &QTimer::timeout, this, [this]() { notifyUi(); });
    statusTimer->start();

    // VTS 不支持可靠的事件订阅（会断线），改为每 15 秒轮询模型
    auto* modelTimer = new QTimer(this);
    modelTimer->setInterval(15000);
    connect(modelTimer, &QTimer::timeout, this, [this]() {
        if (m_vts && m_vts->state() == VtsClient::State::Ready) {
            m_vts->requestCurrentModel();
        }
    });
    modelTimer->start();

    Log::info(QStringLiteral("主窗口已显示"));
    return true;
}

HttpResponse AppController::handleRequest(const HttpRequest& request)
{
    if (request.path == QStringLiteral("/healthz") || request.path == QStringLiteral("/health")) {
        return handleHealthz(request);
    }
    if (request.path == QStringLiteral("/v1/models") || request.path == QStringLiteral("/models")) {
        return handleModels(request);
    }
    if (request.path == QStringLiteral("/v1/chat/completions") || request.path == QStringLiteral("/chat/completions")) {
        return handleChatCompletions(request);
    }
    if (request.path == QStringLiteral("/launcher/open")) {
        const QString url = QStringLiteral("http://127.0.0.1:%1/").arg(m_config.launcher.stPort);
        openInEdge(url);
        HttpResponse response;
        response.body = QStringLiteral("{\"opened\":\"%1\"}").arg(url).toUtf8();
        return response;
    }
    if (request.path == QStringLiteral("/live2d/status")) {
        return handleLive2dStatus(request);
    }
    if (request.path == QStringLiteral("/live2d/raw")) {
        HttpResponse response;
        if (request.method == QStringLiteral("POST")) {
            const QJsonObject body = QJsonDocument::fromJson(request.body).object();
            sendLive2dRaw(body.value(QStringLiteral("type")).toString(),
                          body.value(QStringLiteral("data")).toObject());
            response.body = R"({"sent":true})";
            return response;
        }
        QString type;
        for (const QString& pair : request.query.split('&', Qt::SkipEmptyParts)) {
            const int eq = pair.indexOf('=');
            if (eq > 0 && pair.left(eq) == QStringLiteral("type")) {
                type = QUrl::fromPercentEncoding(pair.mid(eq + 1).toUtf8());
            }
        }
        response.body = QJsonDocument(lastLive2dResponse(type)).toJson(QJsonDocument::Compact);
        return response;
    }
    if (request.path == QStringLiteral("/live2d/pet")) {
        const QJsonObject body = QJsonDocument::fromJson(request.body).object();
        const bool on = body.value(QStringLiteral("on")).toBool(false);
        const QString color = body.value(QStringLiteral("color")).toString(QStringLiteral("#000000"));
        const bool ok = setVtsDesktopPet(on, color);
        QJsonObject root;
        root.insert(QStringLiteral("ok"), ok);
        root.insert(QStringLiteral("on"), on);
        HttpResponse response;
        response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
        return response;
    }
    if (request.path == QStringLiteral("/live2d/emotion")) {
        const QJsonObject body = QJsonDocument::fromJson(request.body).object();
        const QString emotion = body.value(QStringLiteral("emotion")).toString();
        applyEmotion(emotion);
        QJsonObject root;
        root.insert(QStringLiteral("emotion"), emotion);
        root.insert(QStringLiteral("model"), m_currentModel);
        root.insert(QStringLiteral("applied"), !emotion.isEmpty());
        HttpResponse response;
        response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
        return response;
    }
    if (request.path == QStringLiteral("/live2d/expressions")) {
        QJsonObject root;
        root.insert(QStringLiteral("model"), m_currentModel);
        QJsonArray names;
        const QStringList expressionNames = availableExpressions();
        const QStringList expressionFiles = availableExpressionFiles();
        for (int i = 0; i < expressionNames.size(); ++i) {
            QJsonObject item;
            item.insert(QStringLiteral("name"), expressionNames.at(i));
            item.insert(QStringLiteral("file"), i < expressionFiles.size() ? expressionFiles.at(i) : QString());
            names.append(item);
        }
        root.insert(QStringLiteral("expressions"), names);
        HttpResponse response;
        response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
        return response;
    }
    if (request.path == QStringLiteral("/live2d/envelope")) {
        const QVector<float> envelope = LipSync::envelope(request.body, 30);
        float peak = 0.0f;
        double sum = 0.0;
        for (float v : envelope) {
            peak = qMax(peak, v);
            sum += v;
        }
        QJsonObject root;
        root.insert(QStringLiteral("frames"), envelope.size());
        root.insert(QStringLiteral("seconds"), envelope.size() / 30.0);
        root.insert(QStringLiteral("peak"), peak);
        root.insert(QStringLiteral("average"), envelope.isEmpty() ? 0.0 : sum / envelope.size());
        HttpResponse response;
        response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
        return response;
    }
    if (request.path == QStringLiteral("/live2d/test")) {
        return handleLive2dTest(request);
    }
    if (request.path == QStringLiteral("/voice/status")) {
        return handleVoiceStatus(request);
    }
    if (request.path == QStringLiteral("/voice/playback")) {
        // 酒馆插件在音频真正开始播放/结束时通知，用来对齐口型时间轴
        const QJsonObject body = QJsonDocument::fromJson(request.body).object();
        const QString phase = body.value(QStringLiteral("phase")).toString();
        if (m_mouthTimer && !m_mouthEnvelope.isEmpty()) {
            if (phase == QStringLiteral("start")) {
                m_mouthAwaitingPlayback = false;
                m_mouthIndex = 0;
                m_mouthSmoothed = 0.0;
                m_mouthTimer->start();
                Log::info(QStringLiteral("口型对齐：播放开始，重置到第 0 帧"));
            } else if (phase == QStringLiteral("tick")) {
                const double position = body.value(QStringLiteral("t")).toDouble(-1.0);
                if (position >= 0.0) {
                    if (m_mouthTimer->isActive()) { m_mouthTimer->stop(); }
                    const int index = static_cast<int>(position * 30.0);
                    if (index < m_mouthEnvelope.size()) {
                        const double raw = qMin(1.0, m_mouthEnvelope.at(index) * 1.6);
                        m_mouthSmoothed = (raw > m_mouthSmoothed) ? (m_mouthSmoothed * 0.30 + raw * 0.70) : (m_mouthSmoothed * 0.70 + raw * 0.30);
                        if (nativePetActive()) { sendToNativePet(QStringLiteral("mouth ") + QString::number(m_mouthSmoothed, 'f', 3)); }
                    } else if (nativePetActive()) {
                        sendToNativePet(QStringLiteral("mouth 0"));
                    }
                }
            } else if (phase == QStringLiteral("stop")) {
                m_mouthTimer->stop();
                if (nativePetActive()) {
                    sendToNativePet(QStringLiteral("mouth 0"));
                }
                Log::info(QStringLiteral("口型对齐：播放结束"));
            }
        }
        HttpResponse response;
        response.body = QByteArray("{\"ok\":true}");
        return response;
    }
    if (request.path == QStringLiteral("/voice/speak")) {
        HttpResponse response;
        response.status = 405;
        response.body = jsonErrorBody(QStringLiteral("/voice/speak 只接受 POST"));
        return response;
    }
    if (request.path == QStringLiteral("/")) {
        HttpResponse response;
        response.contentType = QStringLiteral("text/plain; charset=utf-8");
        response.body = QStringLiteral("Demon engine is running.\n"
                                       "GET  /healthz\n"
                                       "GET  /v1/models\n"
                                       "POST /v1/chat/completions  (stream=true 走 SSE)\n")
                            .toUtf8();
        return response;
    }

    HttpResponse response;
    response.status = 404;
    response.body = jsonErrorBody(QStringLiteral("not found: %1").arg(request.path));
    return response;
}

HttpResponse AppController::handleHealthz(const HttpRequest&)
{
    const qint64 uptimeMs = QDateTime::currentMSecsSinceEpoch() - m_startedAtMs;
    const UpstreamConfig* up = pickUpstream(QString());

    const QString json = QStringLiteral(R"({
  "status": "ok",
  "version": "1.2.0",
  "uptimeSeconds": %1,
  "model": "%2",
  "upstreams": %3,
  "defaultUpstream": "%4",
  "upstreamBaseUrl": "%5",
  "voice": { "endpoint": "%6", "profile": "%7" }
})")
                             .arg(uptimeMs / 1000)
                             .arg(m_config.modelId)
                             .arg(m_config.upstreams.size())
                             .arg(m_config.effectiveUpstreamId())
                             .arg(up ? up->baseUrl : QString())
                             .arg(m_config.voice.endpoint, m_config.voice.profile);

    HttpResponse response;
    response.body = json.toUtf8();
    return response;
}

HttpResponse AppController::handleModels(const HttpRequest&)
{
    const QString json = QStringLiteral(R"({
  "object": "list",
  "data": [
    { "id": "%1", "object": "model", "created": %2, "owned_by": "demon" }
  ]
})")
                             .arg(m_config.modelId)
                             .arg(m_startedAtMs / 1000);

    HttpResponse response;
    response.body = json.toUtf8();
    return response;
}

HttpResponse AppController::handleChatCompletions(const HttpRequest&)
{
    // 非流式请求暂不支持（酒馆默认走 stream=true）
    HttpResponse response;
    response.status = 501;
    response.body = jsonErrorBody(QStringLiteral("仅支持 stream=true（SSE）；非流式将在后续版本实现"));
    return response;
}

const UpstreamConfig* AppController::pickUpstream(const QString& modelFromRequest) const
{
    // 请求里的 model 若是某个上游的 id 或上游模型名，就路由到它；否则用默认
    if (!modelFromRequest.isEmpty()) {
        for (const UpstreamConfig& u : m_config.upstreams) {
            if (u.id == modelFromRequest || u.model == modelFromRequest) {
                return &u;
            }
        }
    }

    const QString id = m_config.effectiveUpstreamId();
    for (const UpstreamConfig& u : m_config.upstreams) {
        if (u.id == id) {
            return &u;
        }
    }
    return m_config.upstreams.isEmpty() ? nullptr : &m_config.upstreams.first();
}

QByteArray AppController::rewriteModel(const QByteArray& body, const QString& upstreamModel) const
{
    if (upstreamModel.isEmpty()) {
        return body;
    }
    QJsonParseError parseError{};
    const QJsonDocument doc = QJsonDocument::fromJson(body, &parseError);
    if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
        return body;
    }
    QJsonObject root = doc.object();
    root.insert(QStringLiteral("model"), upstreamModel);
    return QJsonDocument(root).toJson(QJsonDocument::Compact);
}

bool AppController::handleChatStream(const HttpRequest& request, const std::shared_ptr<HttpStream>& stream)
{
    if (request.path != QStringLiteral("/v1/chat/completions")
        && request.path != QStringLiteral("/chat/completions")) {
        return false;
    }

    QJsonParseError parseError{};
    const QJsonDocument doc = QJsonDocument::fromJson(request.body, &parseError);
    if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
        stream->writeHead(400, "application/json; charset=utf-8");
        stream->writeChunk(jsonErrorBody(QStringLiteral("请求体不是合法 JSON")));
        stream->end();
        return true;
    }

    const QJsonObject root = doc.object();

    // 提前判定：用户消息里的括号描写先交给本地 4B，等 TTS 请求到达时结果已在缓存里
    {
        QString userText;
        const QJsonArray messages = root.value(QStringLiteral("messages")).toArray();
        for (const QJsonValue& value : messages) {
            const QJsonObject item = value.toObject();
            if (item.value(QStringLiteral("role")).toString() != QStringLiteral("user")) { continue; }
            const QJsonValue content = item.value(QStringLiteral("content"));
            if (content.isString()) {
                userText = content.toString();
            } else if (content.isArray()) {
                QString joined;
                for (const QJsonValue& part : content.toArray()) {
                    const QJsonObject piece = part.toObject();
                    if (piece.value(QStringLiteral("type")).toString() == QStringLiteral("text")) {
                        joined += piece.value(QStringLiteral("text")).toString();
                    }
                }
                userText = joined;
            }
        }
        if (!userText.isEmpty()) {
            QStringList hints;
            stripStageDirections(userText, &hints);
            if (!hints.isEmpty()) { classifyHintsAsync(hints.join(QStringLiteral("；"))); }
        }
    }

    if (!root.value(QStringLiteral("stream")).toBool(false)) {
        return false; // 交给普通处理器（返回 501）
    }

    const UpstreamConfig* upstream = pickUpstream(root.value(QStringLiteral("model")).toString());
    if (!upstream) {
        stream->writeHead(503, "application/json; charset=utf-8");
        stream->writeChunk(jsonErrorBody(QStringLiteral("没有配置上游（config.json 的 upstreams 为空）")));
        stream->end();
        return true;
    }

    QUrl url(upstream->baseUrl);
    QString path = url.path();
    if (!path.endsWith(QLatin1Char('/'))) {
        path += QLatin1Char('/');
    }
    path += QStringLiteral("chat/completions");
    url.setPath(path);

    QNetworkRequest netRequest(url);
    netRequest.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    netRequest.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::NoLessSafeRedirectPolicy);
    if (!upstream->apiKey.isEmpty()) {
        netRequest.setRawHeader("Authorization", "Bearer " + upstream->apiKey.toUtf8());
    }

    const QByteArray payload = rewriteModel(request.body, upstream->model);
    Log::info(QStringLiteral("代理到上游 %1（model=%2）").arg(url.toString(), upstream->model));

    // 先把响应头发给客户端，再开始转发；否则 curl/酒馆会以为这不是 HTTP 响应
    stream->writeHead(200, "text/event-stream; charset=utf-8");

    QNetworkReply* reply = m_net->post(netRequest, payload);

    // 把转发工作交给一个独立的 job 对象（parent=reply，生命周期由 Qt 管理），
    // 避免闭包捕获局部变量导致的悬空指针。
    new StreamJob(reply, stream, this, m_config.keepAliveSeconds * 1000);

    return true;
}


/* ------------------------------- 语音 ------------------------------- */

QVector<VoiceProfile> AppController::buildVoiceProfiles() const
{
    QVector<VoiceProfile> profiles;
    profiles.reserve(m_config.voiceProfiles.size());
    for (const VoiceProfileConfig& p : m_config.voiceProfiles) {
        VoiceProfile vp;
        vp.id = p.id;
        vp.name = p.name.isEmpty() ? p.id : p.name;
        vp.gptWeights = p.gptWeights;
        vp.sovitsWeights = p.sovitsWeights;
        vp.refAudio = p.refAudio;
        vp.promptText = p.promptText;
        vp.promptLang = p.promptLang;
        vp.qwenVoice = p.qwenVoice;
        vp.language = p.language;
        vp.cloudAudio = p.cloudAudio;
        vp.cloudPreview = p.cloudPreview;
        vp.source = p.source;
        profiles.append(vp);
    }
    return profiles;
}

void AppController::setupVoice()
{
    m_tts = std::make_unique<TtsClient>();
    m_tts->setEndpoint(m_config.voice.endpoint);
    m_tts->setProvider(m_config.voice.provider, m_config.voice.qwen);

    const QVector<VoiceProfile> profiles = buildVoiceProfiles();
    m_tts->setProfiles(profiles);

    m_activeProfile = m_config.voice.profile;
    if (m_tts->profile(m_activeProfile).id.isEmpty() && !profiles.isEmpty()) {
        m_activeProfile = profiles.first().id;
    }

    m_audio = std::make_unique<AudioPlayer>();
    m_audio->setVolume(m_config.voice.volume);
    m_audio->setDeviceByName(m_config.voice.outputDevice);

    Log::info(QStringLiteral("语音已配置：endpoint=%1 声线=%2 档案=%3")
                  .arg(m_config.voice.endpoint, m_activeProfile)
                  .arg(profiles.size()));
}


HttpResponse AppController::handleVoiceStatus(const HttpRequest&)
{
    QJsonObject voice;
    voice.insert(QStringLiteral("provider"), m_config.voice.provider);
    voice.insert(QStringLiteral("endpoint"), m_config.voice.endpoint);
    if (m_config.voice.provider == QStringLiteral("qwen")) {
        voice.insert(QStringLiteral("qwenModel"), m_config.voice.qwen.model);
        voice.insert(QStringLiteral("qwenVoice"), m_config.voice.qwen.voice);
    }
    voice.insert(QStringLiteral("profile"), m_activeProfile);
    voice.insert(QStringLiteral("speed"), m_config.voice.speed);

    QStringList ids;
    for (const VoiceProfileConfig& p : m_config.voiceProfiles) {
        ids.append(p.id);
    }
    voice.insert(QStringLiteral("profiles"), QJsonArray::fromStringList(ids));

    QJsonObject root;
    root.insert(QStringLiteral("voice"), voice);
    HttpResponse response;
    response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
    return response;
}

bool AppController::handleVoiceSpeak(const HttpRequest& request, const std::shared_ptr<HttpStream>& stream)
{
    // 没选语音后端：明确报错，绝不静默回落到某个本地后端
    if (m_config.voice.provider.isEmpty()) {
        stream->writeHead(503, "application/json; charset=utf-8");
        stream->writeChunk(jsonErrorBody(QStringLiteral("还没有选择语音后端：请在 Demon 的「语音」页选一下「本地 GPT-SoVITS」或「千问 Qwen」")));
        stream->end();
        return true;
    }
    if (request.method != QStringLiteral("POST")) {
        return false;
    }

    const QJsonObject body = QJsonDocument::fromJson(request.body).object();
    const QString text = body.value(QStringLiteral("text")).toString();
    if (text.trimmed().isEmpty()) {
        stream->writeHead(400, "application/json; charset=utf-8");
        stream->writeChunk(jsonErrorBody(QStringLiteral("text 不能为空")));
        stream->end();
        return true;
    }

    if (!m_tts) {
        stream->writeHead(503, "application/json; charset=utf-8");
        stream->writeChunk(jsonErrorBody(QStringLiteral("语音未初始化")));
        stream->end();
        return true;
    }

    QStringList hints;
    const QString spoken = stripStageDirections(text, &hints);

    // 情绪/动作用原文判断（插件把翻译前的原句放在 original），译文只用来配音
    QStringList originalHints;
    QString original = body.value(QStringLiteral("original")).toString();
    if (!original.isEmpty()) { stripStageDirections(original, &originalHints); }


    // 括号描写常被拆成单独一段（上一段全是括号 → 被判"空句"跳过），
    // 所以要把上一段的括号暂存下来，给这一句一起判定；本句自带括号时以本句为准。
    QStringList effectiveHints = originalHints.isEmpty() ? hints : originalHints;
    QString effectiveText = original.isEmpty() ? text : original;
    if (!effectiveHints.isEmpty()) {
        m_pendingHints = effectiveHints.mid(qMax(0, effectiveHints.size() - 3));
    } else if (!m_pendingHints.isEmpty()) {
        effectiveHints = m_pendingHints;
        m_pendingHints.clear();
        Log::info(QStringLiteral("[pet] 沿用上一段括号描写：%1").arg(effectiveHints.join(QStringLiteral("|")).left(40)));
    }
    // 动作关键词（括号里的「点头」「摇尾巴」等）→ 桌宠动作层，放在空句提前返回之前
    QString action = detectActionFromHints(effectiveHints, effectiveText);
    if (action.isEmpty()) { action = detectActionFromHints(hints, text); }
    if (!action.isEmpty()) {
        playPetAction(action);
    }

    if (spoken.isEmpty()) {
        // 整句都是括号提示（动作/心理），没有可读内容
        stream->writeHead(200, "application/json; charset=utf-8");
        stream->writeChunk("{\"skipped\":true}");
        stream->end();
        return true;
    }

    QString emotion = body.value(QStringLiteral("emotion")).toString();
    if (emotion.isEmpty()) { emotion = emotionFromHints(effectiveHints); }
    if (emotion.isEmpty()) { emotion = emotionFromHints(hints); }
    if (emotion.isEmpty()) { emotion = detectEmotionFromText(spoken); }
    // 诊断：把判定输入和结果都打出来，方便定位"为什么不动"
    Log::info(QStringLiteral("[pet] 判定：original=%1 hints=%2 emotion=%3 action=%4")
                  .arg(original.isEmpty() ? QStringLiteral("-") : original.left(24),
                       effectiveHints.isEmpty() ? QStringLiteral("-") : effectiveHints.join(QStringLiteral("|")).left(40),
                       emotion.isEmpty() ? QStringLiteral("-") : emotion,
                       action.isEmpty() ? QStringLiteral("-") : action));
    // 关键词全没命中 → 交给本地 4B 小模型判断括号里的神态描写（异步，不阻塞配音）
    if (emotion.isEmpty() && action.isEmpty() && !effectiveHints.isEmpty()) {
        classifyHintsAsync(effectiveHints.join(QStringLiteral("；")));
    }
    if (!emotion.isEmpty()) {
        applyEmotion(emotion);
    }

    QString profileId = body.value(QStringLiteral("profile")).toString();
    if (profileId.isEmpty()) {
        profileId = m_activeProfile;
    }
    const VoiceProfile profile = m_tts->profile(profileId);
    QString lang = profile.language;
    if (lang.isEmpty()) {
        lang = body.value(QStringLiteral("lang")).toString(detectTextLang(text));
    }
    Log::info(QStringLiteral("TTS 请求：lang=%1 profile=%2 text=%3")
                  .arg(lang, profileId, spoken.left(24)));

    stream->writeHead(200, "audio/wav");

    auto synthesize = [this, stream, profile, lang](const QString& finalText) {
        m_tts->ensureWeights(profile, [this, finalText, lang, profile, stream](const QString& weightError) {
            if (!weightError.isEmpty()) {
                stream->writeHead(502, "application/json; charset=utf-8");
                stream->writeChunk(QStringLiteral("{\"error\":{\"message\":\"%1\"}}").arg(weightError).toUtf8());
                stream->end();
                return;
            }
            m_tts->synthesize(finalText, lang, profile, m_config.voice.speed,
                              [this, stream](const QByteArray& wav, const QString& error) {
                                  if (!error.isEmpty()) {
                                      stream->writeChunk(QStringLiteral("TTS 失败：%1").arg(error).toUtf8());
                                  } else {
                                      stream->writeChunk(wav);
                                      startLipSync(wav);
                                  }
                                  stream->end();
                              });
        });
    };

    const bool cloudVoice = profile.source == QStringLiteral("cloud");
    if (lang == QStringLiteral("ja") && cloudVoice && needsJapaneseTranslation(spoken)) {
        Log::info(QStringLiteral("台词是中文，先翻成日语：%1").arg(spoken.left(20)));
        translateToJapanese(spoken, [synthesize, spoken](bool ok, const QString& japanese) {
            synthesize(ok && !japanese.isEmpty() ? japanese : spoken);
        });
    } else {
        if (lang == QStringLiteral("ja") && !cloudVoice) {
            Log::info(QStringLiteral("本地语音：翻译交给酒馆插件"));
        }
        synthesize(spoken);
    }
    return true;
}

/* ---------------------------- 控制窗口操作 ---------------------------- */

void AppController::applyProfile(const QString& id)
{
    m_activeProfile = id;
    m_config.voice.profile = id;
    m_config.save(m_config.filePath);
    Log::info(QStringLiteral("声线切换为 %1").arg(id));
    notifyUi();
}

void AppController::openLogFile()
{
    QProcess::startDetached(QStringLiteral("notepad.exe"),
                            {QCoreApplication::applicationDirPath() + QStringLiteral("/data/demon.log")});
}

void AppController::openConfigFolder()
{
    QProcess::startDetached(QStringLiteral("explorer.exe"), {QCoreApplication::applicationDirPath()});
}

void AppController::reloadConfig()
{
    m_config = Config::load(QCoreApplication::applicationDirPath() + QStringLiteral("/config.json"));
    if (m_tts) {
        m_tts->setEndpoint(m_config.voice.endpoint);
        m_tts->setProvider(m_config.voice.provider, m_config.voice.qwen);
        m_tts->setProfiles(buildVoiceProfiles());
    }
    m_activeProfile = m_config.voice.profile;
    Log::info(QStringLiteral("配置已重载"));
    notifyUi();
}


void AppController::setupTray()
{
    QPixmap pixmap(32, 32);
    pixmap.fill(Qt::transparent);
    {
        QPainter painter(&pixmap);
        painter.setRenderHint(QPainter::Antialiasing, true);
        QLinearGradient gradient(0, 0, 32, 32);
        gradient.setColorAt(0.0, QColor(0x6a, 0xa8, 0xff));
        gradient.setColorAt(1.0, QColor(0xa0, 0x6b, 0xff));
        painter.setBrush(gradient);
        painter.setPen(Qt::NoPen);
        painter.drawRoundedRect(QRect(0, 0, 32, 32), 8, 8);
        painter.setPen(Qt::white);
        QFont font = painter.font();
        font.setBold(true);
        font.setPixelSize(20);
        painter.setFont(font);
        painter.drawText(QRect(0, 0, 32, 32), Qt::AlignCenter, QStringLiteral("D"));
    }

    m_menu = new QMenu();
    m_statusAction = m_menu->addAction(
        QStringLiteral("监听 http://%1:%2").arg(m_config.host).arg(m_config.port));
    m_statusAction->setEnabled(false);

    m_voiceMenu = m_menu->addMenu(QStringLiteral("声线"));
    m_profileGroup = new QActionGroup(this);
    m_profileGroup->setExclusive(true);
    for (const VoiceProfileConfig& profile : m_config.voiceProfiles) {
        QAction* action = m_voiceMenu->addAction(profile.id);
        action->setCheckable(true);
        action->setChecked(profile.id == m_activeProfile);
        m_profileGroup->addAction(action);
        const QString id = profile.id;
        connect(action, &QAction::triggered, this, [this, id]() {
            m_activeProfile = id;
            m_config.voice.profile = id;
            m_config.save(m_config.filePath);
            Log::info(QStringLiteral("声线切换为 %1").arg(id));
            showStatus();
        });
    }

    m_menu->addSeparator();

    QAction* showPanel = m_menu->addAction(QStringLiteral("显示控制面板"));
    connect(showPanel, &QAction::triggered, this, [this]() {
        if (m_window) {
            m_window->show();
            m_window->raise();
            m_window->activateWindow();
        }
    });

    QAction* openLog = m_menu->addAction(QStringLiteral("打开日志"));
    connect(openLog, &QAction::triggered, this, []() {
        QProcess::startDetached(QStringLiteral("notepad.exe"),
                                {QCoreApplication::applicationDirPath() + QStringLiteral("/data/demon.log")});
    });

    QAction* openConfig = m_menu->addAction(QStringLiteral("打开配置目录"));
    connect(openConfig, &QAction::triggered, this, []() {
        QProcess::startDetached(QStringLiteral("explorer.exe"), {QCoreApplication::applicationDirPath()});
    });

    QAction* reload = m_menu->addAction(QStringLiteral("重载配置"));
    connect(reload, &QAction::triggered, this, [this]() {
        m_config = Config::load(QCoreApplication::applicationDirPath() + QStringLiteral("/config.json"));
        Log::info(QStringLiteral("配置已重载"));
        showStatus();
    });

    m_menu->addSeparator();

    QAction* quit = m_menu->addAction(QStringLiteral("退出"));
    connect(quit, &QAction::triggered, qApp, &QApplication::quit);

    m_tray = new QSystemTrayIcon(QIcon(pixmap), this);
    m_tray->setToolTip(QStringLiteral("Demon"));
    m_tray->setContextMenu(m_menu);
    connect(m_tray, &QSystemTrayIcon::activated, this, [this](QSystemTrayIcon::ActivationReason reason) {
        if (reason == QSystemTrayIcon::Trigger) {
            showStatus();
        } else if (reason == QSystemTrayIcon::DoubleClick && m_window) {
            m_window->show();
            m_window->raise();
            m_window->activateWindow();
        }
    });
    m_tray->show();
    m_tray->showMessage(
        QStringLiteral("Demon 已启动"),
        QStringLiteral("右键托盘里的 D 图标：切换声线 / 开关朗读 / 看日志。\n"
                       "如果没看到图标，点任务栏右下角的 ^ 展开隐藏图标。"),
        QSystemTrayIcon::Information, 8000);

    Log::info(QStringLiteral("托盘诊断：isVisible=%1 iconNull=%2 geometryValid=%3")
                  .arg(m_tray->isVisible() ? 1 : 0)
                  .arg(m_tray->icon().isNull() ? 1 : 0)
                  .arg(m_tray->geometry().isValid() ? 1 : 0));
    Log::info(QStringLiteral("托盘已创建（系统托盘可用=%1，支持气泡=%2）")
                  .arg(QSystemTrayIcon::isSystemTrayAvailable() ? QStringLiteral("是") : QStringLiteral("否"),
                       QSystemTrayIcon::supportsMessages() ? QStringLiteral("是") : QStringLiteral("否")));
}

void AppController::showStatus()
{
    if (!m_tray) {
        return;
    }
    const UpstreamConfig* up = pickUpstream(QString());
    m_tray->showMessage(QStringLiteral("Demon"),
                        QStringLiteral("引擎运行中\n%1:%2\n模型：%3\n上游：%4")
                            .arg(m_config.host)
                            .arg(m_config.port)
                            .arg(m_config.modelId)
                            .arg(up ? up->baseUrl : QStringLiteral("未配置")),
                        QSystemTrayIcon::Information, 4000);
}


bool AppController::portOpen(quint16 port)
{
    QTcpSocket socket;
    socket.connectToHost(QStringLiteral("127.0.0.1"), port);
    const bool ok = socket.waitForConnected(300);
    socket.abort();
    return ok;
}

/* --------------------------- 角色 / 启动器 --------------------------- */

QString AppController::effectiveCharactersDir() const
{
    if (!m_config.charactersDir.trimmed().isEmpty()) {
        return m_config.charactersDir.trimmed();
    }
    return m_config.launcher.stPath + QStringLiteral("/data/default-user/characters");
}

QStringList AppController::listCharacters() const
{
    QStringList names;
    const QDir dir(effectiveCharactersDir());
    if (!dir.exists()) {
        return names;
    }
    const QStringList filters{QStringLiteral("*.png"), QStringLiteral("*.json"), QStringLiteral("*.webp")};
    for (const QFileInfo& info : dir.entryInfoList(filters, QDir::Files)) {
        names.append(info.completeBaseName());
    }
    names.removeDuplicates();
    names.sort(Qt::CaseInsensitive);
    return names;
}

void AppController::setCharacterVoice(const QString& character, const QString& profileId)
{
    if (character.isEmpty()) {
        return;
    }
    if (profileId.isEmpty()) {
        m_config.characterVoices.remove(character);
    } else {
        m_config.characterVoices.insert(character, profileId);
    }
    saveConfig();
    Log::info(QStringLiteral("角色声线：%1 -> %2").arg(character, profileId.isEmpty() ? QStringLiteral("（默认）") : profileId));
}

void AppController::setDefaultProfile(const QString& profileId)
{
    m_activeProfile = profileId;
    m_config.voice.profile = profileId;
    saveConfig();
    notifyUi();
}

void AppController::testVoice(const QString& profileId)
{
    if (!m_tts) {
        return;
    }
    const VoiceProfile profile = m_tts->profile(profileId);
    const QString text = QStringLiteral("你好，我是%1。").arg(profile.name.isEmpty() ? profile.id : profile.name);
    Log::info(QStringLiteral("试听声线：%1").arg(profile.id));
    m_tts->ensureWeights(profile, [this, text, profile](const QString& weightError) {
        if (!weightError.isEmpty()) {
            Log::warn(QStringLiteral("试听失败：%1").arg(weightError));
            return;
        }
        m_tts->synthesize(text, QStringLiteral("zh"), profile, m_config.voice.speed,
                          [this](const QByteArray& wav, const QString& error) {
                              if (!error.isEmpty()) {
                                  Log::warn(QStringLiteral("试听合成失败：%1").arg(error));
                                  return;
                              }
                              if (m_audio) {
                                  m_audio->playWav(wav);
                              }
                              startLipSync(wav);
                          });
    });
}

void AppController::saveConfig()
{
    m_config.save(m_config.filePath);
    notifyUi();
}

void AppController::notifyUi()
{
    emit uiDirty();
}

namespace {

/** 从注册表读默认浏览器的可执行路径（取命令行的第一个 exe） */
QString defaultBrowserExe()
{
    QString progId;
    {
        QSettings assoc(QStringLiteral("HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice"),
                        QSettings::NativeFormat);
        progId = assoc.value(QStringLiteral("ProgId")).toString();
    }
    if (progId.isEmpty()) {
        return QString();
    }
    QSettings cmd(QStringLiteral("HKEY_CLASSES_ROOT\\%1\\shell\\open\\command").arg(progId),
                  QSettings::NativeFormat);
    const QString command = cmd.value(QStringLiteral(".")).toString();
    if (command.isEmpty()) {
        return QString();
    }
    // 形如 "C:\...\msedge.exe" --single-argument %1
    QString exe;
    if (command.startsWith(QLatin1Char('"'))) {
        const int closing = command.indexOf(QLatin1Char('"'), 1);
        if (closing > 0) {
            exe = command.mid(1, closing - 1);
        }
    } else {
        exe = command.section(QLatin1Char(' '), 0, 0);
    }
    return QFile::exists(exe) ? exe : QString();
}

} // namespace

namespace {

/** 用 Win32 CreateProcess 启动一条命令行（不依赖 Qt 的 detached 逻辑） */
bool spawnCommandLine(const QString& commandLine)
{
#ifdef Q_OS_WIN
    std::wstring cmd = commandLine.toStdWString();
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    const BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE,
                                   CREATE_NEW_PROCESS_GROUP | CREATE_UNICODE_ENVIRONMENT,
                                   nullptr, nullptr, &si, &pi);
    if (!ok) {
        Log::warn(QStringLiteral("CreateProcessW 失败，错误码 %1").arg(GetLastError()));
        return false;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return true;
#else
    Q_UNUSED(commandLine);
    return false;
#endif
}

} // namespace

bool AppController::openInEdge(const QString& url)
{
    const QStringList candidates{
        QStringLiteral("C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"),
        QStringLiteral("C:/Program Files/Microsoft/Edge/Application/msedge.exe"),
    };
    for (const QString& exe : candidates) {
        if (!QFile::exists(exe)) {
            continue;
        }
        // --app 模式：独立窗口、无地址栏、无标签页，看起来像内置浏览器
        const QString line = QStringLiteral("cmd.exe /c start \"\" \"%1\" --app=%2").arg(exe, url);
        if (spawnCommandLine(line)) {
            Log::info(QStringLiteral("已用 Edge --app 打开：%1").arg(url));
            return true;
        }
    }
    Log::warn(QStringLiteral("没找到 Edge，回退默认浏览器"));
    return openExternalUrl(url);
}

bool AppController::openExternalUrl(const QString& url)
{
    // 直接落到浏览器 exe（路径带空格，必须加引号）；壳层激活在这台机器上不可靠。
    const QString browser = defaultBrowserExe();
    if (!browser.isEmpty()) {
        const QString line = QStringLiteral("cmd.exe /c start \"\" \"%1\" \"%2\"").arg(browser, url);
        if (spawnCommandLine(line)) {
            Log::info(QStringLiteral("已启动浏览器 %1 打开 %2").arg(browser, url));
            return true;
        }
    }

    const QString line = QStringLiteral("cmd.exe /c start \"\" \"%1\"").arg(url);
    if (spawnCommandLine(line)) {
        Log::info(QStringLiteral("已通过 cmd start 打开：%1").arg(url));
        return true;
    }

    const bool ok = QDesktopServices::openUrl(QUrl(url));
    Log::info(QStringLiteral("QDesktopServices 结果：%1").arg(ok ? QStringLiteral("成功") : QStringLiteral("失败")));
    return ok;
}

namespace {
/** 找监听指定端口的进程 pid（netstat 解析） */
qint64 pidOnPort(quint16 port)
{
    QProcess process;
    process.start(QStringLiteral("netstat"), {QStringLiteral("-ano"), QStringLiteral("-p"), QStringLiteral("tcp")});
    if (!process.waitForFinished(3000)) {
        return 0;
    }
    const QString output = QString::fromLocal8Bit(process.readAllStandardOutput());
    const QString needle = QStringLiteral(":%1").arg(port);
    for (const QString& line : output.split(QLatin1Char('\n'))) {
        if (!line.contains(needle, Qt::CaseInsensitive) || !line.contains(QStringLiteral("LISTENING"), Qt::CaseInsensitive)) {
            continue;
        }
        const QStringList parts = line.trimmed().split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
        if (parts.size() >= 5) {
            return parts.last().toLongLong();
        }
    }
    return 0;
}

bool killPid(qint64 pid, QString* error)
{
    if (pid <= 0) {
        return false;
    }
    QProcess process;
    process.start(QStringLiteral("taskkill"), {QStringLiteral("/PID"), QString::number(pid), QStringLiteral("/F")});
    process.waitForFinished(5000);
    if (process.exitCode() != 0) {
        if (error) {
            *error = QString::fromLocal8Bit(process.readAllStandardError()).trimmed();
        }
        return false;
    }
    return true;
}
} // namespace

bool AppController::startSillyTavern(QString* error)
{
    const QString dir = m_config.launcher.stPath;
    const QString bat = dir + QStringLiteral("/Start.bat");
    if (!QFile::exists(bat)) {
        if (error) {
            *error = QStringLiteral("找不到 %1").arg(bat);
        }
        return false;
    }
    const bool ok = QProcess::startDetached(QStringLiteral("cmd.exe"),
                                            {QStringLiteral("/c"), QStringLiteral("start"), QString(), bat},
                                            dir);
    Log::info(QStringLiteral("启动酒馆：%1（%2）").arg(bat).arg(ok ? QStringLiteral("已拉起") : QStringLiteral("失败")));
    if (!ok && error) {
        *error = QStringLiteral("启动失败，请检查路径");
    }
    return ok;
}

bool AppController::stopSillyTavern(QString* error)
{
    const qint64 pid = pidOnPort(static_cast<quint16>(m_config.launcher.stPort));
    if (pid == 0) {
        if (error) {
            *error = QStringLiteral("酒馆没有在运行（端口 %1 未监听）").arg(m_config.launcher.stPort);
        }
        return false;
    }
    const bool ok = killPid(pid, error);
    Log::info(QStringLiteral("停止酒馆：pid=%1 %2").arg(pid).arg(ok ? QStringLiteral("成功") : QStringLiteral("失败")));
    return ok;
}

bool AppController::startVoiceService(QString* error)
{
    const QString dir = m_config.launcher.gsvPath;
    const QString bat = dir + QStringLiteral("/start-api-v2pro.bat");
    if (!QFile::exists(bat)) {
        if (error) {
            *error = QStringLiteral("找不到 %1").arg(bat);
        }
        return false;
    }
    const bool ok = QProcess::startDetached(QStringLiteral("cmd.exe"),
                                            {QStringLiteral("/c"), QStringLiteral("start"), QString(), bat},
                                            dir);
    Log::info(QStringLiteral("启动语音服务：%1（%2）").arg(bat).arg(ok ? QStringLiteral("已拉起") : QStringLiteral("失败")));
    if (!ok && error) {
        *error = QStringLiteral("启动失败，请检查路径");
    }
    return ok;
}

bool AppController::stopVoiceService(QString* error)
{
    const qint64 pid = pidOnPort(static_cast<quint16>(9880));
    if (pid == 0) {
        if (error) {
            *error = QStringLiteral("语音服务没有在运行（9880 未监听）");
        }
        return false;
    }
    const bool ok = killPid(pid, error);
    Log::info(QStringLiteral("停止语音服务：pid=%1 %2").arg(pid).arg(ok ? QStringLiteral("成功") : QStringLiteral("失败")));
    return ok;
}


/* ------------------------------ Live2D ------------------------------ */

HttpResponse AppController::handleLive2dStatus(const HttpRequest&)
{
    QJsonObject live2d;
    live2d.insert(QStringLiteral("backend"), QStringLiteral("vtube-studio"));
    live2d.insert(QStringLiteral("host"), m_config.live2d.host);
    live2d.insert(QStringLiteral("port"), m_config.live2d.port);
    live2d.insert(QStringLiteral("state"), m_vts ? VtsClient::stateName(m_vts->state()) : QStringLiteral("disabled"));
    live2d.insert(QStringLiteral("error"), m_vts ? m_vts->lastError() : QString());

    QJsonObject root;
    root.insert(QStringLiteral("live2d"), live2d);
    HttpResponse response;
    response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
    return response;
}

HttpResponse AppController::handleLive2dTest(const HttpRequest& request)
{
    if (!m_vts) {
        HttpResponse response;
        response.status = 503;
        response.body = jsonErrorBody(QStringLiteral("Live2D 未初始化"));
        return response;
    }
    const QJsonObject body = QJsonDocument::fromJson(request.body).object();
    const QString param = body.value(QStringLiteral("param")).toString(QStringLiteral("MouthOpen"));
    const double value = body.value(QStringLiteral("value")).toDouble(0.5);
    m_vts->injectParameter(param, value);

    QJsonObject root;
    root.insert(QStringLiteral("sent"), true);
    root.insert(QStringLiteral("param"), param);
    root.insert(QStringLiteral("value"), value);
    root.insert(QStringLiteral("state"), VtsClient::stateName(m_vts->state()));
    HttpResponse response;
    response.body = QJsonDocument(root).toJson(QJsonDocument::Compact);
    return response;
}


/* ------------------------------ 口型同步 ------------------------------ */

namespace {

// 大肥鱼模型的 exp3 短名（model3.json 里没有 Expressions 段，表情靠自己扫 EXP 目录）
QString nativePetExpression(const QString& emotion)
{
    static const QHash<QString, QString> kMap = {
        {QStringLiteral("happy"), QStringLiteral("龇牙")},
        {QStringLiteral("excited"), QStringLiteral("O O")},
        {QStringLiteral("shy"), QStringLiteral("脸红")},
        {QStringLiteral("love"), QStringLiteral("脸红")},
        {QStringLiteral("sad"), QStringLiteral("担心嘴")},
        {QStringLiteral("cry"), QStringLiteral("担心嘴")},
        {QStringLiteral("angry"), QStringLiteral("脸黑")},
        {QStringLiteral("surprised"), QStringLiteral("O O")},
        {QStringLiteral("confused"), QStringLiteral("X X")},
        {QStringLiteral("think"), QStringLiteral("栗子嘴")},
        {QStringLiteral("tease"), QStringLiteral("》《")},
        {QStringLiteral("dark"), QStringLiteral("脸黑")},
        {QStringLiteral("dizzy"), QStringLiteral("X X")},
        {QStringLiteral("tired"), QStringLiteral("担心嘴")},
    };
    return kMap.value(emotion);
}

// 桌宠（small demon，Electron）走本地 HTTP：8792 的 /expression /mouth /quit
void postSmallDemon(const QString& path, const QJsonObject& body)
{
    static QNetworkAccessManager* manager = new QNetworkAccessManager(qApp);
    QNetworkRequest request(QUrl(QStringLiteral("http://127.0.0.1:8792") + path));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    QNetworkReply* reply = manager->post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));
    QObject::connect(reply, &QNetworkReply::finished, reply, &QNetworkReply::deleteLater);
}

} // namespace

void AppController::startLipSync(const QByteArray& wav)
{
    const bool vtsReady = m_vts && m_vts->state() == VtsClient::State::Ready;
    const bool petReady = nativePetActive() || smallDemonRunning();
    if (!vtsReady && !petReady) {
        return;
    }
    const QVector<float> envelope = LipSync::envelope(wav, 30);
    if (envelope.isEmpty()) {
        Log::warn(QStringLiteral("口型：WAV 解析失败或格式不支持"));
        return;
    }

    if (!m_mouthTimer) {
        m_mouthTimer = new QTimer(this);
        m_mouthTimer->setInterval(33);
        connect(m_mouthTimer, &QTimer::timeout, this, [this]() {
            if (m_mouthIndex >= m_mouthEnvelope.size()) {
                m_mouthTimer->stop();
                if (m_vts) {
                    m_vts->injectParameter(QStringLiteral("MouthOpen"), 0.0);
                }
                postSmallDemon(QStringLiteral("/mouth"), {{QStringLiteral("value"), 0.0}});
                return;
            }
            // 增益 + 平滑：包络本身偏小，×1.6 更明显；上升快、下降慢，避免抖动
            const double raw = qMin(1.0, m_mouthEnvelope.at(m_mouthIndex) * 1.6);
            m_mouthSmoothed = (raw > m_mouthSmoothed)
                                  ? (m_mouthSmoothed * 0.30 + raw * 0.70)
                                  : (m_mouthSmoothed * 0.70 + raw * 0.30);
            const double value = m_mouthSmoothed;
            if (m_vts) {
                m_vts->injectParameter(QStringLiteral("MouthOpen"), value);
            }
            if (nativePetActive()) {
                sendToNativePet(QStringLiteral("mouth ") + QString::number(value, 'f', 3));
            } else {
                postSmallDemon(QStringLiteral("/mouth"), {{QStringLiteral("value"), value}});
            }
            ++m_mouthIndex;
        });
    }

    m_mouthEnvelope = envelope;
    m_mouthIndex = 0;
    m_mouthSmoothed = 0.0;
    // 音频还没开始播，先不跑包络；等插件的 /voice/playback start 事件。
    m_mouthAwaitingPlayback = true;
    QTimer::singleShot(1500, this, [this]() {
        if (m_mouthAwaitingPlayback && m_mouthTimer) {
            m_mouthAwaitingPlayback = false;
            m_mouthIndex = 0;
            m_mouthSmoothed = 0.0;
            m_mouthTimer->start();
            Log::info(QStringLiteral("口型：没等到播放事件，按兜底时间启动"));
        }
    });
    Log::info(QStringLiteral("口型同步开始：%1 帧（约 %2 秒）")
                  .arg(envelope.size())
                  .arg(envelope.size() / 30.0, 0, 'f', 1));
}


QString AppController::live2dStateName() const
{
    return m_vts ? VtsClient::stateName(m_vts->state()) : QStringLiteral("disabled");
}

QString AppController::live2dError() const
{
    return m_vts ? m_vts->lastError() : QString();
}

QString AppController::live2dEndpoint() const
{
    return QStringLiteral("%1:%2").arg(m_config.live2d.host).arg(m_config.live2d.port);
}

void AppController::reconnectLive2d()
{
    if (m_vts) {
        m_vts->disconnectFromServer();
        m_vts->connectToServer();
        notifyUi();
    }
}

void AppController::injectMouth(double value)
{
    if (m_vts) {
        m_vts->injectParameter(QStringLiteral("MouthOpen"), value);
    }
    if (nativePetActive()) {
        sendToNativePet(QStringLiteral("mouth ") + QString::number(qBound(0.0, value, 1.0), 'f', 3));
        return;
    }
    postSmallDemon(QStringLiteral("/mouth"),
                   {{QStringLiteral("value"), qBound(0.0, value, 1.0)}});
}


/* ------------------------------ 情绪映射 ------------------------------ */

namespace {

struct EmotionRule {
    const char* emotion;
    const char* expression;   // 表情名里包含这个关键字
};

// 大肥鱼（da-feiyu）
const EmotionRule kFeiyuRules[] = {
    {"happy", "龇牙"},
    {"excited", "O O"},
    {"shy", "脸红"},
    {"love", "脸红"},
    {"sad", "担心嘴"},
    {"cry", "担心嘴"},
    {"angry", "脸黑"},
    {"surprised", "O O"},
    {"confused", "X X"},
    {"think", "栗子嘴"},
    {"tease", "》《"},
    {"dark", "脸黑"},
    {"dizzy", "X X"},
    {"tired", "担心嘴"},
};

// 鲸鱼娘（whale-deepseek）
const EmotionRule kWhaleRules[] = {
    {"happy", "开心兴奋"},
    {"excited", "星星眼"},
    {"shy", "脸红"},
    {"love", "爱心眼"},
    {"sad", "悲伤"},
    {"cry", "哭"},
    {"angry", "生气"},
    {"surprised", "感叹号"},
    {"confused", "问号"},
    {"think", "呆呆眼"},
    {"tease", "调皮"},
    {"dark", "阴暗"},
    {"dizzy", "晕晕"},
    {"tired", "流汗"},
};

} // namespace

QString AppController::currentModelName() const
{
    return m_currentModel;
}

QStringList AppController::availableExpressions() const
{
    return m_exprNames;
}

void AppController::applyEmotion(const QString& emotion)
{
    // 原生桌宠优先：情绪名映射到 EXP/*.exp3.json（水印消除是常驻基线，不会被清掉）
    if (nativePetActive()) {
        const QString expression = nativePetExpression(emotion);
        if (!expression.isEmpty()) {
            sendToNativePet(QStringLiteral("expr ") + expression);
        } else if (emotion.isEmpty() || emotion == QStringLiteral("neutral")) {
            sendToNativePet(QStringLiteral("expr"));
        }
    } else if (!emotion.isEmpty()) {
        // 没有原生桌宠时退回 small demon（它自己映射情绪名）
        postSmallDemon(QStringLiteral("/expression"), {{QStringLiteral("name"), emotion}});
    }
    if (m_dsh) {
        QString character = m_config.characterModels.isEmpty()
            ? QStringLiteral("default") : m_config.characterModels.firstKey();
        m_dsh->pushEmotion(character, emotion, 1.0, QStringLiteral("audio"));
    }
    if (!m_vts || m_vts->state() != VtsClient::State::Ready) {
        Log::warn(QStringLiteral("情绪：VTS 未就绪，跳过 %1").arg(emotion));
        return;
    }
    if (emotion.isEmpty() || emotion == QStringLiteral("neutral")) {
        return;
    }
    ensureWatermarkHidden();

    const QString model = m_currentModel;
    const bool feiyu = model.contains(QStringLiteral("大肥鱼"))
        || model.contains(QStringLiteral("da-feiyu"), Qt::CaseInsensitive);
    const EmotionRule* rules = feiyu ? kFeiyuRules : kWhaleRules;
    const int ruleCount = feiyu ? int(std::size(kFeiyuRules)) : int(std::size(kWhaleRules));

    QString keyword;
    for (int i = 0; i < ruleCount; ++i) {
        if (emotion == QString::fromLatin1(rules[i].emotion)) {
            keyword = QString::fromUtf8(rules[i].expression);
            break;
        }
    }
    if (keyword.isEmpty()) {
        Log::warn(QStringLiteral("情绪：没有 %1 的映射").arg(emotion));
        return;
    }

    const QStringList names = m_exprNames;
    const QStringList files = m_exprFiles;
    for (int i = 0; i < names.size() && i < files.size(); ++i) {
        if (names.at(i).contains(keyword)) {
            const QString target = files.at(i);
            if (m_activeEmotion == QStringList{target}) {
                // 已经是这个表情，只重置计时，不重复发送
                if (m_emotionResetTimer) {
                    m_emotionResetTimer->start();
                }
                return;
            }
            clearEmotionExpressions();
            m_vts->setExpression(target, true);
            m_activeEmotion = QStringList{target};
            const QString hotkey = m_config.emotionHotkeys.value(emotion);
            if (!hotkey.isEmpty()) {
                m_vts->triggerHotkey(hotkey);
            }
            Log::info(QStringLiteral("情绪 %1 → 表情「%2」").arg(emotion, names.at(i)));

            if (!m_emotionResetTimer) {
                m_emotionResetTimer = new QTimer(this);
                m_emotionResetTimer->setSingleShot(true);
                m_emotionResetTimer->setInterval(8000);
                connect(m_emotionResetTimer, &QTimer::timeout, this, [this]() {
                    clearEmotionExpressions();
                    Log::info(QStringLiteral("情绪表情已清除，回到中性"));
                });
            }
            m_emotionResetTimer->start();
            return;
        }
    }
    Log::warn(QStringLiteral("情绪：模型里找不到含「%1」的表情").arg(keyword));
}


QStringList AppController::availableExpressionFiles() const
{
    return m_exprFiles;
}

void AppController::sendLive2dRaw(const QString& type, const QJsonObject& data)
{
    if (m_vts) {
        m_vts->sendRaw(type, data);
    }
}

QJsonObject AppController::lastLive2dResponse(const QString& type) const
{
    return m_vtsLastResponses.value(type);
}


void AppController::ensureWatermarkHidden()
{
    if (!m_vts || m_vts->state() != VtsClient::State::Ready) {
        return;
    }
    if (!m_currentModel.contains(QStringLiteral("大肥鱼"))) {
        return;
    }
    const QStringList names = m_exprNames;
    const QStringList files = m_exprFiles;
    for (int i = 0; i < names.size() && i < files.size(); ++i) {
        if (names.at(i).contains(QStringLiteral("水印"))) {
            m_vts->setExpression(files.at(i));
            return;
        }
    }
}


/* --------------------------- VTube Studio --------------------------- */

bool AppController::startVTubeStudio(QString* error)
{
    QString exe = m_config.live2d.vtsExe;
    if (exe.isEmpty()) {
        exe = QStringLiteral("E:/SteamLibrary/steamapps/common/VTube Studio/VTube Studio.exe");
    }
    if (!QFileInfo::exists(exe)) {
        if (error) {
            *error = QStringLiteral("找不到 VTube Studio.exe：%1").arg(exe);
        }
        return false;
    }
    if (portOpen(m_config.live2d.port)) {
        if (error) {
            *error = QStringLiteral("VTube Studio 已经在运行（%1）").arg(m_config.live2d.port);
        }
        return false;
    }
    const QString command = QStringLiteral("cmd /c start \"\" \"%1\"").arg(QDir::toNativeSeparators(exe));
    if (!spawnCommandLine(command)) {
        if (error) {
            *error = QStringLiteral("启动失败");
        }
        return false;
    }
    Log::info(QStringLiteral("已启动 VTube Studio：%1").arg(exe));
    return true;
}

bool AppController::stopVTubeStudio(QString* error)
{
    const QString command = QStringLiteral("taskkill /IM \"VTube Studio.exe\"");
    if (!spawnCommandLine(command)) {
        if (error) {
            *error = QStringLiteral("停止失败");
        }
        return false;
    }
    Log::info(QStringLiteral("已请求关闭 VTube Studio"));
    return true;
}

void AppController::testEmotion(const QString& emotion)
{
    applyEmotion(emotion);
}


/* ---------------------------- 文本情绪识别 ---------------------------- */

namespace {

struct EmotionKeyword {
    const char* emotion;
    const char* keywords;   // 用 | 分隔
};

const EmotionKeyword kEmotionKeywords[] = {
    {"happy", "开心|高兴|嘿嘿|哈哈|笑|好耶|太棒|うれし|嬉し|楽しい|ありがと|えへへ|ふふ"},
    {"excited", "兴奋|激动|期待|哇"},
    {"shy", "害羞|脸红|不好意思|讨厌啦|恥ずかし|照れ|赤面|はにか"},
    {"love", "爱你|喜欢你|抱抱|亲亲|贴贴"},
    {"sad", "难过|伤心|失落|呜呜|悲し|寂し|つらい|しょんぼり"},
    {"cry", "哭|眼泪|泣|涙|うええ|えーん"},
    {"angry", "生气|愤怒|讨厌|气死|怒|ムカ|腹立|いやだ"},
    {"surprised", "惊讶|吃惊|真的吗|居然|竟然|驚|びっくり|まさか|うそ"},
    {"confused", "疑惑|为什么|不懂|奇怪"},
    {"think", "想想|思考|让我想"},
    {"tease", "调皮|坏笑|略略略|捉弄"},
    {"dark", "阴暗|黑化|可怕"},
    {"dizzy", "天旋地转|好晕"},
    {"tired", "好累|困了|想睡|疲惫|疲れ|眠い|だるい"},
};

} // namespace

QString AppController::detectEmotionFromText(const QString& text)
{
    if (text.isEmpty()) {
        return QString();
    }
    for (const auto& rule : kEmotionKeywords) {
        const QStringList keywords = QString::fromUtf8(rule.keywords).split(QLatin1Char('|'));
        for (const QString& keyword : keywords) {
            if (!keyword.isEmpty() && text.contains(keyword)) {
                return QString::fromLatin1(rule.emotion);
            }
        }
    }
    return QString();
}


/* ------------------------ 本地读取模型表情 ------------------------ */

void AppController::loadModelExpressions(const QString& modelName, const QString& modelId)
{
    m_exprNames.clear();
    m_exprFiles.clear();

    QString base = m_config.live2d.modelsDir;
    if (base.isEmpty()) {
        base = QStringLiteral("E:/SteamLibrary/steamapps/common/VTube Studio/VTube Studio_Data/StreamingAssets/Live2DModels");
    }
    QDir root(base);
    if (!root.exists()) {
        Log::warn(QStringLiteral("Live2DModels 目录不存在：%1").arg(base));
        return;
    }

    // 1) 用 ModelID 精确找 .vtube.json（DS鲸鱼娘 这类嵌套模型必须靠它）
    QString modelDir;
    if (!modelId.isEmpty()) {
        QDirIterator it(base, {QStringLiteral("*.vtube.json")}, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString path = it.next();
            QFile f(path);
            if (!f.open(QIODevice::ReadOnly)) {
                continue;
            }
            const QJsonObject obj = QJsonDocument::fromJson(f.readAll()).object();
            if (obj.value(QStringLiteral("ModelID")).toString() == modelId) {
                modelDir = QFileInfo(path).absolutePath();
                break;
            }
        }
    }

    // 2) 退路：按目录名 / 模型名匹配
    if (modelDir.isEmpty()) {
        QDirIterator it(base, {QStringLiteral("*.model3.json")}, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString path = it.next();
            const QString dir = QFileInfo(path).absolutePath();
            if (dir.contains(modelName) || QFileInfo(path).completeBaseName().startsWith(modelName)) {
                modelDir = dir;
                break;
            }
        }
    }

    if (modelDir.isEmpty()) {
        Log::warn(QStringLiteral("没找到模型 %1（id=%2）的目录").arg(modelName, modelId));
        return;
    }

    // 3) 先读 model3.json 的 Expressions
    const QStringList modelFiles = QDir(modelDir).entryList({QStringLiteral("*.model3.json")}, QDir::Files);
    for (const QString& file : modelFiles) {
        QFile f(QDir(modelDir).absoluteFilePath(file));
        if (!f.open(QIODevice::ReadOnly)) {
            continue;
        }
        const QJsonObject rootObj = QJsonDocument::fromJson(f.readAll()).object();
        const QJsonArray expressions = rootObj.value(QStringLiteral("FileReferences")).toObject()
                                            .value(QStringLiteral("Expressions")).toArray();
        for (const QJsonValue& v : expressions) {
            const QJsonObject item = v.toObject();
            const QString name = item.value(QStringLiteral("Name")).toString();
            const QString exprFile = item.value(QStringLiteral("File")).toString();
            if (!name.isEmpty()) {
                m_exprNames.append(name);
                m_exprFiles.append(exprFile);
            }
        }
        break;
    }

    // 4) model3.json 没写 Expressions：直接扫 *.exp3.json（DS鲸鱼娘 就是这种）
    if (m_exprNames.isEmpty()) {
        QDirIterator it(modelDir, {QStringLiteral("*.exp3.json")}, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext()) {
            const QString path = it.next();
            const QString rel = QDir(modelDir).relativeFilePath(path);
            QString name = QFileInfo(path).completeBaseName();   // 去掉 .exp3
            m_exprNames.append(name);
            m_exprFiles.append(rel);
        }
        std::sort(m_exprNames.begin(), m_exprNames.end());
        // 文件名和表情文件要一起排序
        QVector<QPair<QString, QString>> pairs;
        for (int i = 0; i < m_exprNames.size(); ++i) {
            pairs.append({m_exprNames.at(i), m_exprFiles.at(i)});
        }
        std::sort(pairs.begin(), pairs.end(), [](const auto& a, const auto& b) {
            return a.first < b.first;
        });
        m_exprNames.clear();
        m_exprFiles.clear();
        for (const auto& p : pairs) {
            m_exprNames.append(p.first);
            m_exprFiles.append(p.second);
        }
    }

    Log::info(QStringLiteral("本地表情表：%1（%2 个，目录 %3）")
                  .arg(modelName)
                  .arg(m_exprNames.size())
                  .arg(QDir(base).relativeFilePath(modelDir)));
}


QStringList AppController::audioDevices() const
{
    QStringList names;
    for (const QAudioDevice& device : QMediaDevices::audioOutputs()) {
        names.append(device.description());
    }
    return names;
}

void AppController::setOutputDevice(const QString& name)
{
    m_config.voice.outputDevice = name;
    if (m_audio) {
        m_audio->setDeviceByName(name);
    }
    saveConfig();
    Log::info(QStringLiteral("输出设备：%1").arg(name.isEmpty() ? QStringLiteral("系统默认") : name));
}

void AppController::setVoiceVolume(double value)
{
    m_config.voice.volume = qBound(0.0, value, 1.0);
    if (m_audio) {
        m_audio->setVolume(m_config.voice.volume);
    }
    saveConfig();
}


void AppController::clearEmotionExpressions()
{
    if (m_vts && m_vts->state() == VtsClient::State::Ready) {
        for (const QString& file : m_activeEmotion) {
            m_vts->setExpression(file, false);
        }
    }
    m_activeEmotion.clear();
}


/* ---------------------------- 中文 → 日语 ---------------------------- */

namespace {

bool containsHan(const QString& text)
{
    static const QRegularExpression han(QStringLiteral("[\\x{4e00}-\\x{9fff}]"));
    return text.contains(han);
}

bool containsKana(const QString& text)
{
    static const QRegularExpression kana(QStringLiteral("[\\x{3040}-\\x{30ff}]"));
    return text.contains(kana);
}

} // namespace

bool AppController::needsJapaneseTranslation(const QString& text) const
{
    return containsHan(text) && !containsKana(text);
}

void AppController::translateToJapanese(const QString& text, std::function<void(bool, const QString&)> callback)
{
    const QString trimmed = text.trimmed();
    if (trimmed.isEmpty()) {
        callback(false, QString());
        return;
    }
    bool hasWord = false;
    for (const QChar ch : trimmed) {
        if (ch.isLetterOrNumber()) {
            hasWord = true;
            break;
        }
    }
    if (!hasWord) {
        callback(true, trimmed);
        return;
    }
    if (m_jaCache.contains(trimmed)) {
        callback(true, m_jaCache.value(trimmed));
        return;
    }

    // 翻译优先用通义千问（本地 local-vl 小模型翻译质量不可用）
    QUrl url;
    QString model;
    QString apiKey;
    if (!m_config.voice.qwen.apiKey.isEmpty()) {
        url = QUrl(QStringLiteral("https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"));
        model = QStringLiteral("qwen-plus");
        apiKey = m_config.voice.qwen.apiKey;
    } else {
        const UpstreamConfig* upstream = pickUpstream(QString());
        if (!upstream) {
            callback(false, QString());
            return;
        }
        url = QUrl(upstream->baseUrl);
        QString path = url.path();
        if (!path.endsWith(QLatin1Char('/'))) {
            path += QLatin1Char('/');
        }
        path += QStringLiteral("chat/completions");
        url.setPath(path);
        model = upstream->model;
        apiKey = upstream->apiKey;
    }

    QJsonObject system;
    system.insert(QStringLiteral("role"), QStringLiteral("system"));
    system.insert(QStringLiteral("content"),
                  QStringLiteral("你是专业的日文本地化翻译。把用户给你的台词翻译成自然、口语化的日语，"
                                 "保留语气、情绪和角色感。只输出译文本身，不要加引号、不要解释。"));
    QJsonObject user;
    user.insert(QStringLiteral("role"), QStringLiteral("user"));
    user.insert(QStringLiteral("content"), trimmed);
    QJsonArray messages;
    messages.append(system);
    messages.append(user);

    QJsonObject body;
    body.insert(QStringLiteral("model"), model);
    body.insert(QStringLiteral("messages"), messages);
    body.insert(QStringLiteral("stream"), false);
    body.insert(QStringLiteral("temperature"), 0.3);
    body.insert(QStringLiteral("max_tokens"), 400);

    QNetworkRequest req(url);
    req.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    if (!apiKey.isEmpty()) {
        req.setRawHeader("Authorization", "Bearer " + apiKey.toUtf8());
    }

    QNetworkReply* reply = m_net->post(req, QJsonDocument(body).toJson(QJsonDocument::Compact));
    QTimer::singleShot(20000, reply, [reply]() {
        if (reply->isRunning()) {
            reply->abort();
        }
    });

    connect(reply, &QNetworkReply::finished, reply, [this, reply, trimmed, callback]() {
        const QByteArray payload = reply->readAll();
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            Log::warn(QStringLiteral("翻译失败：%1").arg(reply->errorString()));
            callback(false, QString());
            return;
        }

        QString content = QJsonDocument::fromJson(payload).object()
                              .value(QStringLiteral("choices")).toArray()
                              .at(0).toObject()
                              .value(QStringLiteral("message")).toObject()
                              .value(QStringLiteral("content")).toString()
                              .trimmed();
        // 去掉可能的引号或“译文：”前缀
        content.remove(QRegularExpression(QStringLiteral("^[「『\\\"']|[」』\\\"']$")));
        content.remove(QRegularExpression(QStringLiteral("^(译文|日文|日本語)[：:]\\s*")));

        if (content.isEmpty()) {
            Log::warn(QStringLiteral("翻译返回为空"));
            callback(false, QString());
            return;
        }
        bool hasKana = false;
        for (const QChar ch : content) {
            const ushort u = ch.unicode();
            if ((u >= 0x3040 && u <= 0x30FF) || (u >= 0x31F0 && u <= 0x31FF)) {
                hasKana = true;
                break;
            }
        }
        if (!hasKana && content != trimmed) {
            Log::warn(QStringLiteral("翻译结果不是日语，丢弃：%1").arg(content.left(30)));
            callback(false, QString());
            return;
        }
        m_jaCache.insert(trimmed, content);
        Log::info(QStringLiteral("翻译完成：%1 → %2").arg(trimmed.left(12), content.left(24)));
        callback(true, content);
    });
}


QStringList AppController::live2dModels() const
{
    QStringList names;
    QString base = m_config.live2d.modelsDir;
    if (base.isEmpty()) {
        base = QStringLiteral("E:/SteamLibrary/steamapps/common/VTube Studio/VTube Studio_Data/StreamingAssets/Live2DModels");
    }
    QDirIterator it(base, {QStringLiteral("*.vtube.json")}, QDir::Files, QDirIterator::Subdirectories);
    while (it.hasNext()) {
        QFile f(it.next());
        if (!f.open(QIODevice::ReadOnly)) {
            continue;
        }
        const QJsonObject obj = QJsonDocument::fromJson(f.readAll()).object();
        const QString name = obj.value(QStringLiteral("Name")).toString();
        if (!name.isEmpty() && !names.contains(name)) {
            names.append(name);
        }
    }
    names.sort(Qt::CaseInsensitive);
    return names;
}

void AppController::loadLive2dModel(const QString& modelName)
{
    if (modelName.isEmpty() || !m_vts) {
        return;
    }
    m_pendingModel = modelName;
    if (m_vts->state() == VtsClient::State::Ready) {
        m_vts->sendRaw(QStringLiteral("AvailableModelsRequest"), QJsonObject());
    }
}

void AppController::setCharacterProvider(const QString& character, const QString& source)
{
    if (character.isEmpty()) {
        return;
    }
    m_config.characterProviders.insert(character, source);
    saveConfig();
    Log::info(QStringLiteral("角色 %1 音色来源：%2").arg(character, source));
}

void AppController::setCharacterModel(const QString& character, const QString& modelName)
{
    if (character.isEmpty()) {
        return;
    }
    m_config.characterModels.insert(character, modelName);
    saveConfig();
    Log::info(QStringLiteral("角色 %1 Live2D：%2").arg(character, modelName));
}


/* --------------------- VTube Studio 窗口独立显示 --------------------- */

#ifdef Q_OS_WIN
namespace {
bool isVtsExecutable(const QString& name)
{
    return name.compare(QStringLiteral("VTube Studio.exe"), Qt::CaseInsensitive) == 0
        || name.compare(QStringLiteral("VTube Studio"), Qt::CaseInsensitive) == 0
        || name.startsWith(QStringLiteral("VTube Studio"), Qt::CaseInsensitive);
}

struct WindowSearch {
    DWORD pid = 0;
    HWND best = nullptr;
    DWORD bestArea = 0;
};

BOOL CALLBACK enumWindowsProc(HWND hwnd, LPARAM lparam)
{
    auto* search = reinterpret_cast<WindowSearch*>(lparam);
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (pid != search->pid || !IsWindowVisible(hwnd)) {
        return TRUE;
    }
    RECT rect{};
    GetWindowRect(hwnd, &rect);
    const DWORD area = static_cast<DWORD>((rect.right - rect.left) * (rect.bottom - rect.top));
    if (area > search->bestArea) {
        search->bestArea = area;
        search->best = hwnd;
    }
    return TRUE;
}
} // namespace
#endif

bool AppController::setVtsWindowBorderless(bool on)
{
#ifdef Q_OS_WIN
    WindowSearch search;
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapshot == INVALID_HANDLE_VALUE) {
        return false;
    }
    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    if (Process32FirstW(snapshot, &entry)) {
        do {
            if (isVtsExecutable(QString::fromWCharArray(entry.szExeFile))) {
                search.pid = entry.th32ProcessID;
                break;
            }
        } while (Process32NextW(snapshot, &entry));
    }
    CloseHandle(snapshot);
    if (search.pid == 0) {
        Log::warn(QStringLiteral("没找到 VTube Studio 进程"));
        return false;
    }
    EnumWindows(enumWindowsProc, reinterpret_cast<LPARAM>(&search));
    if (!search.best) {
        Log::warn(QStringLiteral("没找到 VTube Studio 窗口"));
        return false;
    }

    static LONG originalStyle = 0;
    static LONG originalExStyle = 0;
    HWND hwnd = search.best;
    if (on) {
        if (originalStyle == 0) {
            originalStyle = GetWindowLongW(hwnd, GWL_STYLE);
            originalExStyle = GetWindowLongW(hwnd, GWL_EXSTYLE);
        }
        SetWindowLongW(hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowLongW(hwnd, GWL_EXSTYLE, originalExStyle | WS_EX_TOPMOST);
        SetWindowPos(hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    } else if (originalStyle != 0) {
        SetWindowLongW(hwnd, GWL_STYLE, originalStyle);
        SetWindowLongW(hwnd, GWL_EXSTYLE, originalExStyle);
        SetWindowPos(hwnd, HWND_NOTOPMOST, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    }
    Log::info(QStringLiteral("VTS 窗口独立显示：%1").arg(on ? QStringLiteral("开") : QStringLiteral("关")));
    return true;
#else
    Q_UNUSED(on);
    return false;
#endif
}


/* ---------------------- 动作热键 / 桌宠模式 ---------------------- */

void AppController::refreshLive2dHotkeys()
{
    if (m_vts && m_vts->state() == VtsClient::State::Ready) {
        m_vts->sendRaw(QStringLiteral("HotkeysInCurrentModelRequest"), QJsonObject());
        Log::info(QStringLiteral("已请求 VTS 热键列表"));
    }
}

QStringList AppController::live2dHotkeys() const
{
    QStringList names;
    const QJsonObject root = m_vtsLastResponses.value(QStringLiteral("HotkeysInCurrentModelResponse"));
    const QJsonArray hotkeys = root.value(QStringLiteral("data")).toObject()
                                   .value(QStringLiteral("availableHotkeys")).toArray();
    for (const QJsonValue& v : hotkeys) {
        names.append(v.toObject().value(QStringLiteral("name")).toString());
    }
    return names;
}

QStringList AppController::live2dHotkeyIds() const
{
    QStringList ids;
    const QJsonObject root = m_vtsLastResponses.value(QStringLiteral("HotkeysInCurrentModelResponse"));
    const QJsonArray hotkeys = root.value(QStringLiteral("data")).toObject()
                                   .value(QStringLiteral("availableHotkeys")).toArray();
    for (const QJsonValue& v : hotkeys) {
        ids.append(v.toObject().value(QStringLiteral("hotkeyID")).toString());
    }
    return ids;
}

void AppController::triggerLive2dHotkey(const QString& hotkeyId)
{
    if (m_vts && !hotkeyId.isEmpty()) {
        m_vts->triggerHotkey(hotkeyId);
        Log::info(QStringLiteral("触发 VTS 热键：%1").arg(hotkeyId));
    }
}

bool AppController::setVtsDesktopPet(bool on, const QString& colorKeyHex)
{
#ifdef Q_OS_WIN
    HWND hwnd = FindWindowW(nullptr, L"VTube Studio");
    if (!hwnd) {
        WindowSearch search;
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snapshot == INVALID_HANDLE_VALUE) {
            Log::warn(QStringLiteral("桌宠：进程快照失败 error=%1").arg(GetLastError()));
            return false;
        }
        PROCESSENTRY32W entry{};
        entry.dwSize = sizeof(entry);
        if (Process32FirstW(snapshot, &entry)) {
            do {
                if (isVtsExecutable(QString::fromWCharArray(entry.szExeFile))) {
                    search.pid = entry.th32ProcessID;
                    break;
                }
            } while (Process32NextW(snapshot, &entry));
        }
        CloseHandle(snapshot);
        if (search.pid == 0) {
            Log::warn(QStringLiteral("桌宠：没找到 VTube Studio 进程"));
            return false;
        }
        EnumWindows(enumWindowsProc, reinterpret_cast<LPARAM>(&search));
        hwnd = search.best;
    }
    if (!hwnd) {
        Log::warn(QStringLiteral("桌宠：没找到 VTube Studio 窗口"));
        return false;
    }

    if (IsIconic(hwnd)) {
        ShowWindow(hwnd, SW_RESTORE);
        Sleep(150);
    }
    RECT rect{};
    GetWindowRect(hwnd, &rect);
    if (rect.right - rect.left < 200 || rect.bottom - rect.top < 200) {
        SetWindowPos(hwnd, HWND_TOP, 200, 120, 800, 800, SWP_NOACTIVATE | SWP_SHOWWINDOW);
        Sleep(100);
        GetWindowRect(hwnd, &rect);
    }

    LONG ex = GetWindowLongW(hwnd, GWL_EXSTYLE);
    if (on) {
        if (!m_petWindow) {
            m_petWindow = std::make_unique<PetWindow>();
        }
        if (!m_petWindow->start(reinterpret_cast<quintptr>(hwnd), QColor(colorKeyHex))) {
            Log::warn(QStringLiteral("桌宠：首帧抓取失败"));
            return false;
        }
        // VTS 留在原位，但整体 alpha=0（不可见）；抓帧仍然有效
        ex |= WS_EX_LAYERED;
        SetWindowLongW(hwnd, GWL_EXSTYLE, ex);
        SetLayeredWindowAttributes(hwnd, 0, 0, LWA_ALPHA);
        m_petWindow->move(rect.left, rect.top);
        Log::info(QStringLiteral("桌宠模式：开，VTS 窗口透明，色键 %1，窗口 %2")
                      .arg(colorKeyHex)
                      .arg(reinterpret_cast<quintptr>(hwnd)));
    } else {
        if (m_petWindow) {
            m_petWindow->stop();
        }
        ex &= ~WS_EX_LAYERED;
        SetWindowLongW(hwnd, GWL_EXSTYLE, ex);
        SetLayeredWindowAttributes(hwnd, 0, 255, LWA_ALPHA);
        Log::info(QStringLiteral("桌宠模式：关，VTS 恢复显示"));
    }
    return true;
#else
    Q_UNUSED(on);
    Q_UNUSED(colorKeyHex);
    return false;
#endif
}


QString AppController::expressionForEmotion(const QString& emotion) const
{
    struct Rule {
        const char* emotion;
        const char* keyword;
    };
    static const Rule feiyu[] = {
        {"happy", "龇牙"}, {"excited", "O O"}, {"shy", "脸红"}, {"love", "脸红"},
        {"sad", "担心嘴"}, {"cry", "担心嘴"}, {"angry", "脸黑"}, {"surprised", "O O"},
        {"confused", "X X"}, {"think", "栗子嘴"}, {"tease", "》《"}, {"dark", "脸黑"},
        {"dizzy", "X X"}, {"tired", "担心嘴"},
    };
    static const Rule whale[] = {
        {"happy", "开心兴奋"}, {"excited", "星星眼"}, {"shy", "脸红"}, {"love", "爱心眼"},
        {"sad", "悲伤"}, {"cry", "哭"}, {"angry", "生气"}, {"surprised", "感叹号"},
        {"confused", "问号"}, {"think", "呆呆眼"}, {"tease", "调皮"}, {"dark", "阴暗"},
        {"dizzy", "晕晕"}, {"tired", "流汗"},
    };
    const bool feiyuModel = m_currentModel.contains(QStringLiteral("大肥鱼"));
    const Rule* rules = feiyuModel ? feiyu : whale;
    const int count = feiyuModel ? int(std::size(feiyu)) : int(std::size(whale));
    QString keyword;
    for (int i = 0; i < count; ++i) {
        if (emotion == QString::fromLatin1(rules[i].emotion)) {
            keyword = QString::fromUtf8(rules[i].keyword);
            break;
        }
    }
    if (keyword.isEmpty()) {
        return QString();
    }
    for (const QString& name : m_exprNames) {
        if (name.contains(keyword)) {
            return name;
        }
    }
    return QString();
}


/* ----------------------- 声音情绪识别（Qwen Omni） ----------------------- */

void AppController::recognizeEmotion(const QByteArray& wav,
                                     std::function<void(bool, const QString&, const QString&, const QString&)> callback)
{
    if (wav.isEmpty()) {
        callback(false, QString(), QString(), QStringLiteral("音频为空"));
        return;
    }
    const QString apiKey = m_config.voice.qwen.apiKey;
    if (apiKey.isEmpty()) {
        callback(false, QString(), QString(), QStringLiteral("没有 API Key"));
        return;
    }

    const QByteArray base64 = wav.toBase64();
    const QString prompt = QStringLiteral(
        "请逐字转录音频，保留原语言。根据本段音频，将说话者的整体情绪分类为"
        "neutral、happy、sad、angry、fearful、disgusted、surprised 之一。"
        "只返回一个 JSON 对象，且仅包含 transcript 和 emotion 两个字段。"
        "transcript 为逐字转录字符串，emotion 为上述七个英文值之一。"
        "不要输出解释、依据、置信度或其他字段。");

    QJsonObject audioObj;
    audioObj.insert(QStringLiteral("data"), QStringLiteral("data:;base64,") + QString::fromLatin1(base64));
    audioObj.insert(QStringLiteral("format"), QStringLiteral("wav"));
    QJsonObject audioPart;
    audioPart.insert(QStringLiteral("type"), QStringLiteral("input_audio"));
    audioPart.insert(QStringLiteral("input_audio"), audioObj);
    QJsonObject textPart;
    textPart.insert(QStringLiteral("type"), QStringLiteral("text"));
    textPart.insert(QStringLiteral("text"), prompt);
    QJsonArray content;
    content.append(audioPart);
    content.append(textPart);
    QJsonObject message;
    message.insert(QStringLiteral("role"), QStringLiteral("user"));
    message.insert(QStringLiteral("content"), content);
    QJsonArray messages;
    messages.append(message);

    QJsonObject body;
    body.insert(QStringLiteral("model"), QStringLiteral("qwen3.5-omni-flash-2026-03-15"));
    body.insert(QStringLiteral("messages"), messages);
    body.insert(QStringLiteral("stream"), false);
    body.insert(QStringLiteral("modalities"), QJsonArray{QStringLiteral("text")});

    QNetworkRequest request(QUrl(QStringLiteral("https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions")));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    request.setRawHeader("Authorization", "Bearer " + apiKey.toUtf8());

    QNetworkReply* reply = m_net->post(request, QJsonDocument(body).toJson(QJsonDocument::Compact));
    QTimer::singleShot(60000, reply, [reply]() {
        if (reply->isRunning()) {
            reply->abort();
        }
    });
    connect(reply, &QNetworkReply::finished, reply, [this, reply, callback]() {
        const QByteArray payload = reply->readAll();
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            Log::warn(QStringLiteral("情绪识别失败：%1").arg(reply->errorString()));
            callback(false, QString(), QString(), reply->errorString());
            return;
        }
        const QJsonObject root = QJsonDocument::fromJson(payload).object();
        QString content = root.value(QStringLiteral("choices")).toArray().at(0).toObject()
                              .value(QStringLiteral("message")).toObject()
                              .value(QStringLiteral("content")).toString();
        content = content.trimmed();
        const int start = content.indexOf(QLatin1Char('{'));
        const int end = content.lastIndexOf(QLatin1Char('}'));
        if (start >= 0 && end > start) {
            content = content.mid(start, end - start + 1);
        }
        const QJsonObject result = QJsonDocument::fromJson(content.toUtf8()).object();
        const QString transcript = result.value(QStringLiteral("transcript")).toString();
        const QString emotion = result.value(QStringLiteral("emotion")).toString();
        if (emotion.isEmpty()) {
            Log::warn(QStringLiteral("情绪识别返回异常：%1").arg(QString::fromUtf8(payload).left(200)));
            callback(false, transcript, QString(), QStringLiteral("返回格式不正确"));
            return;
        }
        Log::info(QStringLiteral("情绪识别：%1（%2）").arg(emotion, transcript.left(20)));
        callback(true, transcript, emotion, QString());
    });
}


QString AppController::petExpressionDir() const
{
    const QFileInfo modelInfo(nativePetModelPath());
    return QDir(modelInfo.absolutePath()).absoluteFilePath(QStringLiteral("EXP"));
}

QStringList AppController::scanPetExpressions() const
{
    const QDir dir(petExpressionDir());
    if (!dir.exists()) {
        Log::warn(QStringLiteral("[pet] EXP 目录不存在: %1").arg(dir.absolutePath()));
        return {};
    }
    QStringList names;
    const QStringList files = dir.entryList({QStringLiteral("*.exp3.json")}, QDir::Files, QDir::Name);
    for (const QString& file : files) {
        QString name = file;
        if (name.endsWith(QStringLiteral(".exp3.json"), Qt::CaseInsensitive)) {
            name.chop(static_cast<int>(QStringLiteral(".exp3.json").size()));
        }
        if (!name.isEmpty()) {
            names.append(name);
        }
    }
    return names;
}

QStringList AppController::petExpressions() const
{
    if (!m_config.petExpressions.isEmpty()) {
        return m_config.petExpressions;
    }
    return scanPetExpressions();
}

void AppController::importPetExpressions()
{
    const QStringList scanned = scanPetExpressions();
    m_config.petExpressions = scanned;
    saveConfig();
    notifyUi();
    Log::info(QStringLiteral("[pet] 已导入 %1 个表情（%2）")
                  .arg(scanned.size())
                  .arg(petExpressionDir()));
}

void AppController::removePetExpression(const QString& name)
{
    if (m_config.petExpressions.removeAll(name) > 0) {
        saveConfig();
        notifyUi();
        Log::info(QStringLiteral("[pet] 已从列表移除表情：%1").arg(name));
    }
}

void AppController::keepPetExpression(const QString& name)
{
    if (name.isEmpty()) {
        return;
    }
    if (m_latchedPetExpressions.contains(name)) {
        m_latchedPetExpressions.removeAll(name);
    } else {
        m_latchedPetExpressions.append(name);
    }
    sendToNativePet(QStringLiteral("exprk ") + name);
    Log::info(QStringLiteral("[pet] 保留触发 %1（当前 %2 个）")
                  .arg(name)
                  .arg(m_latchedPetExpressions.size()));
    notifyUi();
}

void AppController::oncePetExpression(const QString& name)
{
    if (name.isEmpty()) {
        return;
    }
    sendToNativePet(QStringLiteral("expr ") + name);
    Log::info(QStringLiteral("[pet] 一次性触发 %1").arg(name));
}

void AppController::clearPetExpressions()
{
    m_latchedPetExpressions.clear();
    sendToNativePet(QStringLiteral("exprclear"));
    notifyUi();
}

void AppController::playPetAction(const QString& name)
{
    if (name.isEmpty()) {
        return;
    }



    sendToNativePet(QStringLiteral("act ") + name);
    Log::info(QStringLiteral("[pet] 动作 %1").arg(name));
}

void AppController::classifyHintsAsync(const QString& hintsText)
{
    const QString text = hintsText.trimmed();
    if (text.isEmpty() || !m_net) { return; }
    if (m_classifyCache.contains(text)) {
        const auto cached = m_classifyCache.value(text);
        if (!cached.first.isEmpty()) { applyEmotion(cached.first); }
        if (!cached.second.isEmpty()) { playPetAction(cached.second); }
        return;
    }
    Log::info(QStringLiteral("[pet] 开始请求本地判定：%1").arg(text.left(30)));
    const QString prompt = QStringLiteral("判断下面这段描写体现的情绪和动作。只输出 JSON，不要解释。\n"
                            "emotion 只能取：happy, excited, shy, love, sad, cry, angry, surprised, confused, think, tease, dark, dizzy, tired，或空字符串。\n"
                            "action 只能取：nod, shake, tail, bow，或空字符串。\n"
                            "描写：%1").arg(text.left(200));
    QJsonObject message;
    message.insert(QStringLiteral("role"), QStringLiteral("user"));
    message.insert(QStringLiteral("content"), prompt);
    QJsonArray messages;
    messages.append(message);
    QJsonObject root;
    root.insert(QStringLiteral("model"), QStringLiteral("local-vl"));
    root.insert(QStringLiteral("messages"), messages);
    root.insert(QStringLiteral("temperature"), 0);
    root.insert(QStringLiteral("max_tokens"), 120);
    QNetworkRequest request(QUrl(QStringLiteral("http://127.0.0.1:8099/v1/chat/completions")));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
    request.setTransferTimeout(60000);   // 4B 冷启动可能要几十秒，别 8 秒就丢
    QNetworkReply* reply = m_net->post(request, QJsonDocument(root).toJson(QJsonDocument::Compact));
    connect(reply, &QNetworkReply::finished, this, [this, reply, text]() {
        reply->deleteLater();
        if (reply->error() != QNetworkReply::NoError) {
            Log::warn(QStringLiteral("[pet] 本地小模型不可用：%1").arg(reply->errorString()));
            return;
        }
        const QJsonObject root = QJsonDocument::fromJson(reply->readAll()).object();
        const QString content = root.value(QStringLiteral("choices")).toArray().at(0).toObject()
                                    .value(QStringLiteral("message")).toObject()
                                    .value(QStringLiteral("content")).toString();
        Log::info(QStringLiteral("[pet] 本地小模型原始返回：%1").arg(content.left(80)));
        const int brace = content.indexOf(QLatin1Char('{'));
        const int last = content.lastIndexOf(QLatin1Char('}'));

        if (brace < 0 || last <= brace) {
            Log::warn(QStringLiteral("[pet] 本地判定返回无法解析：%1").arg(content.left(120)));
            return;
        }
        const QJsonObject result = QJsonDocument::fromJson(content.mid(brace, last - brace + 1).toUtf8()).object();
        const QString emotion = result.value(QStringLiteral("emotion")).toString().trimmed();
        const QString action = result.value(QStringLiteral("action")).toString().trimmed();
        m_classifyCache.insert(text, qMakePair(emotion, action));
        Log::info(QStringLiteral("[pet] 本地小模型：emotion=%1 action=%2")
                      .arg(emotion.isEmpty() ? QStringLiteral("-") : emotion,
                           action.isEmpty() ? QStringLiteral("-") : action));
        if (!emotion.isEmpty() && emotion != QStringLiteral("none")) { applyEmotion(emotion); }
        if (!action.isEmpty() && action != QStringLiteral("none")) { playPetAction(action); }
    });
}
void AppController::triggerPetExpression(const QString& name)
{
    if (name.isEmpty()) {
        return;
    }
    sendToNativePet(QStringLiteral("expr ") + name);
    Log::info(QStringLiteral("[pet] 触发表情：%1").arg(name));
}
QString AppController::nativePetModelPath() const
{
    const QByteArray override = qgetenv("DEMON_LIVE2D_MODEL");
    if (!override.isEmpty()) {
        return QString::fromUtf8(override);
    }

    // 优先固定路径；不存在就扫 models/live2d/*/*.model3.json，
    // 避免源码里的中文路径因编码问题变成乱码后找不到模型。
    const QString fixed = QStringLiteral("E:/dshwork/models/live2d/大肥鱼-B站/大肥鱼.model3.json");
    if (QFileInfo::exists(fixed)) {
        return fixed;
    }

    QDirIterator it(QStringLiteral("E:/dshwork/models/live2d"),
                    {QStringLiteral("*.model3.json")}, QDir::Files, QDirIterator::Subdirectories);
    if (it.hasNext()) {
        return it.next();
    }
    return fixed;
}
void AppController::sendToNativePet(const QString& line)
{
    if (!m_nativePetProcess || m_nativePetProcess->state() != QProcess::Running) {
        return;
    }
    m_nativePetProcess->write(line.toUtf8());
    m_nativePetProcess->write("\n");
}

bool AppController::startNativePet(QString* error)
{
    if (m_nativePetProcess && m_nativePetProcess->state() == QProcess::Running) {
        return true;
    }

    const QString modelPath = nativePetModelPath();
    if (!QFileInfo::exists(modelPath)) {
        if (error) {
            *error = QStringLiteral("模型不存在：%1").arg(modelPath);
        }
        return false;
    }

    m_nativePetProcess = std::make_unique<QProcess>();
    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();
    env.insert(QStringLiteral("DEMON_LIVE2D_MODEL"), modelPath);
    m_nativePetProcess->setProcessEnvironment(env);
    m_nativePetProcess->setProgram(QCoreApplication::applicationFilePath());
    m_nativePetProcess->setArguments({QStringLiteral("--live2d-pet"),
                                      QStringLiteral("--parent-pid"),
                                      QString::number(QCoreApplication::applicationPid())});
    m_nativePetProcess->start();
    if (!m_nativePetProcess->waitForStarted(5000)) {
        if (error) {
            *error = QStringLiteral("桌宠进程启动失败：%1").arg(m_nativePetProcess->errorString());
        }
        m_nativePetProcess.reset();
        return false;
    }

    Log::info(QStringLiteral("原生桌宠子进程已启动：%1").arg(modelPath));
    return true;
}

void AppController::stopNativePet()
{
    if (!m_nativePetProcess) {
        return;
    }
    sendToNativePet(QStringLiteral("quit"));
    if (!m_nativePetProcess->waitForFinished(2000)) {
        m_nativePetProcess->kill();
        m_nativePetProcess->waitForFinished(1000);
    }
    m_nativePetProcess.reset();
    Log::info(QStringLiteral("原生桌宠已关闭"));
}

bool AppController::nativePetActive() const
{
    return m_nativePetProcess && m_nativePetProcess->state() == QProcess::Running;
}

void AppController::setNativePetClickThrough(bool on)
{
    // 点击穿透由桌宠子进程自己按光标位置动态切换，这里不需要做什么
    Q_UNUSED(on);
}
bool AppController::smallDemonRunning() const
{
    return portOpen(8792);
}

void AppController::stopSmallDemon()
{
    postSmallDemon(QStringLiteral("/quit"), {});
    Log::info(QStringLiteral("已请求桌宠退出（small demon）"));
}


void AppController::syncDsh(bool chats, bool worlds,
                            std::function<void(bool, const QString&)> callback)
{
    if (!m_dsh) {
        callback(false, QStringLiteral("dsh-demon 未初始化"));
        return;
    }
    m_dsh->sync(chats, worlds, [callback](bool ok, const QJsonObject& result) {
        if (!ok) {
            callback(false, QStringLiteral("请求失败，检查 dsh-demon 是否在运行"));
            return;
        }
        const QJsonObject chat = result.value(QStringLiteral("chats")).toObject();
        const QJsonObject world = result.value(QStringLiteral("worlds")).toObject();
        const int newMessages = chat.value(QStringLiteral("newMessages")).toInt();
        const int files = chat.value(QStringLiteral("files")).toInt();
        const int worldsCount = world.value(QStringLiteral("files")).toInt();
        callback(true, QStringLiteral("聊天 %1 文件 / 新增 %2 条，世界书 %3 个")
                           .arg(files).arg(newMessages).arg(worldsCount));
    });
}


bool AppController::startSmallDemon(QString* error)
{
    const QString bat = QStringLiteral("E:/dshwork/small-demon/Start-SmallDemon.cmd");
    if (!QFileInfo::exists(bat)) {
        if (error) {
            *error = QStringLiteral("找不到 small demon：%1").arg(bat);
        }
        return false;
    }
    const bool ok = QProcess::startDetached(
        QStringLiteral("cmd.exe"),
        {QStringLiteral("/c"), QStringLiteral("start"), QString(), QDir::toNativeSeparators(bat)},
        QFileInfo(bat).absolutePath());
    if (ok) {
        Log::info(QStringLiteral("已启动 small demon：%1").arg(bat));
    } else if (error) {
        *error = QStringLiteral("启动失败");
    }
    return ok;
}


void AppController::setDshAutoTransfer(bool on)
{
    if (m_dsh) {
        m_dsh->setAutoTransfer(on);
    }
}


void AppController::updateVoiceProfile(const QString& id, const QString& field, const QString& value)
{
    for (VoiceProfileConfig& p : m_config.voiceProfiles) {
        if (p.id != id) continue;
        if (field == QStringLiteral("language")) p.language = value;
        else if (field == QStringLiteral("cloudAudio")) p.cloudAudio = value;
        else if (field == QStringLiteral("cloudPreview")) p.cloudPreview = value;
        else if (field == QStringLiteral("refAudio")) p.refAudio = value;
        else if (field == QStringLiteral("promptText")) p.promptText = value;
        else if (field == QStringLiteral("qwenVoice")) p.qwenVoice = value;
        else if (field == QStringLiteral("gptWeights")) p.gptWeights = value;
        else if (field == QStringLiteral("sovitsWeights")) p.sovitsWeights = value;
        else return;
        m_config.save(m_config.filePath);
        if (m_tts) m_tts->setProfiles(buildVoiceProfiles());
        Log::info(QStringLiteral("档案 %1.%2 = %3").arg(id, field, value.left(40)));
        return;
    }
}
