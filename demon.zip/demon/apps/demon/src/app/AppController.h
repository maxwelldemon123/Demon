#pragma once

#include "config/Config.h"
#include "voice/TtsClient.h"
#include "http/HttpServer.h"

#include <QHash>
#include <QMap>
#include <QObject>
#include <QStringList>
#include <QSystemTrayIcon>

#include <memory>

class QAction;
class QMenu;
class QActionGroup;
class QNetworkAccessManager;
class QSharedMemory;
class TtsClient;
class MainWindow;
class AudioPlayer;
class VtsClient;
class PetWindow;
class DshClient;
class Live2DWindow;
class QProcess;

/**
 * 应用控制器：
 *   - OpenAI 兼容端点（/v1/*）
 *   - 语音合成（/voice/*），播放由酒馆插件 smartdemon 负责
 *   - 启动器（酒馆 / GPT-SoVITS）
 *   - 角色声线绑定
 */
class AppController : public QObject {
    Q_OBJECT

public:
    explicit AppController(QObject* parent = nullptr);
    ~AppController() override;

    bool start();

    // ---- 供 UI 调用 ----
    const Config& config() const { return m_config; }
    Config& mutableConfig() { return m_config; }
    void saveConfig();

    void applyProfile(const QString& id);
    void openLogFile();
    void openConfigFolder();
    void reloadConfig();

    QStringList listCharacters() const;
    QString effectiveCharactersDir() const;
    void setCharacterVoice(const QString& character, const QString& profileId);
    void setDefaultProfile(const QString& profileId);

    void testVoice(const QString& profileId);
    QStringList audioDevices() const;
    void setOutputDevice(const QString& name);
    void setVoiceVolume(double value);

    bool startSillyTavern(QString* error = nullptr);
    bool stopSillyTavern(QString* error = nullptr);
    bool startVoiceService(QString* error = nullptr);
    bool stopVoiceService(QString* error = nullptr);

    static bool portOpen(quint16 port);

    bool openExternalUrl(const QString& url);
    bool openInEdge(const QString& url);

    void notifyUi();

    // Live2D（VTube Studio）
    QString live2dStateName() const;
    QString live2dError() const;
    QString live2dEndpoint() const;
    void reconnectLive2d();
    void injectMouth(double value);
    void applyEmotion(const QString& emotion);
    void ensureWatermarkHidden();
    void clearEmotionExpressions();

    bool needsJapaneseTranslation(const QString& text) const;
    void translateToJapanese(const QString& text, std::function<void(bool, const QString&)> callback);
    static QString detectEmotionFromText(const QString& text);

public:
    void testEmotion(const QString& emotion);
    // 原生桌宠（Demon 内置，Cubism Framework + OpenGL）
    bool startNativePet(QString* error);
    void stopNativePet();
    bool nativePetActive() const;
    void setNativePetClickThrough(bool on);
    QString nativePetModelPath() const;
    // small demon（Electron，8792 提供 /expression /mouth /quit）——备用
    // 原生桌宠表情库（EXP/*.exp3.json，导入后可删、可触发）
    QString petExpressionDir() const;
    QStringList scanPetExpressions() const;
    QStringList petExpressions() const;
    void importPetExpressions();
    void removePetExpression(const QString& name);
    void triggerPetExpression(const QString& name);
    // 保留触发：可叠加多个，再次调用同一项则取消
    void keepPetExpression(const QString& name);
    // 一次性触发：新的顶掉旧的，保留触发的不受影响
    void oncePetExpression(const QString& name);
    void clearPetExpressions();
    // 动作层：nod / shake / tail / bow
    void playPetAction(const QString& name);

    // 用本地 4B 小模型判断括号里的神态描写（关键词表覆盖不到时兜底）
    void classifyHintsAsync(const QString& hintsText);
    QHash<QString, QPair<QString, QString>> m_classifyCache;   // 描写 -> (emotion, action)
    // 括号描写常被拆成单独一段（甚至整段都是括号），暂存下来给下一句判定用
    QStringList m_pendingHints;
    QStringList latchedPetExpressions() const { return m_latchedPetExpressions; }

    bool startSmallDemon(QString* error);
    void stopSmallDemon();
    bool smallDemonRunning() const;
    void setDshAutoTransfer(bool on);
    void updateVoiceProfile(const QString& id, const QString& field, const QString& value);
    void syncDsh(bool chats, bool worlds,
                 std::function<void(bool ok, const QString& message)> callback);
    QString expressionForEmotion(const QString& emotion) const;

    QStringList live2dModels() const;
    void loadLive2dModel(const QString& modelName);
    void setCharacterProvider(const QString& character, const QString& source);
    void setCharacterModel(const QString& character, const QString& modelName);
    void recognizeEmotion(const QByteArray& wav,
                          std::function<void(bool ok, const QString& transcript,
                                             const QString& emotion, const QString& error)> callback);
    bool setVtsWindowBorderless(bool on);
    void refreshLive2dHotkeys();
    QStringList live2dHotkeys() const;
    QStringList live2dHotkeyIds() const;
    void triggerLive2dHotkey(const QString& hotkeyId);
    bool setVtsDesktopPet(bool on, const QString& colorKeyHex);
    bool startVTubeStudio(QString* error = nullptr);
    bool stopVTubeStudio(QString* error = nullptr);
    QString currentModelName() const;
    QStringList availableExpressions() const;
    QStringList availableExpressionFiles() const;
    void sendLive2dRaw(const QString& type, const QJsonObject& data);
    QJsonObject lastLive2dResponse(const QString& type) const;

signals:
    void uiDirty();

private:
    HttpResponse handleRequest(const HttpRequest& request);
    HttpResponse handleHealthz(const HttpRequest& request);
    HttpResponse handleModels(const HttpRequest& request);
    HttpResponse handleChatCompletions(const HttpRequest& request);
    HttpResponse handleVoiceStatus(const HttpRequest& request);
    bool handleVoiceSpeak(const HttpRequest& request, const std::shared_ptr<HttpStream>& stream);
    HttpResponse handleLive2dStatus(const HttpRequest& request);
    HttpResponse handleLive2dTest(const HttpRequest& request);

    bool handleChatStream(const HttpRequest& request, const std::shared_ptr<HttpStream>& stream);

    const UpstreamConfig* pickUpstream(const QString& modelFromRequest) const;
    QByteArray rewriteModel(const QByteArray& body, const QString& upstreamModel) const;

    QVector<VoiceProfile> buildVoiceProfiles() const;
    void setupVoice();

    void startLipSync(const QByteArray& wav);
    void setupTray();
    void showStatus();

    Config m_config;
    std::unique_ptr<HttpServer> m_server;
    std::unique_ptr<QNetworkAccessManager> m_net;
    std::unique_ptr<TtsClient> m_tts;
    std::unique_ptr<AudioPlayer> m_audio;
    std::unique_ptr<VtsClient> m_vts;
    std::unique_ptr<PetWindow> m_petWindow;
    std::unique_ptr<DshClient> m_dsh;
    // 原生桌宠跑在自己的子进程里（demon.exe --live2d-pet），避免同进程呈现被压到 10fps
    std::unique_ptr<QProcess> m_nativePetProcess;
    QStringList m_latchedPetExpressions;   // 当前「保留触发」的表情（UI 高亮用）
    void sendToNativePet(const QString& line);
    quintptr m_vtsWindow = 0;
    int m_vtsSavedX = 0;
    int m_vtsSavedY = 0;
    int m_vtsSavedW = 0;
    int m_vtsSavedH = 0;
    QTimer* m_mouthTimer = nullptr;
    QVector<float> m_mouthEnvelope;
    int m_mouthIndex = 0;
    double m_mouthSmoothed = 0.0;   // 口型平滑后的当前值
    bool m_mouthAwaitingPlayback = false;   // 等浏览器真正开播再跑包络
    QString m_currentModel;
    QString m_pendingModel;
    QHash<QString, QJsonObject> m_vtsLastResponses;
    QStringList m_exprNames;
    QStringList m_activeEmotion;
    QHash<QString, QString> m_jaCache;       // 当前激活的情绪表情文件（不含水印）
    QTimer* m_emotionResetTimer = nullptr;
    QStringList m_exprFiles;
    void loadModelExpressions(const QString& modelName, const QString& modelId);
    QSystemTrayIcon* m_tray = nullptr;
    QMenu* m_menu = nullptr;
    QAction* m_statusAction = nullptr;
    QMenu* m_voiceMenu = nullptr;
    QActionGroup* m_profileGroup = nullptr;
    qint64 m_startedAtMs = 0;
    QString m_dataDir;
    QSharedMemory* m_instanceLock = nullptr;
    std::unique_ptr<MainWindow> m_window;

    QString m_activeProfile;
};
