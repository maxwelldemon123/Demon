#pragma once

#include <QMap>
#include <QString>
#include <QVector>

/**
 * 运行配置：<exe 目录>/config.json
 * 缺省时使用内置默认值，并在首次启动时写一份示例。
 */
struct UpstreamConfig {
    QString id;
    QString baseUrl;   // 例如 http://127.0.0.1:8080/v1
    QString model;     // 上游模型名
    QString apiKey;
};

struct VoiceProfileConfig {
    QString id;
    QString name;         // 显示名（可空，空则用 id）
    QString gptWeights;   // GPT 权重（相对 api_v2 的 cwd 或绝对路径），可空
    QString sovitsWeights;// SoVITS 权重，可空
    QString refAudio;     // 参考音频（相对 api_v2 的 cwd 或绝对路径）
    QString promptText;   // 参考音频原文
    QString promptLang = QStringLiteral("ja");
    QString qwenVoice;   // 千问/CosyVoice 复刻音色 ID
    QString source = QStringLiteral("local");   // local | cloud
    QString language = QStringLiteral("ja");    // zh | en | ja
    QString cloudAudio;   // 云端：长音频（生成/更新 voice ID）
    QString cloudPreview; // 云端：短参考音频（试听/对比）
};

struct LauncherConfig {
    QString stPath = QStringLiteral("C:\\mylove\\SillyTavern");
    int stPort = 8000;
    QString gsvPath = QStringLiteral("E:\\GPT-SoVITS-v5-20261005\\GPT-SoVITS-v2pro-20261006");
};

struct Live2dConfig {
    QString host = QStringLiteral("127.0.0.1");
    quint16 port = 8001;
    QString vtsExe;      // VTube Studio.exe 路径
    QString modelsDir;   // VTube Studio 的 Live2DModels 目录
};

struct QwenTtsConfig {
    QString baseUrl = QStringLiteral("https://dashscope.aliyuncs.com/api/v1/services/audio/tts/SpeechSynthesizer");
    QString apiKey;
    QString model = QStringLiteral("qwen-audio-3.1-tts-flash");
    QString voice = QStringLiteral("longanhuan_v3.1");
    QString format = QStringLiteral("wav");
    int sampleRate = 24000;
};

struct VoiceConfig {
    QString endpoint = QStringLiteral("http://127.0.0.1:9880");
    QString profile = QStringLiteral("xiaod");
    double speed = 1.0;
    double volume = 1.0;
    QString outputDevice;   // 空 = 系统默认

    // 合成后端：gptsovits | qwen
    // 故意默认为空：谁也没选就报错让用户选，绝不静默用某个后端
    QString provider;
    bool translateToJa = false;   // 中文台词先翻成日语再合成
    QwenTtsConfig qwen;
};

class Config {
public:
    static Config load(const QString& filePath);

    bool save(const QString& filePath) const;
    QString toJson() const;

    QString filePath;

    // 监听
    QString host = QStringLiteral("127.0.0.1");
    quint16 port = 8790;

    // 对外声明的模型名（酒馆下拉框里显示）
    QString modelId = QStringLiteral("demon");

    // 上游
    QVector<UpstreamConfig> upstreams;
    QString defaultUpstreamId;

    // 语音
    VoiceConfig voice;
    QVector<VoiceProfileConfig> voiceProfiles;

    // 启动器
    LauncherConfig launcher;

    // Live2D（VTube Studio）
    Live2dConfig live2d;

    // 原生桌宠可触发的表情（EXP/*.exp3.json 的基名，导入后持久化，可删）
    QStringList petExpressions;

    // 角色声线绑定：角色名 -> 档案 id
    QMap<QString, QString> characterVoices;
    QMap<QString, QString> characterProviders;   // 角色 -> local/cloud
    QMap<QString, QString> characterModels;
    QMap<QString, QString> emotionHotkeys;   // 情绪 -> VTS 热键 ID      // 角色 -> Live2D 模型名

    // 角色卡目录（空则用 <stPath>\data\default-user\characters）
    QString charactersDir;

    // 其它
    int keepAliveSeconds = 15;
    int requestTimeoutSeconds = 180;

    /** 找默认上游；没有则返回空 id */
    QString effectiveUpstreamId() const;
};
