#include "Config.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>


namespace {

/** 首次运行/缺少配置时的默认声线 */
QVector<VoiceProfileConfig> defaultVoiceProfiles()
{
    VoiceProfileConfig xiaod;
    xiaod.id = QStringLiteral("xiaod");
    xiaod.refAudio = QStringLiteral("refs/xiaod.wav");
    xiaod.promptText = QStringLiteral("私を強くして……どうするつもりですか？");
    xiaod.promptLang = QStringLiteral("ja");

    VoiceProfileConfig demon;
    demon.id = QStringLiteral("demon");
    demon.refAudio = QStringLiteral("refs/demon.wav");
    demon.promptText = QStringLiteral("この人たちが敵ね。へーえ、面白そうじゃない。");
    demon.promptLang = QStringLiteral("ja");

    return {xiaod, demon};
}

} // namespace

QString Config::effectiveUpstreamId() const
{
    if (!defaultUpstreamId.isEmpty()) {
        return defaultUpstreamId;
    }
    return upstreams.isEmpty() ? QString() : upstreams.first().id;
}

Config Config::load(const QString& filePath)
{
    Config cfg;
    cfg.filePath = filePath;

    QFile file(filePath);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        // 首次运行：给一个本地上游示例，便于命令行验证
        UpstreamConfig local;
        local.id = QStringLiteral("local");
        local.baseUrl = QStringLiteral("http://127.0.0.1:8080/v1");
        local.model = QStringLiteral("local-model");
        cfg.upstreams.append(local);
        cfg.defaultUpstreamId = local.id;

        cfg.voiceProfiles = defaultVoiceProfiles();
        cfg.save(filePath);
        return cfg;
    }

    const QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    const QJsonObject root = doc.object();

    const QJsonObject listen = root.value(QStringLiteral("listen")).toObject();
    if (!listen.isEmpty()) {
        cfg.host = listen.value(QStringLiteral("host")).toString(cfg.host);
        cfg.port = static_cast<quint16>(listen.value(QStringLiteral("port")).toInt(cfg.port));
    }

    cfg.modelId = root.value(QStringLiteral("modelId")).toString(cfg.modelId);
    cfg.defaultUpstreamId = root.value(QStringLiteral("defaultUpstream")).toString();

    const QJsonArray ups = root.value(QStringLiteral("upstreams")).toArray();
    for (const QJsonValue& v : ups) {
        const QJsonObject o = v.toObject();
        UpstreamConfig u;
        u.id = o.value(QStringLiteral("id")).toString();
        u.baseUrl = o.value(QStringLiteral("baseUrl")).toString();
        u.model = o.value(QStringLiteral("model")).toString();
        u.apiKey = o.value(QStringLiteral("apiKey")).toString();
        if (!u.id.isEmpty() && !u.baseUrl.isEmpty()) {
            cfg.upstreams.append(u);
        }
    }

    const QJsonObject voice = root.value(QStringLiteral("voice")).toObject();
    if (!voice.isEmpty()) {
        cfg.voice.endpoint = voice.value(QStringLiteral("endpoint")).toString(cfg.voice.endpoint);
        cfg.voice.profile = voice.value(QStringLiteral("profile")).toString(cfg.voice.profile);
        cfg.voice.speed = voice.value(QStringLiteral("speed")).toDouble(cfg.voice.speed);
        cfg.voice.volume = voice.value(QStringLiteral("volume")).toDouble(cfg.voice.volume);
        cfg.voice.outputDevice = voice.value(QStringLiteral("outputDevice")).toString(cfg.voice.outputDevice);
        cfg.voice.provider = voice.value(QStringLiteral("provider")).toString(cfg.voice.provider);
        cfg.voice.translateToJa = voice.value(QStringLiteral("translateToJa")).toBool(cfg.voice.translateToJa);

        const QJsonObject qwen = voice.value(QStringLiteral("qwen")).toObject();
        if (!qwen.isEmpty()) {
            cfg.voice.qwen.baseUrl = qwen.value(QStringLiteral("baseUrl")).toString(cfg.voice.qwen.baseUrl);
            cfg.voice.qwen.apiKey = qwen.value(QStringLiteral("apiKey")).toString(cfg.voice.qwen.apiKey);
            cfg.voice.qwen.model = qwen.value(QStringLiteral("model")).toString(cfg.voice.qwen.model);
            cfg.voice.qwen.voice = qwen.value(QStringLiteral("voice")).toString(cfg.voice.qwen.voice);
            cfg.voice.qwen.format = qwen.value(QStringLiteral("format")).toString(cfg.voice.qwen.format);
            cfg.voice.qwen.sampleRate = qwen.value(QStringLiteral("sampleRate")).toInt(cfg.voice.qwen.sampleRate);
        }
    }

    const QJsonArray profiles = root.value(QStringLiteral("voiceProfiles")).toArray();
    for (const QJsonValue& v : profiles) {
        const QJsonObject o = v.toObject();
        VoiceProfileConfig p;
        p.id = o.value(QStringLiteral("id")).toString();
        p.name = o.value(QStringLiteral("name")).toString();
        p.gptWeights = o.value(QStringLiteral("gptWeights")).toString();
        p.sovitsWeights = o.value(QStringLiteral("sovitsWeights")).toString();
        p.refAudio = o.value(QStringLiteral("refAudio")).toString();
        p.promptText = o.value(QStringLiteral("promptText")).toString();
        p.promptLang = o.value(QStringLiteral("promptLang")).toString(QStringLiteral("ja"));
        p.qwenVoice = o.value(QStringLiteral("qwenVoice")).toString();
        p.source = o.value(QStringLiteral("source")).toString(QStringLiteral("local"));
        p.language = o.value(QStringLiteral("language")).toString(QStringLiteral("ja"));
        p.cloudAudio = o.value(QStringLiteral("cloudAudio")).toString();
        p.cloudPreview = o.value(QStringLiteral("cloudPreview")).toString();
        if (!p.id.isEmpty() && !p.refAudio.isEmpty()) {
            cfg.voiceProfiles.append(p);
        }
    }

    if (cfg.voiceProfiles.isEmpty()) {
        cfg.voiceProfiles = defaultVoiceProfiles();
    }

    const QJsonObject launcher = root.value(QStringLiteral("launcher")).toObject();
    if (!launcher.isEmpty()) {
        cfg.launcher.stPath = launcher.value(QStringLiteral("stPath")).toString(cfg.launcher.stPath);
        cfg.launcher.stPort = launcher.value(QStringLiteral("stPort")).toInt(cfg.launcher.stPort);
        cfg.launcher.gsvPath = launcher.value(QStringLiteral("gsvPath")).toString(cfg.launcher.gsvPath);
    }

    cfg.charactersDir = root.value(QStringLiteral("charactersDir")).toString();

    const QJsonObject charVoices = root.value(QStringLiteral("characterVoices")).toObject();
    for (auto it = charVoices.constBegin(); it != charVoices.constEnd(); ++it) {
        cfg.characterVoices.insert(it.key(), it.value().toString());
    }
    const QJsonObject charProviders = root.value(QStringLiteral("characterProviders")).toObject();
    for (auto it = charProviders.constBegin(); it != charProviders.constEnd(); ++it) {
        cfg.characterProviders.insert(it.key(), it.value().toString());
    }
    const QJsonObject charModels = root.value(QStringLiteral("characterModels")).toObject();
    for (auto it = charModels.constBegin(); it != charModels.constEnd(); ++it) {
        cfg.characterModels.insert(it.key(), it.value().toString());
    }
    const QJsonObject emotionHotkeys = root.value(QStringLiteral("emotionHotkeys")).toObject();
    for (auto it = emotionHotkeys.constBegin(); it != emotionHotkeys.constEnd(); ++it) {
        cfg.emotionHotkeys.insert(it.key(), it.value().toString());
    }

    const QJsonObject live2d = root.value(QStringLiteral("live2d")).toObject();
    if (!live2d.isEmpty()) {
        cfg.live2d.host = live2d.value(QStringLiteral("host")).toString(cfg.live2d.host);
        cfg.live2d.port = static_cast<quint16>(live2d.value(QStringLiteral("port")).toInt(cfg.live2d.port));
        cfg.live2d.vtsExe = live2d.value(QStringLiteral("vtsExe")).toString(cfg.live2d.vtsExe);
        cfg.live2d.modelsDir = live2d.value(QStringLiteral("modelsDir")).toString(cfg.live2d.modelsDir);
    }
    const QJsonArray petExprs = root.value(QStringLiteral("petExpressions")).toArray();
    cfg.petExpressions.clear();
    for (const QJsonValue& item : petExprs) {
        const QString name = item.toString();
        if (!name.isEmpty()) {
            cfg.petExpressions.append(name);
        }
    }

    const QJsonObject engine = root.value(QStringLiteral("engine")).toObject();
    if (!engine.isEmpty()) {
        cfg.keepAliveSeconds = engine.value(QStringLiteral("keepAliveSeconds")).toInt(cfg.keepAliveSeconds);
        cfg.requestTimeoutSeconds = engine.value(QStringLiteral("requestTimeoutSeconds")).toInt(cfg.requestTimeoutSeconds);
    }

    return cfg;
}

QString Config::toJson() const
{
    QJsonObject root;
    QJsonObject listen;
    listen.insert(QStringLiteral("host"), host);
    listen.insert(QStringLiteral("port"), port);
    root.insert(QStringLiteral("listen"), listen);
    root.insert(QStringLiteral("modelId"), modelId);

    QJsonArray ups;
    for (const UpstreamConfig& u : upstreams) {
        QJsonObject o;
        o.insert(QStringLiteral("id"), u.id);
        o.insert(QStringLiteral("baseUrl"), u.baseUrl);
        o.insert(QStringLiteral("model"), u.model);
        o.insert(QStringLiteral("apiKey"), u.apiKey);
        ups.append(o);
    }
    root.insert(QStringLiteral("upstreams"), ups);
    root.insert(QStringLiteral("defaultUpstream"), effectiveUpstreamId());

    QJsonObject voice;
    voice.insert(QStringLiteral("endpoint"), this->voice.endpoint);
    voice.insert(QStringLiteral("profile"), this->voice.profile);
    voice.insert(QStringLiteral("speed"), this->voice.speed);
    voice.insert(QStringLiteral("volume"), this->voice.volume);
    voice.insert(QStringLiteral("outputDevice"), this->voice.outputDevice);
    voice.insert(QStringLiteral("provider"), this->voice.provider);
    voice.insert(QStringLiteral("translateToJa"), this->voice.translateToJa);

    QJsonObject qwenOut;
    qwenOut.insert(QStringLiteral("baseUrl"), this->voice.qwen.baseUrl);
    qwenOut.insert(QStringLiteral("apiKey"), this->voice.qwen.apiKey);
    qwenOut.insert(QStringLiteral("model"), this->voice.qwen.model);
    qwenOut.insert(QStringLiteral("voice"), this->voice.qwen.voice);
    qwenOut.insert(QStringLiteral("format"), this->voice.qwen.format);
    qwenOut.insert(QStringLiteral("sampleRate"), this->voice.qwen.sampleRate);
    voice.insert(QStringLiteral("qwen"), qwenOut);
    root.insert(QStringLiteral("voice"), voice);

    QJsonArray profilesOut;
    for (const VoiceProfileConfig& p : voiceProfiles) {
        QJsonObject o;
        o.insert(QStringLiteral("id"), p.id);
        o.insert(QStringLiteral("name"), p.name);
        o.insert(QStringLiteral("gptWeights"), p.gptWeights);
        o.insert(QStringLiteral("sovitsWeights"), p.sovitsWeights);
        o.insert(QStringLiteral("refAudio"), p.refAudio);
        o.insert(QStringLiteral("promptText"), p.promptText);
        o.insert(QStringLiteral("promptLang"), p.promptLang);
        o.insert(QStringLiteral("source"), p.source);
        o.insert(QStringLiteral("language"), p.language);
        if (!p.cloudAudio.isEmpty()) o.insert(QStringLiteral("cloudAudio"), p.cloudAudio);
        if (!p.cloudPreview.isEmpty()) o.insert(QStringLiteral("cloudPreview"), p.cloudPreview);
        if (!p.qwenVoice.isEmpty()) {
            o.insert(QStringLiteral("qwenVoice"), p.qwenVoice);
        }
        profilesOut.append(o);
    }
    root.insert(QStringLiteral("voiceProfiles"), profilesOut);

    QJsonObject launcherOut;
    launcherOut.insert(QStringLiteral("stPath"), launcher.stPath);
    launcherOut.insert(QStringLiteral("stPort"), launcher.stPort);
    launcherOut.insert(QStringLiteral("gsvPath"), launcher.gsvPath);
    root.insert(QStringLiteral("launcher"), launcherOut);

    root.insert(QStringLiteral("charactersDir"), charactersDir);

    QJsonObject charVoicesOut;
    for (auto it = characterVoices.constBegin(); it != characterVoices.constEnd(); ++it) {
        charVoicesOut.insert(it.key(), it.value());
    }
    root.insert(QStringLiteral("characterVoices"), charVoicesOut);
    QJsonObject charProvidersOut;
    for (auto it = characterProviders.constBegin(); it != characterProviders.constEnd(); ++it) {
        charProvidersOut.insert(it.key(), it.value());
    }
    root.insert(QStringLiteral("characterProviders"), charProvidersOut);
    QJsonObject charModelsOut;
    for (auto it = characterModels.constBegin(); it != characterModels.constEnd(); ++it) {
        charModelsOut.insert(it.key(), it.value());
    }
    root.insert(QStringLiteral("characterModels"), charModelsOut);
    QJsonObject emotionHotkeysOut;
    for (auto it = emotionHotkeys.constBegin(); it != emotionHotkeys.constEnd(); ++it) {
        emotionHotkeysOut.insert(it.key(), it.value());
    }
    root.insert(QStringLiteral("emotionHotkeys"), emotionHotkeysOut);

    QJsonArray petExprsOut;
    for (const QString& name : petExpressions) {
        petExprsOut.append(name);
    }
    root.insert(QStringLiteral("petExpressions"), petExprsOut);

    QJsonObject live2dOut;
    live2dOut.insert(QStringLiteral("host"), live2d.host);
    live2dOut.insert(QStringLiteral("port"), live2d.port);
    live2dOut.insert(QStringLiteral("vtsExe"), live2d.vtsExe);
    live2dOut.insert(QStringLiteral("modelsDir"), live2d.modelsDir);
    root.insert(QStringLiteral("live2d"), live2dOut);

    QJsonObject engine;
    engine.insert(QStringLiteral("keepAliveSeconds"), keepAliveSeconds);
    engine.insert(QStringLiteral("requestTimeoutSeconds"), requestTimeoutSeconds);
    root.insert(QStringLiteral("engine"), engine);

    return QString::fromUtf8(QJsonDocument(root).toJson(QJsonDocument::Indented));
}

bool Config::save(const QString& filePath) const
{
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        return false;
    }
    file.write(toJson().toUtf8());
    return true;
}
