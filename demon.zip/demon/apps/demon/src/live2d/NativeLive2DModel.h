#pragma once

#include <QElapsedTimer>
#include <QHash>
#include <QRectF>
#include <QSize>
#include <QString>
#include <QStringList>
#include <QVector>

#include <memory>

#include "CubismFramework.hpp"
#include "CubismModelSettingJson.hpp"
#include "Model/CubismUserModel.hpp"

namespace Csm = Live2D::Cubism::Framework;

/**
 * 原生 Live2D 模型（Cubism Framework 5-r.1 + OpenGL）。
 *
 * 只负责「加载 / 每帧更新 / 绘制 / 参数控制」，不依赖 Demon 的 UI。
 * 所有 GL 相关调用（load / draw / release / 析构链路）都要求外部先 makeCurrent()。
 *
 * 该模型没有 Motions / Expressions / LipSync 配置，所以：
 *  - 表情：自己解析 EXP/*.exp3.json，每帧把参数“按住”写回；
 *  - 口型：直接写 ParamMouthOpenY。
 */
class NativeLive2DModel : public Csm::CubismUserModel {
public:
    NativeLive2DModel();
    ~NativeLive2DModel() override;

    /// 加载 model3.json 及其 moc3 / 纹理 / physics / EXP 表情。需要当前 GL 上下文。
    bool load(const QString& model3Path);

    /// 释放 GL 资源（渲染器 + 纹理），需要当前 GL 上下文。
    void release();

    /// 每帧推进（物理 + 参数 + 顶点更新）。
    void update(float dt);

    /// 绘制到当前 FBO。fbWidth/fbHeight 必须是物理像素。
    void draw(int fbWidth, int fbHeight);

    /// 支持 "EXP/04 脸红"、"脸红"、"04 脸红" 或完整 .exp3.json 路径。
    bool setExpression(const QString& expFileBaseNameOrPath);
    void clearExpression();
    QStringList expressionNames() const;
    QString currentExpression() const;


    /// 保留触发：可同时叠加多个，切别的表情不会清掉（水印消除也是这一层）
    bool togglePersistentExpression(const QString& name);
    void clearPersistentExpressions();
    QStringList persistentExpressions() const;

    /// 一次性触发：新的会顶掉上一个
    void setOneShotExpression(const QString& name);
    void clearOneShotExpression();

    /// 动作：nod（点头）/ shake（摇头）/ tail（摇尾巴）/ bow（鞠躬）
    void playAction(const QString& name);
    QString currentAction() const { return m_actionName; }

    /// 常驻叠加的表情（默认「13 水印消除」）。它一直生效，切其它表情不会清掉它。
    void setBaselineExpressions(const QStringList& names);
    QStringList baselineExpressions() const { return m_baselineExpressionNames; }

    /// 口型 0..1（直接写 ParamMouthOpenY）。
    void setMouth(double value);
    double mouth() const { return m_mouth; }

    /// 全身 / 半身取景。
    void setScaleMode(bool half);
    bool isHalfBody() const { return m_halfBody; }

    QSize canvasSize() const;
    QRectF modelBounds() const { return m_bounds; }

    /// 最近 1 秒的实际 update 帧率。
    double fps() const { return m_fps; }

    bool isLoaded() const { return m_loaded; }
    QString lastError() const { return m_lastError; }

private:
    struct ExpressionParam {
        int index = -1;
        float value = 0.0f;
        int blend = 0; // 0=Add, 1=Overwrite, 2=Multiply
    };

    struct Expression {
        QString key;
        QVector<ExpressionParam> params;
    };

    bool loadModelSetting(const QString& model3Path);
    bool loadTextures();
    void loadPhysicsFile();
    void scanExpressions();
    Expression parseExpressionFile(const QString& path) const;
    int resolveExpression(const QString& name);
    int findParameterIndex(const QString& id) const;
    void applyParameters();
    void applyIdleMotion(Csm::CubismModel* model);
    void computeModelBounds();
    void buildMvp(int fbWidth, int fbHeight, Csm::CubismMatrix44* out) const;

    QString m_modelDir;
    std::unique_ptr<Csm::CubismModelSettingJson> m_setting;
    QVector<unsigned int> m_textures;

    QVector<Expression> m_expressions;
    QVector<int> m_expressionParamIndices;
    QHash<int, float> m_expressionResetValues;

    QVector<int> m_persistentIndices;      // 保留触发（可多个）
    int m_oneShotIndex = -1;               // 一次性触发
    QString m_actionName;
    QElapsedTimer m_actionClock;
    float m_actionDuration = 1.2f;

    // 常驻基线表情（这个模型允许多个 exp3 叠加，比如水印消除 + 情绪表情）
    QStringList m_baselineExpressionNames;
    QVector<int> m_baselineIndices;

    // 待机动作（模型自带没有 Motions/眨眼，这里自己驱动）
    QElapsedTimer m_idleClock;
    int m_angleX = -1;
    int m_angleY = -1;
    int m_angleZ = -1;
    int m_bodyAngleX = -1;
    int m_breath = -1;
    int m_eyeLeftOpen = -1;
    int m_eyeRightOpen = -1;
    int m_mouthIndex = -1;
    double m_mouth = 0.0;

    QRectF m_bounds;
    double m_canvasWidth = 0.0;
    double m_canvasHeight = 0.0;
    bool m_halfBody = false;
    bool m_loaded = false;

    QElapsedTimer m_fpsTimer;
    int m_fpsFrames = 0;
    double m_fps = 0.0;

    QString m_lastError;
    QString m_pendingExpression;
};
