#pragma once

#include <QByteArray>
#include <QVector>

/**
 * 从 WAV 计算口型包络（0..1），用于驱动 Live2D 的 MouthOpen。
 * 只处理 PCM16（单/双声道），其他格式返回空。
 */
class LipSync {
public:
    /** 每 1/fps 秒一个采样点 */
    static QVector<float> envelope(const QByteArray& wav, int fps = 30);
};
