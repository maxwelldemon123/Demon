#include "VtsClient.h"

#include "../util/Log.h"

#include <QFile>
#include <QStringList>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QUrl>

namespace {
constexpr int kReconnectMs = 5000;
}

VtsClient::VtsClient(QObject* parent)
    : QObject(parent)
{
    connect(&m_socket, &QWebSocket::connected, this, &VtsClient::onConnected);
    connect(&m_socket, &QWebSocket::textMessageReceived, this, &VtsClient::onTextMessage);
    connect(&m_socket, &QWebSocket::disconnected, this, &VtsClient::onDisconnected);
    connect(&m_socket, &QWebSocket::errorOccurred, this, [this](QAbstractSocket::SocketError) {
        m_lastError = m_socket.errorString();
        setState(State::Error, m_lastError);
    });

    m_reconnectTimer.setInterval(kReconnectMs);
    connect(&m_reconnectTimer, &QTimer::timeout, this, [this]() {
        if (m_shouldReconnect && m_state != State::Ready) {
            connectToServer();
        }
    });
}

QString VtsClient::stateName(State state)
{
    switch (state) {
    case State::Disconnected: return QStringLiteral("disconnected");
    case State::Connecting: return QStringLiteral("connecting");
    case State::WaitingForToken: return QStringLiteral("waiting-for-token");
    case State::Authenticating: return QStringLiteral("authenticating");
    case State::Ready: return QStringLiteral("ready");
    case State::Error: return QStringLiteral("error");
    }
    return QStringLiteral("unknown");
}

void VtsClient::setEndpoint(const QString& host, quint16 port)
{
    m_host = host;
    m_port = port;
}

void VtsClient::setTokenFile(const QString& path)
{
    m_tokenFile = path;
}

QString VtsClient::tokenFilePath() const
{
    return m_tokenFile;
}

bool VtsClient::loadToken(QString* token) const
{
    if (m_tokenFile.isEmpty()) {
        return false;
    }
    QFile file(m_tokenFile);
    if (!file.open(QIODevice::ReadOnly)) {
        return false;
    }
    const QJsonObject obj = QJsonDocument::fromJson(file.readAll()).object();
    const QString value = obj.value(QStringLiteral("token")).toString();
    if (value.isEmpty()) {
        return false;
    }
    if (token) {
        *token = value;
    }
    return true;
}

void VtsClient::saveToken(const QString& token) const
{
    if (m_tokenFile.isEmpty()) {
        return;
    }
    QJsonObject obj;
    obj.insert(QStringLiteral("token"), token);
    obj.insert(QStringLiteral("pluginName"), QStringLiteral("Demon"));
    QFile file(m_tokenFile);
    if (file.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        file.write(QJsonDocument(obj).toJson(QJsonDocument::Indented));
    }
}

void VtsClient::connectToServer()
{
    m_shouldReconnect = true;
    if (m_state == State::Connecting || m_state == State::Ready) {
        return;
    }
    setState(State::Connecting, QStringLiteral("%1:%2").arg(m_host).arg(m_port));
    const QUrl url(QStringLiteral("ws://%1:%2").arg(m_host).arg(m_port));
    m_socket.open(url);
}

void VtsClient::disconnectFromServer()
{
    m_shouldReconnect = false;
    m_reconnectTimer.stop();
    m_socket.close();
    setState(State::Disconnected);
}

void VtsClient::setState(State state, const QString& detail)
{
    if (m_state == state && detail.isEmpty()) {
        return;
    }
    m_state = state;
    emit stateChanged(state, detail);
}

void VtsClient::onConnected()
{
    m_reconnectTimer.stop();
    QString token;
    const bool hasToken = loadToken(&token);
    m_token = token;

    QJsonObject data;
    data.insert(QStringLiteral("pluginName"), QStringLiteral("Demon"));
    data.insert(QStringLiteral("pluginDeveloper"), QStringLiteral("dsh"));
    if (hasToken) {
        data.insert(QStringLiteral("authenticationToken"), token);
        sendRequest(QStringLiteral("AuthenticationRequest"), data);
        setState(State::Authenticating);
    } else {
        // 没有 token：请求一个新的，VTS 会弹窗让用户点「允许」
        sendRequest(QStringLiteral("AuthenticationTokenRequest"), data);
        setState(State::WaitingForToken, QStringLiteral("请在 VTube Studio 里点「允许」"));
    }
}

void VtsClient::sendRequest(const QString& messageType, const QJsonObject& data)
{
    QJsonObject root;
    root.insert(QStringLiteral("apiName"), QStringLiteral("VTubeStudioPublicAPI"));
    root.insert(QStringLiteral("apiVersion"), QStringLiteral("1.0"));
    root.insert(QStringLiteral("requestID"), QStringLiteral("demon-%1").arg(++m_requestSeq));
    root.insert(QStringLiteral("messageType"), messageType);
    root.insert(QStringLiteral("data"), data);
    const QByteArray payload = QJsonDocument(root).toJson(QJsonDocument::Compact);
    Log::info(QStringLiteral("VTS 发送 %1：%2").arg(messageType, QString::fromUtf8(payload).left(160)));
    m_socket.sendTextMessage(QString::fromUtf8(payload));
}

void VtsClient::onTextMessage(const QString& message)
{
    const QJsonObject root = QJsonDocument::fromJson(message.toUtf8()).object();
    const QString type = root.value(QStringLiteral("messageType")).toString();
    emit rawMessage(type, root);

    if (type == QStringLiteral("ModelLoadedEvent")) {
        const QJsonObject data = root.value(QStringLiteral("data")).toObject();
        const bool loaded = data.value(QStringLiteral("modelLoaded")).toBool(false);
        const QString name = data.value(QStringLiteral("modelName")).toString();
        if (loaded && !name.isEmpty()) {
            m_modelName = name;
            Log::info(QStringLiteral("VTS 模型切换：%1").arg(name));
            emit stateChanged(m_state, QStringLiteral("model:%1").arg(name));
            requestExpressionState();
        }
        return;
    }
    if (type == QStringLiteral("CurrentModelResponse")) {
        const QJsonObject data = root.value(QStringLiteral("data")).toObject();
        m_modelId = data.value(QStringLiteral("modelID")).toString();
        const QString name = data.value(QStringLiteral("modelName")).toString();
        if (!name.isEmpty() && name != m_modelName) {
            m_modelName = name;
            Log::info(QStringLiteral("VTS 当前模型：%1").arg(m_modelName));
            emit stateChanged(m_state, QStringLiteral("model:%1").arg(m_modelName));
        }
        return;
    }
    if (type == QStringLiteral("ExpressionStateResponse")) {
        const QJsonArray list = root.value(QStringLiteral("data")).toObject()
                                    .value(QStringLiteral("expressions")).toArray();
        m_expressionNames.clear();
        m_expressionFiles.clear();
        for (const QJsonValue& v : list) {
            const QJsonObject o = v.toObject();
            m_expressionNames.append(o.value(QStringLiteral("name")).toString());
            m_expressionFiles.append(o.value(QStringLiteral("file")).toString());
        }
        Log::info(QStringLiteral("VTS 表情列表：%1 个").arg(m_expressionNames.size()));
        return;
    }
    if (type == QStringLiteral("AuthenticationTokenResponse")) {
        handleTokenResponse(root);
    } else if (type == QStringLiteral("AuthenticationResponse")) {
        handleAuthenticationResponse(root);
    } else {
        handleGenericResponse(root);
    }
}

void VtsClient::handleTokenResponse(const QJsonObject& root)
{
    const QString token = root.value(QStringLiteral("data")).toObject()
                              .value(QStringLiteral("authenticationToken")).toString();
    if (token.isEmpty()) {
        m_lastError = QStringLiteral("VTS 没有返回 token（可能被拒绝）");
        setState(State::Error, m_lastError);
        return;
    }
    m_token = token;
    saveToken(token);
    Log::info(QStringLiteral("VTS token 已保存"));

    QJsonObject data;
    data.insert(QStringLiteral("pluginName"), QStringLiteral("Demon"));
    data.insert(QStringLiteral("pluginDeveloper"), QStringLiteral("dsh"));
    data.insert(QStringLiteral("authenticationToken"), token);
    sendRequest(QStringLiteral("AuthenticationRequest"), data);
    setState(State::Authenticating);
}

void VtsClient::handleAuthenticationResponse(const QJsonObject& root)
{
    const QJsonObject data = root.value(QStringLiteral("data")).toObject();
    const bool ok = data.value(QStringLiteral("authenticated")).toBool(false);
    if (ok) {
        Log::info(QStringLiteral("VTS 认证成功"));
        setState(State::Ready);
        QTimer::singleShot(600, this, [this]() { requestCurrentModel(); });

    } else {
        m_lastError = data.value(QStringLiteral("reason")).toString(QStringLiteral("认证失败"));
        Log::warn(QStringLiteral("VTS 认证失败：%1").arg(m_lastError));
        // token 失效：删掉重来
        QFile::remove(m_tokenFile);
        m_token.clear();
        setState(State::Error, m_lastError);
    }
}

void VtsClient::handleGenericResponse(const QJsonObject& root)
{
    const QJsonObject data = root.value(QStringLiteral("data")).toObject();
    if (data.value(QStringLiteral("errorID")).toInt(0) != 0) {
        Log::warn(QStringLiteral("VTS 返回错误：%1").arg(data.value(QStringLiteral("message")).toString()));
    }
}

void VtsClient::onDisconnected()
{
    Log::warn(QStringLiteral("VTS 连接断开：code=%1 reason=%2").arg(m_socket.closeCode()).arg(m_socket.closeReason()));
    if (m_state != State::Error) {
        setState(State::Disconnected);
    }
    if (m_shouldReconnect) {
        if (++m_reconnectAttempts > 12) {
            m_shouldReconnect = false;
            m_lastError = QStringLiteral("VTS 重连失败，请点「重新连接」");
            setState(State::Error, m_lastError);
        } else {
            m_reconnectTimer.start();
        }
    }
}

void VtsClient::injectParameter(const QString& id, double value)
{
    if (m_state != State::Ready) {
        return;
    }
    QJsonObject param;
    param.insert(QStringLiteral("id"), id);
    param.insert(QStringLiteral("value"), value);

    QJsonArray values;
    values.append(param);

    QJsonObject data;
    data.insert(QStringLiteral("faceFound"), false);
    data.insert(QStringLiteral("mode"), QStringLiteral("set"));
    data.insert(QStringLiteral("parameterValues"), values);
    sendRequest(QStringLiteral("InjectParameterDataRequest"), data);
}

void VtsClient::triggerHotkey(const QString& hotkeyId)
{
    if (m_state != State::Ready) {
        return;
    }
    QJsonObject data;
    data.insert(QStringLiteral("hotkeyID"), hotkeyId);
    sendRequest(QStringLiteral("HotkeyTriggerRequest"), data);
}


void VtsClient::requestCurrentModel()
{
    if (m_state != State::Ready) {
        return;
    }
    sendRequest(QStringLiteral("CurrentModelRequest"), QJsonObject());
}

void VtsClient::requestExpressionState()
{
    if (m_state != State::Ready) {
        return;
    }
    QJsonObject data;
    data.insert(QStringLiteral("details"), false);
    sendRequest(QStringLiteral("ExpressionStateRequest"), data);
}

void VtsClient::setExpression(const QString& file, bool active)
{
    if (m_state != State::Ready || file.isEmpty()) {
        return;
    }
    QJsonObject data;
    data.insert(QStringLiteral("expressionFile"), file);
    data.insert(QStringLiteral("active"), active);
    sendRequest(QStringLiteral("ExpressionActivationRequest"), data);
}


void VtsClient::sendRaw(const QString& messageType, const QJsonObject& data)
{
    if (m_state != State::Ready) {
        return;
    }
    sendRequest(messageType, data);
}
