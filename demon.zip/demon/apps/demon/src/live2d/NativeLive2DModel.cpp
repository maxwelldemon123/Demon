#include "NativeLive2DModel.h"

#include <QByteArray>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QOpenGLContext>

#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstring>

#include "Physics/CubismPhysics.hpp"
#include "Rendering/OpenGL/CubismRenderer_OpenGLES2.hpp"
#include "cubism/CubismSupport.h"
#include "util/Log.h"

namespace {

const char* kMouthParameterId = "ParamMouthOpenY";

QByteArray readAllBytes(const QString& path)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        return QByteArray();
    }
    return file.readAll();
}

float clampFloat(float value, float low, float high)
{
    return value < low ? low : (value > high ? high : value);
}

} // namespace

NativeLive2DModel::NativeLive2DModel()
{
    // 这个模型的水印是模型自带的，靠 EXP/13 水印消除 关掉；默认常驻，其它表情叠加在它上面。
    m_baselineExpressionNames << QStringLiteral("EXP/13 水印消除");
}

NativeLive2DModel::~NativeLive2DModel()
{
    // GL 资源必须由 Live2DWindow 在 makeCurrent() 的情况下调用 release() 释放。
    if (!m_textures.isEmpty()) {
        Log::warn(QStringLiteral("[live2d] NativeLive2DModel 析构时仍有 %1 个纹理未释放")
                      .arg(m_textures.size()));
    }
}

bool NativeLive2DModel::load(const QString& model3Path)
{
    release();

    m_lastError.clear();

    if (GetModel() != nullptr) {
        m_lastError = QStringLiteral("该实例已经加载过模型，不支持重复 load()");
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }

    if (!CubismSupport::initialize()) {
        m_lastError = QStringLiteral("CubismFramework 初始化失败");
        return false;
    }

    const QFileInfo modelInfo(model3Path);
    if (!modelInfo.exists()) {
        m_lastError = QStringLiteral("model3.json 不存在: %1").arg(model3Path);
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }

    m_modelDir = modelInfo.absolutePath();
    CubismSupport::setAssetRoot(m_modelDir);

    if (!loadModelSetting(model3Path)) {
        return false;
    }

    // ---- moc3 ----
    const QString mocPath =
        QDir(m_modelDir).absoluteFilePath(QString::fromUtf8(m_setting->GetModelFileName()));
    const QByteArray mocBytes = readAllBytes(mocPath);
    if (mocBytes.isEmpty()) {
        m_lastError = QStringLiteral("moc3 读取失败: %1").arg(mocPath);
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }
    LoadModel(reinterpret_cast<const Csm::csmByte*>(mocBytes.constData()),
              static_cast<Csm::csmSizeInt>(mocBytes.size()), false);
    if (GetModel() == nullptr) {
        m_lastError = QStringLiteral("CubismModel 创建失败（moc3 无效）: %1").arg(mocPath);
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }

    m_canvasWidth = GetModel()->GetCanvasWidth();
    m_canvasHeight = GetModel()->GetCanvasHeight();

    // ---- renderer ----
    CreateRenderer(1);
    auto* renderer = GetRenderer<Csm::Rendering::CubismRenderer_OpenGLES2>();
    if (renderer == nullptr) {
        m_lastError = QStringLiteral("CubismRenderer_OpenGLES2 创建失败");
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }
    // 模型是预乘 alpha 的渲染管线（shader 输出预乘，GL_ONE / GL_ONE_MINUS_SRC_ALPHA）。
    renderer->IsPremultipliedAlpha(false);

    const float maskSize = static_cast<float>(std::min(2048.0, std::max(256.0, m_canvasWidth)));
    renderer->SetClippingMaskBufferSize(maskSize, maskSize);

    // ---- textures ----
    if (!loadTextures()) {
        return false;
    }

    // ---- physics（能上就上，失败不致命）----
    loadPhysicsFile();

    // ---- expressions（model3.json 里没有，自己扫 EXP 目录）----
    scanExpressions();
    // 基线表情解析（水印消除等）
    m_baselineIndices.clear();
    for (const QString& name : m_baselineExpressionNames) {
        const int index = resolveExpression(name);
        if (index < 0) {
            Log::warn(QStringLiteral("[live2d] 基线表情不存在: %1").arg(name));
            continue;
        }
        m_baselineIndices.append(index);
        Log::info(QStringLiteral("[live2d] 基线表情常驻: %1").arg(m_expressions[index].key));
    }

    m_angleX = findParameterIndex(QStringLiteral("ParamAngleX"));
    m_angleY = findParameterIndex(QStringLiteral("ParamAngleY"));
    m_angleZ = findParameterIndex(QStringLiteral("ParamAngleZ"));
    m_bodyAngleX = findParameterIndex(QStringLiteral("ParamBodyAngleX"));
    m_breath = findParameterIndex(QStringLiteral("ParamBreath"));
    m_eyeLeftOpen = findParameterIndex(QStringLiteral("ParamEyeLOpen"));
    m_eyeRightOpen = findParameterIndex(QStringLiteral("ParamEyeROpen"));
    m_idleClock.start();
    m_mouthIndex = findParameterIndex(QString::fromLatin1(kMouthParameterId));
    if (m_mouthIndex < 0) {
        Log::warn(QStringLiteral("[live2d] 模型没有 %1 参数，口型不可用")
                      .arg(QString::fromLatin1(kMouthParameterId)));
    }

    GetModel()->Update();
    // 记录一次「基线参数」：之后每帧 LoadParameters() 都回到这里
    GetModel()->SaveParameters();
    computeModelBounds();

    m_loaded = true;
    m_fpsFrames = 0;
    m_fpsTimer.start();

    Log::info(QStringLiteral("[live2d] 模型加载完成: %1 | 画布 %2x%3 | drawable=%4 | 纹理=%5 | 表情=%6 | 口型参数=%7")
                  .arg(QFileInfo(model3Path).fileName())
                  .arg(m_canvasWidth, 0, 'f', 1)
                  .arg(m_canvasHeight, 0, 'f', 1)
                  .arg(GetModel()->GetDrawableCount())
                  .arg(m_textures.size())
                  .arg(m_expressions.size())
                  .arg(m_mouthIndex));

    if (!m_pendingExpression.isEmpty()) {
        const QString pending = m_pendingExpression;
        m_pendingExpression.clear();
        setExpression(pending);
    }

    return true;
}

bool NativeLive2DModel::loadModelSetting(const QString& model3Path)
{
    const QByteArray bytes = readAllBytes(model3Path);
    if (bytes.isEmpty()) {
        m_lastError = QStringLiteral("model3.json 读取失败: %1").arg(model3Path);
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        return false;
    }

    m_setting.reset(new Csm::CubismModelSettingJson(
        reinterpret_cast<const Csm::csmByte*>(bytes.constData()),
        static_cast<Csm::csmSizeInt>(bytes.size())));

    if (!m_setting->IsValid()) {
        m_lastError = QStringLiteral("model3.json 解析失败: %1").arg(model3Path);
        Log::error(QStringLiteral("[live2d] %1").arg(m_lastError));
        m_setting.reset();
        return false;
    }
    return true;
}

bool NativeLive2DModel::loadTextures()
{
    auto* renderer = GetRenderer<Csm::Rendering::CubismRenderer_OpenGLES2>();
    if (renderer == nullptr) {
        return false;
    }

    const int textureCount = m_setting->GetTextureCount();
    Log::info(QStringLiteral("[live2d] model3 纹理数量: %1").arg(textureCount));

    for (int i = 0; i < textureCount; ++i) {
        const QString relative = QString::fromUtf8(m_setting->GetTextureFileName(i));
        const QString path = QDir(m_modelDir).absoluteFilePath(relative);
        int width = 0;
        int height = 0;
        const unsigned int textureId = CubismSupport::createTextureFromImage(path, &width, &height);
        if (textureId == 0) {
            m_lastError = QStringLiteral("纹理创建失败: %1").arg(path);
            return false;
        }
        m_textures.append(textureId);
        renderer->BindTexture(static_cast<Csm::csmUint32>(i), textureId);

        if (width > 16384 || height > 16384) {
            Log::warn(QStringLiteral("[live2d] 纹理尺寸异常: %1x%2").arg(width).arg(height));
        }
    }
    return true;
}

void NativeLive2DModel::loadPhysicsFile()
{
    const Csm::csmChar* physicsName = m_setting->GetPhysicsFileName();
    if (physicsName == nullptr || physicsName[0] == '\0') {
        Log::info(QStringLiteral("[live2d] model3 未配置 physics"));
        return;
    }

    const QString path = QDir(m_modelDir).absoluteFilePath(QString::fromUtf8(physicsName));
    const QByteArray bytes = readAllBytes(path);
    if (bytes.isEmpty()) {
        Log::warn(QStringLiteral("[live2d] physics3.json 读取失败: %1").arg(path));
        return;
    }

    LoadPhysics(reinterpret_cast<const Csm::csmByte*>(bytes.constData()),
                static_cast<Csm::csmSizeInt>(bytes.size()));
    Log::info(QStringLiteral("[live2d] physics 已加载: %1 (%2)")
                  .arg(QString::fromUtf8(physicsName))
                  .arg(_physics != nullptr ? QStringLiteral("ok") : QStringLiteral("failed")));
}

void NativeLive2DModel::scanExpressions()
{
    m_expressions.clear();

    const QDir expDir(QDir(m_modelDir).absoluteFilePath(QStringLiteral("EXP")));
    if (!expDir.exists()) {
        Log::warn(QStringLiteral("[live2d] 没有 EXP 目录，表情不可用: %1").arg(expDir.absolutePath()));
        return;
    }

    const QStringList files =
        expDir.entryList(QStringList() << QStringLiteral("*.exp3.json"), QDir::Files, QDir::Name);
    for (const QString& file : files) {
        const Expression expression = parseExpressionFile(expDir.absoluteFilePath(file));
        if (expression.params.isEmpty()) {
            Log::warn(QStringLiteral("[live2d] 表情没有可用参数: %1").arg(file));
            continue;
        }
        m_expressions.append(expression);
    }

    // 所有表情写过的参数并集：每帧先复位，再按当前表情写回。
    m_expressionParamIndices.clear();
    m_expressionResetValues.clear();
    for (const Expression& expression : m_expressions) {
        for (const ExpressionParam& param : expression.params) {
            if (m_expressionResetValues.contains(param.index)) {
                continue;
            }
            // 复位必须回到「模型默认值」，不能写 0：
            // 嘴型/脸颊这类参数默认不是 0，清成 0 会把脸画坏（灰块、嘴型错乱）。
            const float base = GetModel()
                                   ? GetModel()->GetParameterDefaultValue(
                                         static_cast<Csm::csmUint32>(param.index))
                                   : 0.0f;
            m_expressionResetValues.insert(param.index, base);
            m_expressionParamIndices.append(param.index);
        }
    }

    Log::info(QStringLiteral("[live2d] 找到 %1 个表情，涉及 %2 个参数")
                  .arg(m_expressions.size())
                  .arg(m_expressionParamIndices.size()));
    for (const Expression& expression : m_expressions) {
        QStringList ids;
        for (const ExpressionParam& param : expression.params) {
            ids << QStringLiteral("%1(%2)").arg(param.index).arg(param.value);
        }
        Log::info(QStringLiteral("[live2d]   表情 [%1] -> %2")
                      .arg(expression.key, ids.join(QStringLiteral(", "))));
    }
}

NativeLive2DModel::Expression NativeLive2DModel::parseExpressionFile(const QString& path) const
{
    Expression expression;
    expression.key = QFileInfo(path).fileName();
    if (expression.key.endsWith(QStringLiteral(".exp3.json"), Qt::CaseInsensitive)) {
        expression.key.chop(static_cast<int>(QStringLiteral(".exp3.json").size()));
    }

    const QByteArray bytes = readAllBytes(path);
    if (bytes.isEmpty()) {
        Log::warn(QStringLiteral("[live2d] 表情文件读取失败: %1").arg(path));
        return expression;
    }

    QJsonParseError parseError{};
    const QJsonDocument document = QJsonDocument::fromJson(bytes, &parseError);
    if (document.isNull() || !document.isObject()) {
        Log::warn(QStringLiteral("[live2d] 表情 JSON 解析失败(%1): %2")
                      .arg(parseError.errorString(), path));
        return expression;
    }

    const QJsonArray parameters = document.object().value(QStringLiteral("Parameters")).toArray();
    for (const QJsonValue& value : parameters) {
        const QJsonObject object = value.toObject();
        const QString id = object.value(QStringLiteral("Id")).toString();
        if (id.isEmpty()) {
            continue;
        }

        const int index = findParameterIndex(id);
        if (index < 0) {
            Log::warn(QStringLiteral("[live2d] 表情参数不存在: %1 (%2)").arg(id, expression.key));
            continue;
        }

        ExpressionParam param;
        param.index = index;
        param.value = static_cast<float>(object.value(QStringLiteral("Value")).toDouble(0.0));

        const QString blend = object.value(QStringLiteral("Blend")).toString();
        if (blend.compare(QStringLiteral("Multiply"), Qt::CaseInsensitive) == 0) {
            param.blend = 2;
        } else if (blend.compare(QStringLiteral("Overwrite"), Qt::CaseInsensitive) == 0
                   || blend.compare(QStringLiteral("Absolute"), Qt::CaseInsensitive) == 0) {
            param.blend = 1;
        } else {
            param.blend = 0;
        }

        expression.params.append(param);
    }
    return expression;
}

int NativeLive2DModel::findParameterIndex(const QString& id) const
{
    if (GetModel() == nullptr) {
        return -1;
    }

    const QByteArray utf8 = id.toUtf8();
    const Csm::csmInt32 count = GetModel()->GetParameterCount();
    for (Csm::csmInt32 i = 0; i < count; ++i) {
        const Csm::csmString& parameterId = GetModel()->GetParameterId(i)->GetString();
        if (std::strcmp(parameterId.GetRawString(), utf8.constData()) == 0) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

int NativeLive2DModel::resolveExpression(const QString& name)
{
    QString normalized = name;
    normalized.replace(QLatin1Char('\\'), QLatin1Char('/'));
    if (normalized.endsWith(QStringLiteral(".exp3.json"), Qt::CaseInsensitive)) {
        normalized.chop(static_cast<int>(QStringLiteral(".exp3.json").size()));
    }
    const int slash = normalized.lastIndexOf(QLatin1Char('/'));
    if (slash >= 0) {
        normalized = normalized.mid(slash + 1);
    }
    normalized = normalized.trimmed();

    if (!normalized.isEmpty()) {
        int fuzzy = -1;
        for (int i = 0; i < m_expressions.size(); ++i) {
            const QString& key = m_expressions[i].key;
            if (key.compare(normalized, Qt::CaseInsensitive) == 0) {
                return i;
            }
            if (fuzzy < 0 && key.endsWith(normalized, Qt::CaseInsensitive)) {
                fuzzy = i;
            }
        }
        if (fuzzy >= 0) {
            return fuzzy;
        }
        for (int i = 0; i < m_expressions.size(); ++i) {
            if (m_expressions[i].key.contains(normalized, Qt::CaseInsensitive)) {
                return i;
            }
        }
    }

    // 也允许直接传 .exp3.json 的绝对/相对路径。
    QString candidate = name;
    if (!QFileInfo::exists(candidate)) {
        candidate = QDir(m_modelDir).absoluteFilePath(name);
    }
    if (QFileInfo::exists(candidate)) {
        Expression expression = parseExpressionFile(candidate);
        if (!expression.params.isEmpty()) {
            m_expressions.append(expression);
            for (const ExpressionParam& param : expression.params) {
                if (m_expressionResetValues.contains(param.index)) {
                    continue;
                }
                const float base = (param.blend == 2 && GetModel())
                                       ? GetModel()->GetParameterDefaultValue(
                                             static_cast<Csm::csmUint32>(param.index))
                                       : 0.0f;
                m_expressionResetValues.insert(param.index, base);
                m_expressionParamIndices.append(param.index);
            }
            return m_expressions.size() - 1;
        }
    }

    return -1;
}

bool NativeLive2DModel::setExpression(const QString& expFileBaseNameOrPath)
{
    setOneShotExpression(expFileBaseNameOrPath);
    return m_oneShotIndex >= 0;
}

void NativeLive2DModel::clearExpression()
{
    clearOneShotExpression();
}

bool NativeLive2DModel::togglePersistentExpression(const QString& expFileBaseNameOrPath)
{
    if (!m_loaded) {
        return false;
    }
    const int index = resolveExpression(expFileBaseNameOrPath);
    if (index < 0) {
        Log::warn(QStringLiteral("[live2d] 找不到表情: %1").arg(expFileBaseNameOrPath));
        return false;
    }
    if (m_persistentIndices.removeAll(index) > 0) {
        Log::info(QStringLiteral("[live2d] 保留表情 -%1（剩 %2 个）")
                      .arg(m_expressions[index].key)
                      .arg(m_persistentIndices.size()));
        return false;
    }
    m_persistentIndices.append(index);
    Log::info(QStringLiteral("[live2d] 保留表情 +%1（共 %2 个）")
                  .arg(m_expressions[index].key)
                  .arg(m_persistentIndices.size()));
    return true;
}

void NativeLive2DModel::clearPersistentExpressions()
{
    m_persistentIndices.clear();
    Log::info(QStringLiteral("[live2d] 保留表情已全部清除"));
}

QStringList NativeLive2DModel::persistentExpressions() const
{
    QStringList names;
    for (int index : m_persistentIndices) {
        if (index >= 0 && index < m_expressions.size()) {
            names.append(m_expressions[index].key);
        }
    }
    return names;
}

void NativeLive2DModel::setOneShotExpression(const QString& expFileBaseNameOrPath)
{
    if (!m_loaded) {
        m_pendingExpression = expFileBaseNameOrPath;
        return;
    }
    if (expFileBaseNameOrPath.isEmpty()) {
        m_oneShotIndex = -1;
        return;
    }
    const int index = resolveExpression(expFileBaseNameOrPath);
    if (index < 0) {
        Log::warn(QStringLiteral("[live2d] 找不到表情: %1").arg(expFileBaseNameOrPath));
        return;
    }
    m_oneShotIndex = index;
    Log::info(QStringLiteral("[live2d] 一次性表情 -> %1").arg(m_expressions[index].key));
}

void NativeLive2DModel::clearOneShotExpression()
{
    m_oneShotIndex = -1;
}
void NativeLive2DModel::playAction(const QString& name)
{
    static const QStringList kActions = {
        QStringLiteral("nod"), QStringLiteral("shake"),
        QStringLiteral("tail"), QStringLiteral("bow"),
    };
    if (!kActions.contains(name)) {
        Log::warn(QStringLiteral("[live2d] 未知动作: %1").arg(name));
        return;
    }
    m_actionName = name;
    m_actionClock.restart();
    Log::info(QStringLiteral("[live2d] 动作 -> %1").arg(name));
}
QString NativeLive2DModel::currentExpression() const
{
    if (m_oneShotIndex < 0 || m_oneShotIndex >= m_expressions.size()) {
        return QString();
    }
    return m_expressions[m_oneShotIndex].key;
}

void NativeLive2DModel::setMouth(double value)
{
    m_mouth = clampFloat(static_cast<float>(value), 0.0f, 1.0f);
}

void NativeLive2DModel::setScaleMode(bool half)
{
    m_halfBody = half;
}


// 待机动作：模型自带没有 Motions / 眨眼（model3.json 的 Groups 都是空的），
// 所以要自己驱动一点点呼吸、摆动和眨眼，否则物理收敛后画面完全静止。
void NativeLive2DModel::applyIdleMotion(Csm::CubismModel* model)
{
    if (model == nullptr || !m_idleClock.isValid()) {
        return;
    }
    const float t = static_cast<float>(m_idleClock.elapsed()) / 1000.0f;

    const auto set = [model](int index, float value) {
        if (index >= 0) {
            model->SetParameterValue(index, value);
        }
    };
    const auto get = [model](int index) -> float {
        return index >= 0 ? model->GetParameterValue(index) : 0.0f;
    };

    // 呼吸 + 轻微摆动
    set(m_breath, 0.5f + 0.5f * std::sin(t * 1.1f));
    set(m_angleX, 8.0f * std::sin(t * 0.45f));
    set(m_angleY, 5.0f * std::sin(t * 0.31f + 1.2f));
    set(m_angleZ, 4.0f * std::sin(t * 0.27f + 0.6f));
    set(m_bodyAngleX, 5.0f * std::sin(t * 0.39f + 2.0f));

    // 动作层：用参数动画模拟点头/摇头/摇尾巴/鞠躬（模型没有 Motions 文件，只能这么做）
    if (!m_actionName.isEmpty() && m_actionClock.isValid()) {
        const float actionT = static_cast<float>(m_actionClock.elapsed()) / 1000.0f;
        const float progress = qBound(0.0f, actionT / m_actionDuration, 1.0f);
        const float envelope = std::sin(progress * 3.14159265f);   // 起-落包络
        if (m_actionName == QStringLiteral("nod")) {
            set(m_angleY, get(m_angleY) - 14.0f * envelope * std::sin(actionT * 18.0f));
        } else if (m_actionName == QStringLiteral("shake")) {
            set(m_angleX, get(m_angleX) + 16.0f * envelope * std::sin(actionT * 20.0f));
        } else if (m_actionName == QStringLiteral("tail")) {
            const float swing = envelope * std::sin(actionT * 12.0f);
            set(m_bodyAngleX, get(m_bodyAngleX) + 9.0f * swing);
            set(m_angleZ, get(m_angleZ) + 6.0f * swing);
        } else if (m_actionName == QStringLiteral("bow")) {
            set(m_angleY, get(m_angleY) - 22.0f * envelope);
        }
        if (progress >= 1.0f) {
            m_actionName.clear();
        }
    }

    // 每 ~4 秒眨一次眼（0.12 秒闭合）
    const float phase = std::fmod(t, 4.0f) / 4.0f;
    float open = 1.0f;
    if (phase > 0.97f) {
        open = 0.0f;
    } else if (phase > 0.94f) {
        open = (0.97f - phase) / 0.03f;
    }
    set(m_eyeLeftOpen, open);
    set(m_eyeRightOpen, open);
}
void NativeLive2DModel::applyParameters()
{
    Csm::CubismModel* model = GetModel();
    if (model == nullptr) {
        return;
    }

    // 注：基线复位由 update() 里的 LoadParameters() 完成（Cubism 官方做法），
    // 这里只负责把「基线表情 + 当前表情 + 口型」叠加到当前参数上。

    // 基线表情（水印消除）每帧先叠上，永不撤销
    for (int baseline : m_baselineIndices) {
        if (baseline < 0 || baseline >= m_expressions.size()) {
            continue;
        }
        for (const ExpressionParam& param : m_expressions[baseline].params) {
            switch (param.blend) {
            case 2:
                model->MultiplyParameterValue(param.index, param.value);
                break;
            case 1:
                model->SetParameterValue(param.index, param.value);
                break;
            case 0:
            default:
                model->AddParameterValue(param.index, param.value);
                break;
            }
        }
    }

    // 保留触发：可叠加多个，互不清除
    for (int persistent : m_persistentIndices) {
        if (persistent < 0 || persistent >= m_expressions.size()) {
            continue;
        }
        for (const ExpressionParam& param : m_expressions[persistent].params) {
            switch (param.blend) {
            case 2: model->MultiplyParameterValue(param.index, param.value); break;
            case 1: model->SetParameterValue(param.index, param.value); break;
            case 0:
            default: model->AddParameterValue(param.index, param.value); break;
            }
        }
    }

    // 一次性触发：只保留最后一个
    const int active = m_oneShotIndex;
    if (active >= 0 && active < m_expressions.size()
        && !m_baselineIndices.contains(active)) {
        for (const ExpressionParam& param : m_expressions[active].params) {
            switch (param.blend) {
            case 2: // Multiply
                model->MultiplyParameterValue(param.index, param.value);
                break;
            case 1: // Overwrite
                model->SetParameterValue(param.index, param.value);
                break;
            case 0: // Add
            default:
                model->AddParameterValue(param.index, param.value);
                break;
            }
        }
    }

    if (m_mouthIndex >= 0) {
        model->SetParameterValue(m_mouthIndex, static_cast<Csm::csmFloat32>(m_mouth));
    }
}

void NativeLive2DModel::update(float dt)
{
    if (!m_loaded || GetModel() == nullptr) {
        return;
    }

    ++m_fpsFrames;
    const qint64 elapsed = m_fpsTimer.elapsed();
    if (elapsed >= 1000) {
        m_fps = m_fpsFrames * 1000.0 / static_cast<double>(elapsed);
        m_fpsFrames = 0;
        m_fpsTimer.restart();
    }

    if (dt <= 0.0f) {
        dt = 1.0f / 30.0f;
    }
    dt = clampFloat(dt, 0.001f, 0.1f);

    // 官方做法：每帧先恢复「基线参数」，再叠加表情/口型/物理。
    // 这样参数不会被逐帧累加，也不会把默认值非 0 的参数写坏。
    GetModel()->LoadParameters();

    applyIdleMotion(GetModel());
    applyParameters();

    if (_physics != nullptr) {
        _physics->Evaluate(GetModel(), dt);
    }

    GetModel()->Update();
}

void NativeLive2DModel::computeModelBounds()
{
    Csm::CubismModel* model = GetModel();
    if (model == nullptr) {
        return;
    }

    float minX = FLT_MAX;
    float minY = FLT_MAX;
    float maxX = -FLT_MAX;
    float maxY = -FLT_MAX;
    bool any = false;

    const Csm::csmInt32 drawableCount = model->GetDrawableCount();
    for (Csm::csmInt32 i = 0; i < drawableCount; ++i) {
        if (!model->GetDrawableDynamicFlagIsVisible(i)) {
            continue;
        }
        const Csm::csmInt32 vertexCount = model->GetDrawableVertexCount(i);
        const Csm::csmFloat32* vertices = model->GetDrawableVertices(i);
        if (vertices == nullptr) {
            continue;
        }
        for (Csm::csmInt32 j = 0; j < vertexCount; ++j) {
            const float x = vertices[j * 2];
            const float y = vertices[j * 2 + 1];
            minX = std::min(minX, x);
            maxX = std::max(maxX, x);
            minY = std::min(minY, y);
            maxY = std::max(maxY, y);
            any = true;
        }
    }

    if (!any) {
        // 没有可见 drawable 时退回画布矩形（画布坐标中心在原点）。
        const float halfW = static_cast<float>(m_canvasWidth) * 0.5f;
        const float halfH = static_cast<float>(m_canvasHeight) * 0.5f;
        m_bounds = QRectF(-halfW, -halfH, halfW * 2.0f, halfH * 2.0f);
        Log::warn(QStringLiteral("[live2d] 没有可见 drawable，使用画布矩形作为取景框"));
        return;
    }

    // 留 4% 边距，避免顶到窗口边缘。
    const float width = maxX - minX;
    const float height = maxY - minY;
    const float padding = std::max(width, height) * 0.04f;
    m_bounds = QRectF(minX - padding, minY - padding, width + padding * 2.0f,
                      height + padding * 2.0f);
    Log::info(QStringLiteral("[live2d] 模型取景框: x=[%1,%2] y=[%3,%4] (%5x%6)")
                  .arg(minX, 0, 'f', 1)
                  .arg(maxX, 0, 'f', 1)
                  .arg(minY, 0, 'f', 1)
                  .arg(maxY, 0, 'f', 1)
                  .arg(width, 0, 'f', 1)
                  .arg(height, 0, 'f', 1));
}

void NativeLive2DModel::buildMvp(int fbWidth, int fbHeight, Csm::CubismMatrix44* out) const
{
    if (out == nullptr) {
        return;
    }

    float left = static_cast<float>(m_bounds.left());
    float right = static_cast<float>(m_bounds.right());
    float bottom = static_cast<float>(m_bounds.top());    // QRectF::top 是较小的 y
    float top = static_cast<float>(m_bounds.bottom());    // QRectF::bottom 是较大的 y

    if (m_halfBody) {
        // 半身：取上半部分（模型坐标 y 向上，上边缘是较大的 y）。
        const float fullHeight = top - bottom;
        const float fullWidth = right - left;
        const float centerX = (left + right) * 0.5f;
        top = top - fullHeight * 0.02f;
        bottom = top - fullHeight * 0.58f;
        left = centerX - fullWidth * 0.40f;
        right = centerX + fullWidth * 0.40f;
    }

    const float viewWidth = static_cast<float>(std::max(1, fbWidth));
    const float viewHeight = static_cast<float>(std::max(1, fbHeight));
    const float sourceWidth = std::max(1.0f, right - left);
    const float sourceHeight = std::max(1.0f, top - bottom);

    // 等比缩放 + 底部对齐。
    const float pixelsPerUnit = std::min(viewWidth / sourceWidth, viewHeight / sourceHeight);
    const float scale = 2.0f * pixelsPerUnit / viewHeight;
    const float centerX = (left + right) * 0.5f;
    const float centerY = (top + bottom) * 0.5f;
    const float translateX = -scale * centerX;
    const float translateY = -scale * centerY + scale * sourceHeight * 0.5f - 1.0f;

    // 这个模型的 canvas 不是正方形（1.0 x 1.5），Cubism 渲染器内部按 canvas 归一化，
    // 外面再用同一个 scale 就会把 x 压掉 canvasW/canvasH ≈ 0.667。这里把 x 补偿回来。
    const float aspectFixX = (m_canvasWidth > 0.0f && m_canvasHeight > 0.0f)
                                 ? (m_canvasHeight / m_canvasWidth)
                                 : 1.0f;
    out->LoadIdentity();
    out->Scale(scale * aspectFixX, scale);
    out->Translate(translateX * aspectFixX, translateY);
}

void NativeLive2DModel::draw(int fbWidth, int fbHeight)
{
    if (!m_loaded) {
        return;
    }

    auto* renderer = GetRenderer<Csm::Rendering::CubismRenderer_OpenGLES2>();
    if (renderer == nullptr) {
        return;
    }

    Csm::CubismMatrix44 mvp;
    buildMvp(fbWidth, fbHeight, &mvp);
    renderer->SetMvpMatrix(&mvp);
    renderer->DrawModel();
}

QSize NativeLive2DModel::canvasSize() const
{
    return QSize(static_cast<int>(std::lround(m_canvasWidth)),
                 static_cast<int>(std::lround(m_canvasHeight)));
}

void NativeLive2DModel::release()
{
    if (GetRenderer<Csm::Rendering::CubismRenderer_OpenGLES2>() != nullptr) {
        DeleteRenderer();
    }

    for (unsigned int textureId : m_textures) {
        CubismSupport::deleteTexture(textureId);
    }
    m_textures.clear();

    m_setting.reset();
    m_loaded = false;
    m_bounds = QRectF();
    m_mouth = 0.0;
    m_mouthIndex = -1;
    m_fps = 0.0;
}
