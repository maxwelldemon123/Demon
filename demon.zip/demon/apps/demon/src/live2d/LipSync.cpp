#include "LipSync.h"

#include <QtEndian>

#include <algorithm>
#include <cmath>

QVector<float> LipSync::envelope(const QByteArray& wav, int fps)
{
    QVector<float> result;
    if (wav.size() < 44 || !wav.startsWith("RIFF") || fps <= 0) {
        return result;
    }

    int channels = 1;
    int bitsPerSample = 16;
    int sampleRate = 0;
    int dataOffset = -1;
    int dataSize = 0;

    int pos = 12;
    while (pos + 8 <= wav.size()) {
        const QByteArray id = wav.mid(pos, 4);
        const int size = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(wav.constData() + pos + 4));
        if (id == "fmt " && pos + 16 <= wav.size()) {
            channels = qFromLittleEndian<quint16>(reinterpret_cast<const uchar*>(wav.constData() + pos + 10));
            sampleRate = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(wav.constData() + pos + 12));
            bitsPerSample = qFromLittleEndian<quint16>(reinterpret_cast<const uchar*>(wav.constData() + pos + 22));
        } else if (id == "data") {
            dataOffset = pos + 8;
            dataSize = std::min<int>(size, static_cast<int>(wav.size() - dataOffset));
            break;
        }
        pos += 8 + size + (size & 1);
    }

    if (dataOffset < 0 || dataSize <= 0 || sampleRate <= 0) {
        return result;
    }
    // 只支持 16bit PCM；24/32bit 或压缩格式不处理
    if (bitsPerSample != 16) {
        return result;
    }

    const int bytesPerSample = 2 * channels;
    const int windowSamples = std::max(1, sampleRate / fps);
    const int sampleCount = dataSize / bytesPerSample;
    const uchar* base = reinterpret_cast<const uchar*>(wav.constData() + dataOffset);

    float peak = 1.0f;
    for (int i = 0; i < sampleCount; ++i) {
        const auto value = static_cast<qint16>(qFromLittleEndian<qint16>(base + i * bytesPerSample));
        peak = std::max(peak, std::abs(static_cast<float>(value)) / 32768.0f);
    }

    for (int start = 0; start < sampleCount; start += windowSamples) {
        const int end = std::min(sampleCount, start + windowSamples);
        double sum = 0.0;
        for (int i = start; i < end; ++i) {
            const auto value = static_cast<qint16>(qFromLittleEndian<qint16>(base + i * bytesPerSample));
            const double normalized = static_cast<double>(value) / 32768.0;
            sum += normalized * normalized;
        }
        const double rms = std::sqrt(sum / std::max(1, end - start));
        // 归一化并做一点增益，低音量也能张嘴
        float level = static_cast<float>(rms / peak);
        level = std::clamp(level * 1.8f, 0.0f, 1.0f);
        // 起音/收尾稍微削一下，避免抖动
        result.append(level);
    }

    return result;
}
