#pragma once

#include <QString>

#include "CubismFramework.hpp"

/**
 * Cubism Framework 的运行支撑层。
 *
 * 负责：
 *  - 内存分配器（ICubismAllocator）
 *  - 文件加载器（QFile，负责把框架内部的 "FrameworkShaders/xxx.vert"
 *    相对路径映射到 resources/live2d/shaders 的绝对路径）
 *  - 日志回调（转发到 Demon 的 Log，绝不走 stdout）
 *  - 框架 StartUp / Initialize / Dispose / CleanUp 生命周期
 *  - QImage -> OpenGL 纹理（预乘 alpha）
 *
 * 注意：所有涉及 GL 的函数都要求调用线程已经 makeCurrent()。
 */
namespace CubismSupport {

/// StartUp + Initialize，可重复调用（幂等）。
bool initialize();

/// Dispose + CleanUp，可重复调用（幂等）。调用前必须已释放全部模型，
/// 并且当前线程必须 makeCurrent()（Dispose 内部会 glDeleteProgram）。
void shutdown();

bool isInitialized();

/// 资源目录（可由 Live2DWindow 在 initializeGL 前覆盖；否则自动探测）。
void setShaderDir(const QString& dir);
QString shaderDir();

/// 允许把相对路径解析到模型目录（框架读 shader 之外的文件时才用到）。
void setAssetRoot(const QString& dir);

/// CubismFramework::Option 用的文件读写回调。
Csm::csmByte* loadFile(const std::string filePath, Csm::csmSizeInt* outSize);
void releaseBytes(Csm::csmByte* bytes);

/// 用 QImage 解码 PNG（预乘 RGBA8888）并上传为 GL 纹理。
/// 失败返回 0。成功时 outWidth/outHeight 写入像素尺寸。
unsigned int createTextureFromImage(const QString& imagePath, int* outWidth, int* outHeight);

void deleteTexture(unsigned int textureId);

} // namespace CubismSupport
