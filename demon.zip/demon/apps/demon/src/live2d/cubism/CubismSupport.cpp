#include "CubismSupport.h"

#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QImage>
#include <QImageReader>
#include <QStringList>

#include <cstdlib>
#include <cstring>
#include <malloc.h>
#include <string>

#include "AppOpenGLWrapper.hpp"
#include "util/Log.h"

namespace {

class CubismAllocator : public Csm::ICubismAllocator {
public:
    void* Allocate(const Csm::csmSizeType size) override
    {
        return std::malloc(static_cast<size_t>(size));
    }

    void Deallocate(void* memory) override
    {
        std::free(memory);
    }

    void* AllocateAligned(const Csm::csmSizeType size, const Csm::csmUint32 alignment) override
    {
        return _aligned_malloc(static_cast<size_t>(size), static_cast<size_t>(alignment));
    }

    void DeallocateAligned(void* alignedMemory) override
    {
        _aligned_free(alignedMemory);
    }
};

CubismAllocator g_allocator;
Csm::CubismFramework::Option g_option;
bool g_initialized = false;

QString g_shaderDir;
QString g_assetRoot;

void cubismLog(const Csm::csmChar* message)
{
    if (!message) {
        return;
    }
    Log::info(QStringLiteral("[cubism] %1").arg(QString::fromUtf8(message)));
}

QString appDir()
{
    return QCoreApplication::applicationDirPath();
}

QString defaultShaderDir()
{
    QStringList candidates;
    const QString env = qEnvironmentVariable("DEMON_LIVE2D_SHADER_DIR");
    if (!env.isEmpty()) {
        candidates << env;
    }
    candidates << QDir(appDir()).absoluteFilePath(QStringLiteral("live2d/shaders"));
#ifdef LIVE2D_SHADER_SOURCE_DIR
    candidates << QString::fromUtf8(LIVE2D_SHADER_SOURCE_DIR);
#endif

    for (const QString& candidate : candidates) {
        if (QFileInfo(candidate).isDir()) {
            return QDir(candidate).absolutePath();
        }
    }
    return candidates.isEmpty() ? QString() : QDir(candidates.first()).absolutePath();
}

QString resolveAssetPath(const QString& rawPath)
{
    QString path = rawPath;
    path.replace(QLatin1Char('\\'), QLatin1Char('/'));

    // Framework 内部用 "FrameworkShaders/xxx.vert" 这样的相对路径读 shader，
    // 必须映射到打包后的绝对目录（不能依赖 CWD）。
    if (path.contains(QStringLiteral("FrameworkShaders/"), Qt::CaseInsensitive)) {
        const int slash = path.lastIndexOf(QLatin1Char('/'));
        const QString name = slash >= 0 ? path.mid(slash + 1) : path;
        return QDir(CubismSupport::shaderDir()).absoluteFilePath(name);
    }

    const QFileInfo info(path);
    if (info.isAbsolute()) {
        return path;
    }

    if (!g_assetRoot.isEmpty()) {
        const QString candidate = QDir(g_assetRoot).absoluteFilePath(path);
        if (QFileInfo::exists(candidate)) {
            return candidate;
        }
    }

    const QString appCandidate = QDir(appDir()).absoluteFilePath(path);
    if (QFileInfo::exists(appCandidate)) {
        return appCandidate;
    }
    return path;
}

} // namespace

namespace CubismSupport {

bool initialize()
{
    if (g_initialized) {
        return true;
    }

    if (!Csm::CubismFramework::IsStarted()) {
        g_option.LogFunction = &cubismLog;
        g_option.LoggingLevel = Csm::CubismFramework::Option::LogLevel_Warning;
        g_option.LoadFileFunction = &CubismSupport::loadFile;
        g_option.ReleaseBytesFunction = &CubismSupport::releaseBytes;

        if (!Csm::CubismFramework::StartUp(&g_allocator, &g_option)) {
            Log::error(QStringLiteral("[live2d] CubismFramework::StartUp 失败"));
            return false;
        }
    }

    if (!Csm::CubismFramework::IsInitialized()) {
        Csm::CubismFramework::Initialize();
    }

    g_initialized = Csm::CubismFramework::IsInitialized();
    if (!g_initialized) {
        Log::error(QStringLiteral("[live2d] CubismFramework::Initialize 失败"));
    }
    return g_initialized;
}

void shutdown()
{
    if (Csm::CubismFramework::IsInitialized()) {
        Csm::CubismFramework::Dispose(); // 内部会 CubismRenderer::StaticRelease()
    }
    if (Csm::CubismFramework::IsStarted()) {
        Csm::CubismFramework::CleanUp();
    }
    g_initialized = false;
}

bool isInitialized()
{
    return g_initialized;
}

void setShaderDir(const QString& dir)
{
    g_shaderDir = dir;
}

QString shaderDir()
{
    if (g_shaderDir.isEmpty()) {
        g_shaderDir = defaultShaderDir();
    }
    return g_shaderDir;
}

void setAssetRoot(const QString& dir)
{
    g_assetRoot = dir;
}

Csm::csmByte* loadFile(const std::string filePath, Csm::csmSizeInt* outSize)
{
    if (outSize) {
        *outSize = 0;
    }

    const QString path = resolveAssetPath(QString::fromStdString(filePath));
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        Log::warn(QStringLiteral("[live2d] 打开文件失败: %1").arg(path));
        return nullptr;
    }

    const qint64 size = file.size();
    if (size <= 0 || size > 64LL * 1024 * 1024) {
        Log::warn(QStringLiteral("[live2d] 文件大小异常(%1): %2").arg(size).arg(path));
        return nullptr;
    }

    Csm::csmByte* bytes = new Csm::csmByte[static_cast<size_t>(size) + 1];
    const qint64 read = file.read(reinterpret_cast<char*>(bytes), size);
    if (read != size) {
        Log::warn(QStringLiteral("[live2d] 读取文件不完整: %1").arg(path));
        delete[] bytes;
        return nullptr;
    }
    bytes[size] = 0;

    if (outSize) {
        *outSize = static_cast<Csm::csmSizeInt>(size);
    }
    return bytes;
}

void releaseBytes(Csm::csmByte* bytes)
{
    delete[] bytes;
}

unsigned int createTextureFromImage(const QString& imagePath, int* outWidth, int* outHeight)
{
    if (outWidth) {
        *outWidth = 0;
    }
    if (outHeight) {
        *outHeight = 0;
    }

    QImageReader reader(imagePath);
    reader.setAutoTransform(false);
    QImage image;
    if (!reader.read(&image) || image.isNull()) {
        Log::error(QStringLiteral("[live2d] 纹理解码失败: %1 (%2)")
                       .arg(imagePath, reader.errorString()));
        return 0;
    }

    // 注意：必须上传「直通 alpha」，不能用 RGBA8888_Premultiplied。
    // Cubism 的 frag shader 自己就输出预乘（gl_FragColor.rgb = color.rgb * color.a），
    // 纹理再预乘一次会把半透明阴影压暗 → 脸上出现灰块。
    if (image.format() != QImage::Format_RGBA8888) {
        image = image.convertToFormat(QImage::Format_RGBA8888);
    }
    if (image.isNull()) {
        Log::error(QStringLiteral("[live2d] 纹理格式转换失败: %1").arg(imagePath));
        return 0;
    }

    QOpenGLFunctions* gl = AppOpenGLWrapper::get();
    GLuint textureId = 0;
    gl->glGenTextures(1, &textureId);
    gl->glBindTexture(GL_TEXTURE_2D, textureId);
    gl->glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
    gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    gl->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    gl->glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, image.width(), image.height(), 0, GL_RGBA,
                     GL_UNSIGNED_BYTE, image.constBits());
    gl->glGenerateMipmap(GL_TEXTURE_2D);
    gl->glBindTexture(GL_TEXTURE_2D, 0);

    if (outWidth) {
        *outWidth = image.width();
    }
    if (outHeight) {
        *outHeight = image.height();
    }

    Log::info(QStringLiteral("[live2d] 纹理已上传: %1x%2 (%3)")
                  .arg(image.width())
                  .arg(image.height())
                  .arg(QFileInfo(imagePath).fileName()));
    return textureId;
}

void deleteTexture(unsigned int textureId)
{
    if (textureId == 0) {
        return;
    }
    QOpenGLFunctions* gl = AppOpenGLWrapper::get();
    GLuint id = textureId;
    gl->glDeleteTextures(1, &id);
}

} // namespace CubismSupport
