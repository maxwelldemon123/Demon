#pragma once

#include <QJsonObject>
#include <QObject>
#include <QString>
#include <QTimer>
#include <QWebSocket>

/**
 * VTube Studio 插件 API 客户端（单后端）。
 *
 * 协议：ws://127.0.0.1:8001，JSON 消息 {apiName, apiVersion, requestID, messageType, data}
 * 流程：
 *   1. 连接后发 AuthenticationRequest（带已保存 token）
 *   2. 没有 token / token 失效 → 发 AuthenticationTokenRequest，VTS 弹窗让用户点「允许」
 *   3. 拿到 token 存到 data/vts-token.json，下次直接复用
 *   4. 之后可以注入参数（MouthOpen 等）、触发热键
 */
class VtsClient : public QObject {
    Q_OBJECT

public:
    enum class State {
        Disconnected,
        Connecting,
        WaitingForToken,   // 等用户在 VTS 里点允许
        Authenticating,
        Ready,
        Error,
    };

    explicit VtsClient(QObject* parent = nullptr);

    void setEndpoint(const QString& host, quint16 port);
    void setTokenFile(const QString& path);

    void connectToServer();
    void disconnectFromServer();
    State state() const { return m_state; }
    QString lastError() const { return m_lastError; }

    /** 注入一个 Live2D 参数（如 MouthOpen = 0..1） */
    void injectParameter(const QString& id, double value);
    /** 触发 VTS 热键 */
    void triggerHotkey(const QString& hotkeyId);

    /** 请求当前模型信息 */
    void requestCurrentModel();
    /** 请求表情列表 */
    void requestExpressionState();
    /** 激活表情（file 为表情文件名，如 exp_01.exp3.json） */
    void setExpression(const QString& file, bool active = true);

    QString modelName() const { return m_modelName; }
    QString modelId() const { return m_modelId; }
    QStringList expressionNames() const { return m_expressionNames; }
    QStringList expressionFiles() const { return m_expressionFiles; }

    /** 状态转文字（给 UI / HTTP 用） */
    static QString stateName(State state);

    /** 发送任意请求（调试用） */
    void sendRaw(const QString& messageType, const QJsonObject& data);

signals:
    void stateChanged(VtsClient::State state, const QString& detail);
    /** 收到任意响应（调试用） */
    void rawMessage(const QString& messageType, const QJsonObject& data);

private:
    void onConnected();
    void onTextMessage(const QString& message);
    void onDisconnected();
    void handleAuthenticationResponse(const QJsonObject& root);
    void handleTokenResponse(const QJsonObject& root);
    void handleGenericResponse(const QJsonObject& root);
    void sendRequest(const QString& messageType, const QJsonObject& data);
    void setState(State state, const QString& detail = QString());
    QString tokenFilePath() const;
    bool loadToken(QString* token) const;
    void saveToken(const QString& token) const;

    QWebSocket m_socket;
    QTimer m_reconnectTimer;
    State m_state = State::Disconnected;
    QString m_lastError;
    QString m_host = QStringLiteral("127.0.0.1");
    quint16 m_port = 8001;
    QString m_tokenFile;
    QString m_token;
    QString m_modelName;
    QString m_modelId;
    QStringList m_expressionNames;
    QStringList m_expressionFiles;
    quint64 m_requestSeq = 0;
    bool m_shouldReconnect = false;
    int m_reconnectAttempts = 0;
};
