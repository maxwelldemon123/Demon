// 独立验收程序：加载大肥鱼 model3.json，轮换表情、切口型，并自检像素数/FPS。
// 不参与 Demon 主程序（不进 demon target）。

#include <QApplication>
#include <QAudioDevice>
#include <QAudioSink>
#include <QMediaDevices>
#include <QMenu>
#include <QSystemTrayIcon>
#include <QTcpServer>
#include <QWebSocket>
#include <QWidget>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QElapsedTimer>
#include <QFileInfo>
#include <QImage>
#include <QTimer>

#include <algorithm>
#include <cmath>

#include "ui/Live2DWindow.h"
#include "util/Log.h"

namespace {

const char* kDefaultModelPath = "E:/dshwork/models/live2d/大肥鱼-B站/大肥鱼.model3.json";

QString shotsDir()
{
    const QString dir = QDir(QCoreApplication::applicationDirPath()).absoluteFilePath("probe_shots");
    QDir().mkpath(dir);
    return dir;
}

qint64 countOpaque(const QImage& image)
{
    if (image.isNull()) {
        return -1;
    }
    const QImage argb = image.convertToFormat(QImage::Format_ARGB32);
    qint64 count = 0;
    for (int y = 0; y < argb.height(); ++y) {
        const QRgb* line = reinterpret_cast<const QRgb*>(argb.constScanLine(y));
        for (int x = 0; x < argb.width(); ++x) {
            if (qAlpha(line[x]) > 8) {
                ++count;
            }
        }
    }
    return count;
}

qint64 countNonBlack(const QImage& image)
{
    if (image.isNull()) {
        return -1;
    }
    const QImage argb = image.convertToFormat(QImage::Format_ARGB32);
    qint64 count = 0;
    for (int y = 0; y < argb.height(); ++y) {
        const QRgb* line = reinterpret_cast<const QRgb*>(argb.constScanLine(y));
        for (int x = 0; x < argb.width(); ++x) {
            if ((qRed(line[x]) + qGreen(line[x]) + qBlue(line[x])) > 24) {
                ++count;
            }
        }
    }
    return count;
}

qint64 countDiff(const QImage& lhs, const QImage& rhs)
{
    if (lhs.isNull() || rhs.isNull() || lhs.size() != rhs.size()) {
        return -1;
    }
    const QImage a = lhs.convertToFormat(QImage::Format_ARGB32);
    const QImage b = rhs.convertToFormat(QImage::Format_ARGB32);
    qint64 count = 0;
    for (int y = 0; y < a.height(); ++y) {
        const QRgb* lineA = reinterpret_cast<const QRgb*>(a.constScanLine(y));
        const QRgb* lineB = reinterpret_cast<const QRgb*>(b.constScanLine(y));
        for (int x = 0; x < a.width(); ++x) {
            const int d = std::max(std::max(std::abs(qRed(lineA[x]) - qRed(lineB[x])),
                                            std::abs(qGreen(lineA[x]) - qGreen(lineB[x]))),
                                   std::max(std::abs(qBlue(lineA[x]) - qBlue(lineB[x])),
                                            std::abs(qAlpha(lineA[x]) - qAlpha(lineB[x]))));
            if (d > 8) {
                ++count;
            }
        }
    }
    return count;
}

struct Capture {
    QString tag;
    QImage image;
    qint64 opaque = -1;
    qint64 nonBlack = -1;
    qint64 diffVsBaseline = -1;
    qint64 diffVsMouthOff = -1;
};

class Probe : public QObject {
public:
    Probe(Live2DWindow* window, const QString& modelPath)
        : m_window(window)
        , m_modelPath(modelPath)
    {
    }

    void start()
    {
        Log::info(QStringLiteral("[probe] ==== 开始 ===="));
        Log::info(QStringLiteral("[probe] 模型: %1").arg(m_modelPath));
        Log::info(QStringLiteral("[probe] 日志目录: %1")
                      .arg(QCoreApplication::applicationDirPath()));

        m_clock.start();

        // 模型纹理很大（8192x8192），加载需要时间；轮询 ready()。
        m_readyPoll.setInterval(100);
        QObject::connect(&m_readyPoll, &QTimer::timeout, [this]() { pollReady(); });
        m_readyPoll.start();

        // 兜底：无论加载是否成功，25 秒后退出，避免挂住。
        QTimer::singleShot(25000, qApp, []() {
            Log::warn(QStringLiteral("[probe] 兜底超时，强制退出"));
            QCoreApplication::quit();
        });
    }

private:
    void pollReady()
    {
        if (!m_window->ready()) {
            return;
        }
        m_readyPoll.stop();
        m_readyMilliseconds = m_clock.elapsed();
        Log::info(QStringLiteral("[probe] 模型就绪，耗时 %1 ms").arg(m_readyMilliseconds));

        scheduleChecks();
    }

    void scheduleChecks()
    {
        // 每 2 秒轮换表情；8 秒后自动退出。
        QTimer::singleShot(300, qApp, [this]() { capture(QStringLiteral("baseline")); });
        QTimer::singleShot(500, qApp, [this]() { applyExpression(QStringLiteral("脸红")); });
        QTimer::singleShot(1500, qApp, [this]() { capture(QStringLiteral("exp_脸红")); });

        QTimer::singleShot(2500, qApp, [this]() { applyExpression(QStringLiteral("脸黑")); });
        QTimer::singleShot(3500, qApp, [this]() { capture(QStringLiteral("exp_脸黑")); });

        QTimer::singleShot(4500, qApp, [this]() { applyExpression(QStringLiteral("尾巴消失")); });
        QTimer::singleShot(5500, qApp, [this]() { capture(QStringLiteral("exp_尾巴消失")); });

        QTimer::singleShot(6500, qApp, [this]() { applyExpression(QStringLiteral("龇牙")); });
        QTimer::singleShot(7000, qApp, [this]() { capture(QStringLiteral("exp_龇牙")); });

        // 口型：先清掉表情，保证 mouth 0/1 两帧只差口型参数。
        QTimer::singleShot(7100, qApp, [this]() { clearExpression(); });
        QTimer::singleShot(7300, qApp, [this]() { capture(QStringLiteral("mouth_off")); });
        QTimer::singleShot(7400, qApp, [this]() { setMouth(1.0); });
        QTimer::singleShot(7850, qApp, [this]() { capture(QStringLiteral("mouth_1.0")); });
        QTimer::singleShot(7900, qApp, [this]() { setMouth(0.0); });

        QTimer::singleShot(7950, qApp, [this]() { finish(); });
        QTimer::singleShot(8000, qApp, []() { QCoreApplication::quit(); });
    }

    void applyExpression(const QString& name)
    {
        m_window->setExpression(name);
        Log::info(QStringLiteral("[probe] setExpression(%1) -> %2")
                      .arg(name, m_window->ready() ? QStringLiteral("ok") : QStringLiteral("not ready")));
    }

    void clearExpression()
    {
        m_window->clearExpression();
        Log::info(QStringLiteral("[probe] clearExpression()"));
    }

    void setMouth(double value)
    {
        m_window->setMouth(value);
        Log::info(QStringLiteral("[probe] setMouth(%1)").arg(value, 0, 'f', 2));
    }

    void capture(const QString& tag)
    {
        Capture capture;
        capture.tag = tag;
        capture.image = m_window->grabFrame();
        capture.opaque = countOpaque(capture.image);
        capture.nonBlack = countNonBlack(capture.image);

        if (!m_baseline.image.isNull() && tag != QStringLiteral("baseline")) {
            capture.diffVsBaseline = countDiff(m_baseline.image, capture.image);
        }
        if (tag == QStringLiteral("mouth_1.0") && !m_mouthOffImage.isNull()) {
            capture.diffVsMouthOff = countDiff(m_mouthOffImage, capture.image);
        }

        const QString path = QDir(shotsDir()).absoluteFilePath(tag + QStringLiteral(".png"));
        capture.image.save(path);

        Log::info(QStringLiteral("[probe] frame tag=%1 size=%2x%3 opaque=%4 nonBlack=%5 "
                                 "diffVsBaseline=%6 diffVsMouthOff=%7 fps=%8 drawMs=%9")
                      .arg(tag)
                      .arg(capture.image.width())
                      .arg(capture.image.height())
                      .arg(capture.opaque)
                      .arg(capture.nonBlack)
                      .arg(capture.diffVsBaseline)
                      .arg(capture.diffVsMouthOff)
                      .arg(m_window->fps(), 0, 'f', 1)
                      .arg(m_window->drawMilliseconds(), 0, 'f', 2));
        Log::info(QStringLiteral("[probe] 截图已保存: %1").arg(path));

        if (tag == QStringLiteral("baseline")) {
            m_baseline = capture;
        }
        if (tag == QStringLiteral("mouth_off")) {
            m_mouthOffImage = capture.image;
        }
        m_captures.append(capture);
    }

    void finish()
    {
        Log::info(QStringLiteral("[probe] ==== 汇总 ===="));
        Log::info(QStringLiteral("[probe] 加载耗时(ms)=%1").arg(m_readyMilliseconds));

        const Capture* baseline = &m_baseline;
        Log::info(QStringLiteral("[probe] 基线: opaque=%1 nonBlack=%2")
                      .arg(baseline->opaque)
                      .arg(baseline->nonBlack));

        for (const Capture& capture : m_captures) {
            if (capture.tag == QStringLiteral("baseline")) {
                continue;
            }
            Log::info(QStringLiteral("[probe] %1: opaque=%2 nonBlack=%3 diffVsBaseline=%4 "
                                     "diffVsMouthOff=%5")
                          .arg(capture.tag)
                          .arg(capture.opaque)
                          .arg(capture.nonBlack)
                          .arg(capture.diffVsBaseline)
                          .arg(capture.diffVsMouthOff));
        }

        Log::info(QStringLiteral("[probe] FPS=%1").arg(m_window->fps(), 0, 'f', 1));

        const bool drawn = baseline->opaque > 5000 || baseline->nonBlack > 5000;
        Log::info(QStringLiteral("[probe] VERDICT drawn=%1").arg(drawn ? QStringLiteral("PASS")
                                                                        : QStringLiteral("FAIL")));

        for (const Capture& capture : m_captures) {
            if (capture.tag == QStringLiteral("baseline")) {
                continue;
            }
            if (capture.tag.startsWith(QStringLiteral("exp_"))) {
                Log::info(QStringLiteral("[probe] VERDICT expression %1 diff=%2 %3")
                              .arg(capture.tag)
                              .arg(capture.diffVsBaseline)
                              .arg(capture.diffVsBaseline > 500 ? QStringLiteral("PASS")
                                                                : QStringLiteral("FAIL")));
            }
        }
        for (const Capture& capture : m_captures) {
            if (capture.tag == QStringLiteral("mouth_1.0")) {
                Log::info(QStringLiteral("[probe] VERDICT mouth diff=%1 %2")
                              .arg(capture.diffVsMouthOff)
                              .arg(capture.diffVsMouthOff > 100 ? QStringLiteral("PASS")
                                                                : QStringLiteral("FAIL")));
            }
        }
        Log::info(QStringLiteral("[probe] VERDICT fps=%1 %2")
                      .arg(m_window->fps(), 0, 'f', 1)
                      .arg(m_window->fps() >= 25.0 ? QStringLiteral("PASS") : QStringLiteral("FAIL")));
    }

    Live2DWindow* m_window = nullptr;
    QString m_modelPath;
    QTimer m_readyPoll;
    QElapsedTimer m_clock;
    qint64 m_readyMilliseconds = 0;
    Capture m_baseline;
    QImage m_mouthOffImage;
    QList<Capture> m_captures;
};

} // namespace

int main(int argc, char** argv)
{
    QCoreApplication::setAttribute(Qt::AA_UseDesktopOpenGL);
    Live2DWindow::configureSurfaceFormat();

    QApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("Live2DProbe"));
    app.setApplicationVersion(QStringLiteral("0.1"));

    Log::init(QDir(QCoreApplication::applicationDirPath())
                  .absoluteFilePath(QStringLiteral("data/live2d_probe.log")));

    const QStringList arguments = QCoreApplication::arguments();
    QString modelPath = arguments.value(1);
    if (modelPath.isEmpty()) {
        modelPath = QString::fromUtf8(kDefaultModelPath);
    }
    if (!QFileInfo::exists(modelPath)) {
        Log::error(QStringLiteral("[probe] 模型不存在: %1").arg(modelPath));
        return 2;
    }

    Live2DWindow window;
    window.resize(520, 760);
    window.setPosition(160, 70);
    window.loadModel(modelPath);
    window.show();
    window.raise();
    window.requestActivate();

    // ---- 诊断：模拟 Demon 进程里同时存在的其它组件 ----
    // PROBE_EXTRA=tray,http,ws,widget 控制要加哪些，用来定位「同样代码在 Demon 里只有 10fps」的原因。
    const QString extra = qEnvironmentVariable("PROBE_EXTRA").trimmed();
    QSystemTrayIcon* tray = nullptr;
    QTcpServer* tcp = nullptr;
    QWidget* widgetWindow = nullptr;
    QWebSocket* socket = nullptr;

    if (extra.contains(QStringLiteral("tray"))) {
        QIcon icon;
        tray = new QSystemTrayIcon(icon, &app);
        auto* menu = new QMenu;
        menu->addAction(QStringLiteral("测试"));
        tray->setContextMenu(menu);
        tray->show();
        Log::info(QStringLiteral("[probe] extra: tray"));
    }
    if (extra.contains(QStringLiteral("http"))) {
        tcp = new QTcpServer(&app);
        tcp->listen(QHostAddress::LocalHost, 8799);
        Log::info(QStringLiteral("[probe] extra: http %1").arg(tcp->isListening() ? 1 : 0));
    }
    if (extra.contains(QStringLiteral("widget"))) {
        widgetWindow = new QWidget;
        widgetWindow->resize(1080, 760);
        widgetWindow->setWindowTitle(QStringLiteral("fake main window"));
        widgetWindow->show();
        Log::info(QStringLiteral("[probe] extra: widget"));
    }
    QAudioSink* audioSink = nullptr;
    if (extra.contains(QStringLiteral("audio"))) {
        const QAudioDevice device = QMediaDevices::defaultAudioOutput();
        QAudioFormat fmt;
        fmt.setSampleRate(24000);
        fmt.setChannelCount(1);
        fmt.setSampleFormat(QAudioFormat::Int16);
        if (!device.isNull() && device.isFormatSupported(fmt)) {
            audioSink = new QAudioSink(device, fmt, &app);
            Log::info(QStringLiteral("[probe] extra: audio sink created"));
        } else {
            Log::warn(QStringLiteral("[probe] extra: audio sink 不可用（设备空或不支持）"));
        }
    }
    if (extra.contains(QStringLiteral("ws"))) {
        socket = new QWebSocket(QString(), QWebSocketProtocol::VersionLatest, &app);
        socket->open(QUrl(QStringLiteral("ws://127.0.0.1:8001")));
        Log::info(QStringLiteral("[probe] extra: websocket"));
    }

    Probe probe(&window, modelPath);
    probe.start();

    return app.exec();
}
