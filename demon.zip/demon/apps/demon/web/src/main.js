import * as PIXI from 'pixi.js';
import { Live2DModel } from 'pixi-live2d-display/cubism4';

window.PIXI = PIXI;

const params = new URLSearchParams(location.search);
const modelBase = params.get('base') || '../models/c_0120/';
const modelFile = params.get('model') || 'c_0120.model3.json';

const app = new PIXI.Application({
  backgroundAlpha: 0,
  antialias: true,
  resolution: 1,
  autoDensity: true,
  resizeTo: window,
});
document.body.appendChild(app.view);

let model = null;
let frameCounter = 0;
let fpsValue = 0;
app.ticker.maxFPS = 30;
app.ticker.add(() => { frameCounter++; });
setInterval(() => { fpsValue = frameCounter; frameCounter = 0; }, 1000);
const expressionCache = new Map();

async function applyExpression(name) {
  if (!model || !name) return;
  if (!expressionCache.has(name)) {
    const url = `${modelBase}${name}.exp3.json`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`expression not found: ${name}`);
    expressionCache.set(name, await response.json());
  }
  const data = expressionCache.get(name);
  const core = model.internalModel.coreModel;
  for (const param of data.Parameters || []) {
    try {
      if (param.Blend === 'Add') {
        core.addParameterValueById(param.Id, param.Value, 1);
      } else if (param.Blend === 'Multiply') {
        core.multiplyParameterValueById(param.Id, param.Value, 1);
      } else {
        core.setParameterValueById(param.Id, param.Value, 1);
      }
    } catch {
      // 模型没有该参数时忽略
    }
  }
}

(async () => {
  try {
    model = await Live2DModel.from(modelBase + modelFile, { autoInteract: false });
    app.stage.addChild(model);

    const naturalW = model.width;
    const naturalH = model.height;
    const fit = () => {
      const scale = Math.min(window.innerWidth / naturalW, window.innerHeight / naturalH) * 0.92;
      model.scale.set(scale);
      model.x = (window.innerWidth - naturalW * scale) / 2;
      model.y = window.innerHeight - naturalH * scale;
    };
    fit();
    window.addEventListener('resize', fit);

    window.pet = {
      ready: true,
      fps: () => fpsValue,
      setExpression: (name) => {
        try {
          model.expression(name);
        } catch {
          applyExpression(name).catch((e) => console.warn(e.message));
        }
      },
      setMouth: (value) => {
        try {
          model.internalModel.coreModel.setParameterValueById('ParamMouthOpenY', Math.max(0, Math.min(1, value)));
        } catch {
          // 忽略
        }
      },
      setScale: (value) => model.scale.set(value),
      modelInfo: () => ({ width: model.width, height: model.height }),
    };
    document.title = 'localpet-ready';
  } catch (error) {
    console.error(error);
    document.title = 'localpet-error';
    const pre = document.createElement('pre');
    pre.style.color = '#f66';
    pre.textContent = String(error && error.message ? error.message : error);
    document.body.appendChild(pre);
  }
})();
