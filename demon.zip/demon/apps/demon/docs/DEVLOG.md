# Demon — 开发日志

## 2026-10-24 · 1.0 D1 + D2 完成

### 目标
按 v1.3 计划书的主方向（反向集成）落地：Demon 对外提供 OpenAI 兼容端点，酒馆当界面。

### 已完成

| 项 | 状态 |
| --- | --- |
| 仓库骨架（CMake + Qt 6.8.3 + MSVC 2022） | ✅ |
| 极简 HTTP/1.1 服务器（QTcpServer，自解析） | ✅ |
| `GET /healthz` | ✅ |
| `GET /v1/models` | ✅ |
| `OPTIONS` 预检 + CORS（回显 Origin） | ✅ |
| `POST /v1/chat/completions` SSE 流式透传 | ✅ |
| 托盘图标 + 菜单（日志/配置目录/重载/退出） | ✅ |
| 日志落盘（`bin/data/demon.log`） | ✅ |
| 配置文件自动生成（`bin/config.json`） | ✅ |
| 假上游（`tools/fake_upstream.py`）用于本地验证 | ✅ |

### 实测证据

```
GET /healthz        → 200，返回 model/upstream/voice
GET /v1/models      → 200，data[0].id = demon
OPTIONS             → 204，ACAO 回显
POST stream=true    → 200 text/event-stream，17 个 data 事件，末行 data: [DONE]
                      首包 6 ms 到达（未缓冲），总耗时 1.98s（上游每 token 120ms）
POST stream=false   → 501（非流式留到后续）
```

### 踩到的坑与修复

1. **流式回调悬空指针导致 0xC0000005 崩溃**
   - 原因：`HttpStream` 是 `onReadyRead` 里的栈对象，异步回调按引用捕获。
   - 修复：`HttpStream` 改为 `shared_ptr`，由 `HttpServer::Client` 持有；socket 用 `QPointer` 防悬空；转发逻辑抽成独立 `StreamJob`（parent = reply，随 reply 销毁）。

2. **`writeHead` 被重构误删**
   - 现象：curl 收到的是裸 `data: ...`，没有 HTTP 头。
   - 修复：在 `post()` 之前显式 `stream->writeHead(200, "text/event-stream")`。

3. **`unique_ptr` 与 QObject parent 双重持有**
   - `QNetworkAccessManager` / `HttpServer` 既被 `unique_ptr` 管理，又传了 `this` 作 parent → 退出时双重删除。
   - 修复：不给 parent，统一由 `unique_ptr` 管理。

### 已知限制（D3 处理）

- 非流式请求返回 501（酒馆默认流式，可接受）。
- 没有 SSE 保活（`KeepAliveSeconds` 配置项已预留，未实现）。
- 上游只支持一个默认；按 model 名分流未实现。
- TTS 未接入（D3）。

### 如何复现验证

```bat
:: 1. 启动假上游
"<python.exe>" tools\fake_upstream.py

:: 2. 构建并启动
tools\build.bat
build\bin\demon.exe

:: 3. 测试
curl -N -X POST http://127.0.0.1:8790/v1/chat/completions ^
  -H "Content-Type: application/json" ^
  --data-binary "@build\req.json"
```

## 2026-10-24 · 1.0 D3 完成（语音）

### 已完成

| 项 | 说明 |
| --- | --- |
| `TtsClient` | 调 GPT-SoVITS api_v2 的 `/tts`，返回 WAV |
| `AudioPlayer` | QMediaPlayer + QAudioBuffer，内存播放，无需落盘 |
| 分句 | `splitForSpeech()`：按句末标点切，过长再按逗号切，去掉 *动作* 与（动作） |
| 语种判定 | 假名→ja / 汉字→zh / 韩文→ko / 其余 en |
| 语音队列 | 逐句合成 → 播放 → 下一句（按 WAV 时长估算间隔） |
| 自动朗读 | 每条回复流式结束后自动触发（配置 `voice.autoPlay`） |
| `GET /voice/status` | 端点、声线、队列、busy、可用档案 |
| `POST /voice/speak` | 单句合成，直接返回 `audio/wav`（便于命令行验证） |
| 两条声线 | xiaod / demon，参考音频与 prompt 写在 config.json |

### 实测

```
POST /voice/speak  {"text":"主人，晚上好。","profile":"xiaod","lang":"zh"}
  → HTTP 200, 152,364 字节, RIFF/WAVE, 8.8s（含模型首次加载）

酒馆里发一条消息（回复 20 字）：
  回调：收到完整文本 20 字
  准备朗读 2 句
  合成[zh]：你好，我是Demon。      → 133 KB → 开始播放
  合成[zh]：这是一次流式测试。      → 186 KB → 开始播放
  单句合成耗时 1.1~1.5s（热态）
```

### 本阶段修掉的 bug

1. `accumulate()` 没被调用（补丁没命中）→ 文本一直是 0 字。
2. `StreamJob` 构造函数漏了 `m_onText` 初始化 → 完成回调永远不触发。
3. 老 `config.json` 没有 `voiceProfiles` → 启动时档案为 0；现在缺省补两条。
4. `/voice/speak` 先发 200 再合成失败，把错误文本写进了 wav；改成合成完成后再发头（失败 502）。

### 已知限制

- 声线只能改配置，托盘还没有切换菜单（D4）。
- 没有按角色自动选声线。
- 首句延迟 = 合成时间（1~8s），尚未做"边写边合成"。
- 播放设备用系统默认。
## 2026-10-24 · 1.0 D4 完成（托盘 + 保活 + 路由 + 音量）

### 新增

| 项 | 说明 | 验证 |
| --- | --- | --- |
| 托盘「声线」子菜单 | xiaod / demon 单选，切换即写回 config.json | 代码路径 + 配置持久化 |
| 托盘「自动朗读」开关 | 勾选状态写回 config.json | 同上 |
| SSE 保活 | 每 `keepAliveSeconds` 秒发 `:keep-alive` | **实测**：慢上游沉默 6s，收到 2 条保活 |
| 上游按模型名路由 | 请求 model 匹配上游 id/model 时定向，否则回落默认 | **实测**：fake-model-b 打到 8898，demon/nope 打到 8899 |
| 音量 | `voice.volume` → QAudioOutput | 编译通过，待听感确认 |

### 自动化冒烟测试（`tools/smoke_test.py`）

```
== 1. 基础接口 ==      healthz / models / voice/status        ✓ ✓ ✓
== 2. 语音合成 ==      xiaod 中文 4.76s / demon 日文 3.72s / 空文本 400   ✓ ✓ ✓
== 3. 流式对话 ==      17 个事件, [DONE], text/event-stream    ✓ ✓
== 4. 上游路由 ==      fake-model → 8899, fake-model-b → 8898, 未知 → 回落   ✓ ✓ ✓
== 5. 语音队列 ==      最终排空                                ✓
通过 12/12
```

### 备注

- 语音合成热态 1.3~1.4s/句（32 kHz WAV）。
- 慢上游测试暴露一个正常行为：客户端（curl 管道被提前关闭）断开时会中止上游，日志会记 `WARN 客户端提前断开`，这是预期。
## 2026-10-24 · 1.0 D5 完成（稳定性 + 打包 + 真模型）

### 稳定性

| 场景 | 处理 | 实测 |
| --- | --- | --- |
| 上游中途断开 | 发 `data: {"error":...}` + `data: [DONE]`，客户端不会一直转圈 | 停掉假上游后 4.1s 返回错误事件 |
| 端口被占用 | 弹窗提示 + 日志，不再静默退出 | 代码路径（未在无头环境实测弹窗） |
| 首包失败 | 同上，带 `[DONE]` | 已验证 |

### 打包（dist\Demon）

- `DEMON_CONSOLE=OFF` 构建 → 子系统 = Windows GUI（无控制台窗口），exe 155 KB
- windeployqt 后整包 **44.8 MB / 32 文件**（含 Qt6 + FFmpeg 多媒体运行库）
- 脚本：`启动Demon.bat` `停止Demon.bat` `安装开机启动.bat` `卸载开机启动.bat`
  - bat 必须 **GBK + CRLF**，UTF-8 会被 cmd 按字节拆成命令（踩过：`'ul' is not recognized`）
  - 开机自启只写 `HKCU\...\Run`，实测安装 → 注册表有值 → 卸载 → 已清除
- `使用说明.txt`：酒馆配置、配置项、排错

### 真模型联调

本机 DSH 网关 `127.0.0.1:8099` 提供 `local-vl`（Qwen3-VL-4B）：

```
4 轮对话：0.6s / 0.1s / 0.1s / 0.1s（模型已在内存）
内存：36.2 MB → 36.2 MB（无增长）
每轮都触发 TTS 并播放（93~466 KB WAV）
```

注意：该网关会用「视觉子代理」系统提示词覆盖，所以回复风格不是聊天模型；
换真聊天模型只需改 `upstreams` 的 baseUrl/model。

### 已知限制

- 端口冲突弹窗在无桌面会话下会阻塞（正常桌面无影响）
- 没有单实例检测（重复启动会弹窗后退出，可接受）
- `dist` 里的 config 指向 8099（本机 DSH 网关），换机器要改

### 环境核查（D5 收尾）

- 本次安装/构建全部落在 E 盘：Qt、构建产物、dist、测试数据。
- 本会话临时文件已清理 64 MB（`%TEMP%\dsh-subprocess-*`、ego 截图）。
- C 盘从 24.1 GB → 18.6 GB 的主要原因是 **系统页面文件**（`C:\pagefile.sys` 当前分配 12.3 GB，峰值仅 1.5 GB）
  以及既有的 VS 安装缓存（2.6 GB）和 gopeed 预取文件（1 GB，10-22 生成，非本项目）。
  项目本身没有向 C 盘写入任何文件。
## 2026-10-24 · 控制窗口（解决“找不到托盘图标”）

### 背景
用户反馈看不到托盘内容。排查结论：进程与 explorer 同会话（Session 2），
托盘创建成功（日志 `系统托盘可用=是`），但 **Windows 11 把新图标默认放进折叠区**，
注册表 `NotifyIconSettings` 里也没有登记项。

### 改动
1. 新增 `ControlWindow`（Qt Widgets）：运行状态 / 声线切换 / 自动朗读开关 /
   复制接口地址 / 打开日志 / 配置目录 / 重载配置 / 退出。
2. 启动即显示控制窗口，托盘图标保留为快捷方式（双击重新打开窗口）。
3. 启动气泡提示：“右键托盘 D 图标…如果没看到，点任务栏 ^”。
4. 单实例检测（QSharedMemory）：重复双击不再弹“端口被占用”，
   而是提示“已经在运行”。
5. 端口占用文案补充“最常见原因是已经有一个 Demon 在运行”。

### 踩坑
- 无 DPI 感知的 PowerShell 里 `GetWindowRect` 返回的是**虚拟化坐标**（1.75 倍缩放），
  截出来的窗口总像被裁掉。用 `SetProcessDpiAwarenessContext(-4)` 后拿到真实尺寸
  （1214x624，屏幕 2560x1440），确认窗口完整。
- 窗口尺寸不能写死：固定 560 宽会裁掉按钮；最终用
  `layout()->setSizeConstraint(QLayout::SetMinimumSize)` 让布局决定最小尺寸。

## 2026-10-24 · 托盘图标问题定论

### 现象
- 用户看不到 Demon 托盘图标；Win11「其他系统托盘图标」列表里也没有 Demon。
- 程序侧日志：`isSystemTrayAvailable=是`、`isVisible=1`、`iconNull=0`，
  但 `geometry=0x0`。

### 对照实验
1. 写了一个 20 行最小 Qt 托盘程序（红色圆点）：
   `available=true visible=true geometry=0x0`，注册表 `NotifyIconSettings` 同样无记录。
2. 重启 Explorer 后重试：仍然无位置、无登记。

### 结论
**不是 Demon 的代码问题，是这台 Win11 不注册新的第三方托盘图标。**
（`HKCU\Control Panel\NotifyIconSettings` 里只有 Quark/WeGame/OneDrive 等既有条目，
新程序不会生成条目，因此也不会出现在设置页。）

### 应对
- 控制窗口作为主界面，启动即显示。
- 关闭窗口 = 退出程序（避免“看不见也关不掉”）。
- 托盘仍保留（万一以后系统恢复了能用），但不再作为唯一入口。
- 文档里说明：想快速启动就建桌面快捷方式或固定到任务栏。

## 2026-10-24 · 音色档案从酒馆插件迁入 Demon

### 背景
用户要求：`st-gptsovits5-voice` 插件只保留音色档案并留存在 Demon，酒馆端删掉插件。

### 档案来源
插件配置存在酒馆 `settings.json` 的 `extension_settings.gptsovits5_voice`，
共 4 条档案（id / gptWeights / sovitsWeights / refAudio / promptText / promptLang）。

### 迁移动作
1. `VoiceProfileConfig` 增加 `name` / `gptWeights` / `sovitsWeights`。
2. `TtsClient::ensureWeights()`：合成前比对当前权重，不同则依次 GET
   `/set_gpt_weights?weights_path=...`、`/set_sovits_weights?weights_path=...`，
   成功后才合成；`/voice/speak` 与自动朗读都走这条路径。
3. 参考音频复制到 `dist\Demon\voices\`，配置里用绝对路径（api_v2 的相对路径按它自己的 cwd 解析）。
4. 4 条档案写入 `config.json`，默认声线 `小d-柔软`。

### 酒馆端清理
- 检查 `public/scripts/extensions/third-party`、`plugins/`：**插件代码本来就不在了**。
- 删除 `settings.json` 里的 `gptsovits5_voice` 配置（先备份到
  `E:\dshwork\st-gptsovits5-voice\_st-backup\`）。
- 注意：酒馆当时正在运行（pid 20104），它下次保存设置时可能用内存里的旧配置覆盖；
  重启一次酒馆即可固定，或运行 `dist\Demon\清理酒馆插件残留.bat`。

### 实测
```
小d-柔软       -> 200  157 KB  3.5s
demon-小恶魔   -> 200  178 KB  3.2s
小d-柔软-泛化  -> 200  175 KB  2.7s
demon-小恶魔-2 -> 200  181 KB  2.7s
日志：权重已切换：...（每条切换 0.3~0.5 秒）
自检：5/5 PASS（profiles 显示 4 条）
```

## 2026-10-24 · UI 重构（仿 Electron 版）+ 启动器 + 角色声线

### 新界面
左侧深色导航（状态/接口/启动/语音/角色/日志），右侧 QStackedWidget 面板，
整体仿 1.0 Electron 版的三栏观感（不含聊天界面）。

- 状态：接口地址、上游、模型、默认声线、队列 + 快捷按钮
- 接口：上游表格（可增删改）+ 默认上游，保存后热加载
- 启动：SillyTavern 与 GPT-SoVITS 路径（已预填）、端口、启动/停止/打开页面
- 语音：4 条档案表格 + 试听 / 设为默认
- 角色：扫描 `characters` 目录，逐角色绑定声线
- 日志：日志尾部查看

### 启动器实现
`QProcess::startDetached("cmd.exe", {"/c","start","",bat}, workdir)`：
- 酒馆：`<stPath>\Start.bat`
- 语音：`<gsvPath>\start-api-v2pro.bat`
停止：解析 `netstat -ano -p tcp` 找端口对应 pid，再 `taskkill /PID /F`。
状态：每 1.5 秒探测 8000 / 9880 端口，绿点=运行中。

### 角色声线
`config.characterVoices`（角色名 → 档案 id）。
请求到达时 `detectCharacterProfile()` 在请求体里找绑定的角色名（取最长匹配），
写入 `m_pendingProfile`，朗读时优先使用；没有匹配则用默认声线。

### 实测
```
请求 system 里含「小鲸鱼娘」：
  识别到角色 小鲸鱼娘，使用声线 demon-小恶魔
  准备朗读 1 句（声线 demon-小恶魔）
  权重已切换：GPT_weights_v2Pro/nightmare-JP-e15.ckpt
  权重已切换：SoVITS_weights_v2Pro/nightmare-JP_e8_s368.pth
  TTS 合成完成：2 字 / 68 KB
```

### 踩坑
- 截图看起来“页面错位”，实际是 PrintWindow 抓到切换前的旧帧；
  用 UIA 的 BoundingRectangle 定位点击 + 等待 900ms 后正常。
- PowerShell 单引号字符串里的 `` `r`n `` 是字面量，会写进 C++ 源码导致编译失败（又踩一次）。

## 2026-10-24 · 启动酒馆后自动打开浏览器

### 实现
点「启动酒馆」后：
1. 调 Start.bat 拉起酒馆；
2. 每 600ms 探测一次端口，最多等 72 秒；
3. 端口一通就打开 http://127.0.0.1:<端口>/；
4. 若酒馆本来就在跑，直接打开页面。
「打开页面」按钮也走同一函数。

打开方式按顺序尝试：默认浏览器 exe（从注册表读）→ cmd start → rundll32 → QDesktopServices。

### 没能当场验证的原因
当前调试环境会拦截 GUI 子进程：
- 从 Demon 里 CreateProcess 启动 notepad / msedge，返回成功但进程秒退；
- 连 pwsh 的 Start-Process 启 GUI 程序都报 "The operation was canceled by the user"；
- 控制台子进程（node/cmd）正常（酒馆就是被 Demon 启动并一直跑着）。

结论：这是**沙箱限制 GUI 子进程**，不是代码问题。用户双击桌面快捷方式的正常会话不受此限制。

## 2026-10-24 · smartdemon 插件（改造版）

### 做法
不重写，直接把 `st-gptsovits5-voice` 改造成 `plugin/smartdemon`：
保留 UI/分句/队列/绑定逻辑（约 70%），只换后端。

| 文件 | 处理 |
| --- | --- |
| lib/tts-text.js | 保留；cacheKey 改用 profile.id；normalizeProfile 放宽（权重归 Demon） |
| style.css | 保留，新增选句菜单样式 |
| index.js | 换网络层：9880 → 8790；删 setWeights；档案表单只读；新增选句菜单 |
| server/ | 删除（Demon 处理 CORS） |

### 新增能力：逐句播放
每条 AI 消息两个按钮：
- 🔊 耳机：整条朗读（Shift=换声线，Alt=标注）
- ☰ 列表：弹出该消息的句子列表，点第 N 句只播第 N 句

### 实测（酒馆 1.18 + Demon）
```
插件加载 → 自动同步 4 条声线（小d-柔软 / demon-小恶魔 / 小d-柔软-泛化 / demon-小恶魔-2）
点耳机     → OPTIONS /voice/speak 204 → 切权重 → TTS 合成完成 14 字 / 293 KB
点列表→第1句 → /voice/speak → TTS 合成完成 23 字 / 332 KB
```

### 过程中修的三个问题
1. 历史消息没有按钮：init 时聊天 DOM 未渲染完 → 加 800ms/1800ms 延迟补装饰。
2. 未绑定角色直接报错：改为回退 Demon 默认声线。
3. 用户消息/系统提示也有按钮：按 is_user / smallSysMes 过滤。

### 环境处理
发现 `demon.exe` 被打上 `RUNASADMIN` 兼容性标记（导致每次弹 UAC、非管理员无法启动），
已从 `HKCU\...\AppCompatFlags\Layers` 清除；现在非管理员可正常启动。

## 2026-10-24 · 插件独立成库

- 新建仓库 `E:\dshwork\smartdemon`（git 已初始化）
- 首次提交 `a4c2c0b`：7 个文件（index.js / lib/tts-text.js / style.css / manifest.json / README / LICENSE / .gitignore）
- Demon 仓库不再包含插件：`plugin/` 已移出，提交集合回到 33 个文件 / 206 KB
- 酒馆里的安装副本已用新仓库源码覆盖
- 仓库身份用的是本地占位（smartdemon@localhost），推送前可改成自己的

## 2026-10-24 · 许可证

- 新增 `LICENSE`（MIT，Copyright (c) 2026 dsh），与 smartdemon 插件保持一致
- 新增 `THIRD-PARTY-NOTICES.txt`：
  - Qt 6.8.3 — LGPL-3.0，动态链接、DLL 独立可替换、未修改
  - FFmpeg（Qt 自带构建）— LGPL-2.1+，动态加载
  - MSVC 运行库 — 随系统/VC Redist
  - SillyTavern / GPT-SoVITS — 仅通过 HTTP 调用，未打包
- README 补「许可」段
- 发布包加入这两个文件并重新压缩：42 个文件 / 20.3 MB
  SHA256 `D2119D0A073FD2535DEF2067E8A369B5B8F0C3D6C0BF99E86A333C9458A8620B`

## 2026-10-24 · 1.1.0

### 删除
- 「回复后自动朗读」整条链路（未达预期）：
  onAssistantText / enqueueSpeech / pumpSpeech / estimateWavMs / 角色识别 / 托盘开关 / 配置项 autoPlay
- 语音不再由 Demon 主动播出，改由酒馆插件 smartdemon 调 `/voice/speak` 按句播放

### 清理
- 默认声线档案去重（Config 两处 → defaultVoiceProfiles()）
- 声线组装去重（setupVoice / reloadConfig → buildVoiceProfiles()）
- Log 改常驻 QFile + QMutex（原来每行 open/close）
- TextSplit 四个正则改 static
- 删死代码：browserProcessCount / AudioPlayer::isPlaying / TtsClient::probe / defaultProfileId / splitForSpeech

### 验证
- 编译通过，healthz `version=1.1.0`
- `/voice/status` 不再返回 autoPlay/queued/busy
- 聊天后 8 秒内无任何 TTS 日志（确认不再自动播报）
- `/voice/speak` 仍正常：154,924 字节 WAV

### 发布
- `Demon-1.1.0-win64.zip` 42 个文件 / 20.3 MB
  SHA256 `B7B4B4392D3BD20DD2EBD0443C721861DD6806B766A2D1AA86398596E8CF7EA1`

## 2026-10-24 · 1.1.1（千问语音 + Live2D 起始）

### 千问 Qwen 语音
- 新增 `voice.provider = gptsovits | qwen`
- 千问走 DashScope：`POST https://dashscope.aliyuncs.com/api/v1/services/audio/tts/SpeechSynthesizer`
  - model `qwen-audio-3.1-tts-flash`，voice `longanhuan_v3.1`
  - 非流式返回 24h 音频 URL，Demon 再下载成 WAV
- 实测：11 字 → 76 KB WAV，**0.98 秒**（本地 GPT-SoVITS 约 1.5~8 秒）
- API Key 只写 `dist/Demon/config.json`（已 gitignore），不进日志、不进仓库
- 「启动」页新增后端选择 + 模型/音色/API Key + 「试听千问」

### Live2D（2.0 起步）
- `VtsClient`：VTube Studio WebSocket API（8001）
  - 认证流程：AuthenticationRequest → 无 token 走 AuthenticationTokenRequest → 存 `data/vts-token.json`
  - 注入 `MouthOpen` / 触发 Hotkey
- `LipSync`：WAV → 30fps 包络（RMS 归一化）
- `/live2d/status`、`/live2d/test`、`/live2d/envelope`
- 「Live2D」页：连接状态、重连、MouthOpen 滑杆、扫一遍 0→1
- 现状：VTS 已连上，状态 `waiting-for-token`，等待用户在 VTS 里点「允许」

### 实测
```
healthz version 1.1.1
voice/status provider=qwen model=qwen-audio-3.1-tts-flash voice=longanhuan_v3.1
/voice/speak 11 字 → 76,844 字节 WAV / 0.98 秒
/live2d/envelope 68 帧 / 2.27 秒 / peak 0.39
```

### 发布
- `Demon-1.1.1-win64.zip` 47 文件 / 20.5 MB
  SHA256 `D2B2BFC45119425426FFEFB9937DE8DC893BB469FA474C26F5E4092133070220`

## 2026-10-24 · 2.0 起步：VTube Studio 打通

### 模型
- 从 github.com/xkk6663/dsh-live2d-mao 提取 8 个模型到 `E:\dshwork\models\live2d`（53.9 MB，8/8 引用完整）
- VTS 已导入 da-feiyu（大肥鱼）与 whale-deepseek（c_0120，44 个表情）

### VTS 协议结论（实测）
- 激活表情字段是 `expressionFile` + `active: true`（不是 expression）
- **表情可以叠加**：水印消除 + 情绪表情能同时生效
- `Paramcol_3` 不能注入（VTS 只允许 tracking 参数），水印必须走 `13 水印消除.exp3.json`
- VTS 的 `ExpressionStateResponse` 在 c_0120 上会发出非法 UTF-8，Qt 收到后按 1007 断开
  → 改为**本地读取 model3.json** 的表情表，不再请求 ExpressionState
- 事件订阅 `ModelLoadedEvent` 也会引起断线 → 改为 15 秒轮询 CurrentModelRequest

### 功能
- 启动器新增 VTube Studio：路径、启动、关闭、8001 状态
- Live2D 页：连接状态、当前模型、表情数、MouthOpen 测试、14 个情绪按钮
- 情绪映射表：
  - 大肥鱼：开心=龇牙 害羞/亲昵=脸红 难过=担心嘴 生气/阴沉=脸黑 惊讶=O O 疑惑=XX 思考=栗子嘴 调皮=》《
  - c_0120：开心=开心兴奋 兴奋=星星眼 亲昵=爱心眼 难过=悲伤 哭=哭 生气=生气 惊讶=感叹号 疑惑=问号 思考=呆呆眼 调皮=调皮 阴沉=阴暗 晕=晕晕 累=流汗
- 聊天自动情绪：`/voice/speak` 的文本按关键词猜情绪（开心/难过/生气/害羞…），再切表情
- 水印：切到大肥鱼时自动激活 13 水印消除，之后每次切情绪前补一次

### 实测
```
VTS ready，模型 大肥鱼（15 表情）/ c_0120（44 表情）
情绪 happy → 02 龇牙；love → 爱心眼；sad → 悲伤
激活中：02 龇牙, 13 水印消除
千问 19 字 → 168 KB / 0.97 秒，口型 108 帧 3.6 秒
```

## 2026-10-25 · DS鲸鱼娘表情修复 + 声音复刻受阻

### 表情（已修）
- DS鲸鱼娘 是嵌套模型（DS面捕版 / DS鼠控版），model3.json 里没有 Expressions 列表
- 改为：用 CurrentModelResponse 的 modelID 找到对应 .vtube.json 目录 → 扫描 *.exp3.json
- 结果：DS鲸鱼娘 加载 44 个表情；happy→开心兴奋、shy→脸红、angry→生气 均返回成功响应
- 少女鱼 与大肥鱼同 ModelID、同 15 个 EXP，按大肥鱼映射即可

### 声音复刻（阻塞）
- 千问复刻接口 `services/audio/tts/customization` 返回 403：
  `AllocationQuota.FreeTierOnly`（账户仅用免费额度，复刻额度不可用）
- 已准备 `tools/dev/qwen_voice_clone.py`：
  - 小d ← 葛罗莉亚/交谈3.wav（15.0s）
  - demon ← 夜魔/晋升后交谈1.wav（16.1s）
  - 自动创建音色、轮询状态、把 voice_id 写入 config 的 qwenVoice 字段
- 代码已支持每个声线独立 qwenVoice（voiceProfiles[].qwenVoice）

### 其他
- 语音页新增输出设备与音量，跟随系统默认（耳机验证通过）
- 启动页白底修复
- 酒馆保存报错：清理 0 字节残留 + 建议刷新页面（服务重启导致旧会话失效）

## 2026-10-25 · 复刻音色上线 + 表情自动清除

### 声音复刻（完成）
- 账户关闭「仅使用免费额度」后创建成功：
  - 小d：qwen-audio-3.1-tts-flash-xiaod-fa9cfb9a…
  - demon：qwen-audio-3.1-tts-flash-demon-48a52b2e…
- 已写入 4 个声线档案的 qwenVoice：
  小d-柔软 / 小d-柔软-泛化 → 小d 音色
  demon-小恶魔 / demon-小恶魔-2 → demon 音色
- 实测：16 字 191 KB / 2.8 秒；13 字 176 KB / 1.8 秒
- 酒馆插件无需改动（仍调 /voice/speak）

### 表情自动清除（完成）
- 切情绪前先对上一个表情发 active:false，再激活新表情
- 8 秒无新情绪自动撤销，回到中性
- 大肥鱼/DS鲸鱼娘 的水印表情不参与清除
- 实测日志：
  happy active:true → happy active:false → shy active:true
  8 秒后「情绪表情已清除，回到中性」

## 2026-10-25 · 1.2.0：复刻音色重做 + 中文→日语

### 复刻（重做）
- 葛罗莉亚 19 条 + 夜魔 16 条按 1 秒间隔拼成完整音频（210s / 162s，存 dist/voices）
- 复刻样本累计约 44 秒（多句），重新创建 xiaod2 / demon2，写入 4 个声线档案
- 日语测试文本合成成功（小d 172 KB / demon 188 KB）

### 中文 → 日语
- 根因：插件默认 translate=false，输出语言选日语时仍按中文原文合成
- 插件 2.0.1：
  - translate 默认 true
  - 已选非 auto 输出语言且 translate=false 时自动开启
  - 翻译失败回退原文，不中断播放
  - 翻译走酒馆当前模型（generateQuietPrompt），实测「你好，今天天气不错」→「こんにちは、今日はいい天気ですね。」
- ST 设置已改为 outputLang=ja + translate=true

### 发布
- Demon 1.2.0（exe 版本 1.2.0）
- Demonstr-1.2.0-win64.zip 45 文件 / 20.4 MB
  SHA256 4682639F8787536CA9C58BF0785F7EA5B62B3E71A0B5CF2485029523E1797604
- 备份：release/backup/Demon-1.2.0-win64-<时间>.zip + smartdemon-index-2.0.1.js

## 2026-10-25 · 1.2.0 定稿：CosyVoice v3.5

- 试听对比：CosyVoice v3.5 明显更像原声，确定作为默认复刻模型
- 配置：voice.qwen.model = cosyvoice-v3.5-flash
  - 小d-柔软 / 泛化 → cosyvoice-v3.5-flash-xiaodcosy-439a648a…
  - demon-小恶魔 / -2 → cosyvoice-v3.5-flash-demoncosy-24bbe0c2…
- Demon 实测：
  - 小d 27 字日语 → 295,724 字节 / 5.0 秒
  - demon 23 字日语 → 230,444 字节 / 3.1 秒
  - 日志确认收到日语文本（lang=ja）
- 代价：CosyVoice 比 Qwen 慢（3~5 秒 vs 1.8~2.8 秒），逐句播放会感觉稍慢
- 酒馆插件设置 key 修正：真正生效的是 smartdemon（不是 gptsovits5_voice）
  outputLang=ja、translate=true；实测插件发出的请求体已是日语
- 重新打包：
  Demon-1.2.0-win64.zip 46 文件 / 20.4 MB
  SHA256 CE462FFA14E5E8AC919C1872E531C6B51DA3BF1CB40590BE7DB49476E7C3CB36
  备份 backup/Demon-1.2.0-win64-20261025-0126.zip

## 2026-10-26 · Live2D 桌宠去白边 + 导航树 + 声音情绪识别

### 桌宠
- VTS 不再移出屏幕，改为 `WS_EX_LAYERED` + `LWA_ALPHA(0)` 原地透明，PrintWindow 仍能抓帧
- 修复崩溃：DIB 在读取像素前被释放（读已释放内存）
- 去掉 Windows 不可见边框：`DwmGetWindowAttribute(DWMWA_EXTENDED_FRAME_BOUNDS)` 裁剪
- 关闭桌宠 / 退出 Demon 都会恢复 VTS 显示

### 导航
- 改为树形：语音（对接酒馆 / 本地语音 / 云端语音 / 声音情绪识别）、Live2D（本地桌宠 / vts-obs模式）
- 原 Live2D 页整体归入 vts-obs模式

### 声音情绪识别（参考 AAAAGENT）
- 参考 github.com/phoiex/AAAAGENT 的七情绪协议（neutral/happy/sad/angry/fearful/disgusted/surprised）
- 录音 5 秒 → DashScope compatible-mode `qwen3.5-omni-flash-2026-03-15`
- 返回 JSON {transcript, emotion} → 映射到 Demon 情绪并切 Live2D 表情
- 注意：AAAAGENT 为非商业许可 + 署名要求，仅参考其协议与提示词

### 已知
- 本地桌宠需要 Qt WebEngine（未安装）才能复用 AAAAGENT 的 Cubism Web 渲染模块
