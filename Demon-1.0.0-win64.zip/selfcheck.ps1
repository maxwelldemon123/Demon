﻿$ErrorActionPreference = 'Stop'
$base = 'http://127.0.0.1:8790'
$pass = 0
$fail = 0

function Check($name, $ok, $detail) {
    if ($ok) { $script:pass++; Write-Host ("  [PASS] " + $name + "  " + $detail) -ForegroundColor Green }
    else     { $script:fail++; Write-Host ("  [FAIL] " + $name + "  " + $detail) -ForegroundColor Red }
}

Write-Host "Demon 1.0 self check" -ForegroundColor Cyan
Write-Host ("target: " + $base)
Write-Host ""

# 1 health
try {
    $r = Invoke-WebRequest ($base + '/healthz') -UseBasicParsing -TimeoutSec 5
    $j = $r.Content | ConvertFrom-Json
    Check 'healthz' ($r.StatusCode -eq 200 -and $j.status -eq 'ok') ('version=' + $j.version)
} catch { Check 'healthz' $false $_.Exception.Message }

# 2 models
try {
    $r = Invoke-WebRequest ($base + '/v1/models') -UseBasicParsing -TimeoutSec 5
    $j = $r.Content | ConvertFrom-Json
    $ids = ($j.data | ForEach-Object { $_.id }) -join ','
    Check 'models' ($ids -match 'demon') ('ids=' + $ids)
} catch { Check 'models' $false $_.Exception.Message }

# 3 voice status
$profiles = @()
try {
    $r = Invoke-WebRequest ($base + '/voice/status') -UseBasicParsing -TimeoutSec 5
    $j = $r.Content | ConvertFrom-Json
    $profiles = @($j.voice.profiles)
    Check 'voice/status' ($profiles.Count -ge 1) ('profiles=' + ($profiles -join ',') + ' autoPlay=' + $j.voice.autoPlay)
} catch { Check 'voice/status' $false $_.Exception.Message }

# 4 tts (skip when service is down)
$ttsUp = $false
try {
    $c = New-Object Net.Sockets.TcpClient
    $c.Connect('127.0.0.1', 9880)
    $ttsUp = $c.Connected
    $c.Close()
} catch { $ttsUp = $false }

if (-not $ttsUp) {
    Write-Host '  [SKIP] voice/speak  (GPT-SoVITS 9880 not running)' -ForegroundColor Yellow
} else {
try {
    $body = @{ text = '测试'; profile = $(if ($profiles.Count -gt 0) { $profiles[0] } else { 'xiaod' }); lang = 'zh' } | ConvertTo-Json -Compress
    $r = Invoke-WebRequest ($base + '/voice/speak') -Method Post -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -UseBasicParsing -TimeoutSec 120
    $bytes = $r.RawContentStream.ToArray()
    $isWav = ($bytes.Length -gt 10000 -and $bytes[0] -eq 82 -and $bytes[1] -eq 73 -and $bytes[2] -eq 70 -and $bytes[3] -eq 70)
    Check 'voice/speak' $isWav ('bytes=' + $bytes.Length + ' (need >10000, RIFF)')
} catch { Check 'voice/speak' $false $_.Exception.Message }
}

# 5 chat stream
try {
    $body = '{"model":"demon","stream":true,"messages":[{"role":"user","content":"self check"}]}'
    $r = Invoke-WebRequest ($base + '/v1/chat/completions') -Method Post -ContentType 'application/json' -Body $body -UseBasicParsing -TimeoutSec 180
    $txt = $r.Content
    $hasData = $txt -match 'data:'
    $hasDone = $txt -match '\[DONE\]'
    $hasError = $txt -match '"error"'
    if ($hasData -and $hasDone -and -not $hasError) { Check 'chat stream' $true 'got data + [DONE]' }
    elseif ($hasData -and $hasDone) { Check 'chat stream' $true 'data + [DONE], but upstream reported error (check config)' }
    else { Check 'chat stream' $false ('data=' + $hasData + ' done=' + $hasDone) }
} catch { Check 'chat stream' $false $_.Exception.Message }

Write-Host ""
Write-Host ("result: " + $pass + " passed, " + $fail + " failed")
if ($fail -eq 0) { Write-Host "SELF CHECK OK" -ForegroundColor Green } else { Write-Host "SELF CHECK FAILED" -ForegroundColor Red }
exit $fail
