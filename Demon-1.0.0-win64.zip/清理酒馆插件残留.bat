@echo off
chcp 936 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0clean-st-plugin.ps1"
echo.
pause
