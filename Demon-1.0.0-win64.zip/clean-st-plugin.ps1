﻿$ErrorActionPreference = 'Stop'
$stPath = 'C:\mylove\SillyTavern\data\default-user\settings.json'
$backupDir = 'E:\dshwork\st-gptsovits5-voice\_st-backup'

$listening = Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue
if ($listening) {
    Write-Host "SillyTavern is running (port 8000)." -ForegroundColor Yellow
    Write-Host "Close SillyTavern first, then run this again." -ForegroundColor Yellow
    exit 1
}
if (-not (Test-Path $stPath)) { Write-Host "settings.json not found"; exit 1 }

New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Copy-Item $stPath (Join-Path $backupDir ("settings-" + $stamp + ".json")) -Force

$raw = Get-Content $stPath -Raw -Encoding UTF8
$cfg = $raw | ConvertFrom-Json
if ($cfg.extension_settings.PSObject.Properties.Name -contains 'gptsovits5_voice') {
    $cfg.extension_settings.PSObject.Properties.Remove('gptsovits5_voice')
    ($cfg | ConvertTo-Json -Depth 100 -Compress) | Set-Content $stPath -Encoding UTF8 -NoNewline
    Write-Host "Removed gptsovits5_voice from settings.json" -ForegroundColor Green
} else {
    Write-Host "gptsovits5_voice not present (already clean)" -ForegroundColor Green
}
